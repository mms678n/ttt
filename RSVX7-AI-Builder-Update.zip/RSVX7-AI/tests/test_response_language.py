from tests.test_builder import server
import re

def test_personality_instructions_do_not_bias_reply_towards_russian():
    for name, prompt in server.PERSONALITIES.items():
        assert not re.search(r"[\u0400-\u04ff]", prompt), name
        assert "language" in prompt.lower()
