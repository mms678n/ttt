"""No real credentials or platform writes; private file envelope contracts."""
import asyncio
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from file_crypto import encrypt_payload, decrypt_payload, TAG_BYTES


def test_private_payload_roundtrip_and_random_envelopes():
    plaintext = b"private attachment\x00" * 100
    first, envelope = encrypt_payload(plaintext)
    second, other = encrypt_payload(plaintext)
    assert plaintext not in first and first != second and envelope != other
    assert len(first) == len(plaintext) + TAG_BYTES
    assert decrypt_payload(first, envelope) == plaintext


def test_tampered_payload_or_wrong_key_fails_closed_without_secrets():
    data, envelope = encrypt_payload(b"private")
    _, other = encrypt_payload(b"private")
    for payload, key in [(data[:-1] + bytes([data[-1] ^ 1]), envelope), (data, other), (data, {})]:
        with pytest.raises(HTTPException) as error:
            decrypt_payload(payload, key)
        assert error.value.status_code == 502
        assert envelope["key_b64"] not in str(error.value.detail)


def test_download_authorizes_before_decrypt_and_returns_nocache(monkeypatch):
    import workspace
    encrypted, envelope = encrypt_payload(b"owner-only")
    record = {"_id": "f_crypto", "user_id": "owner", "is_deleted": False,
              "upload_status": "ready", "storage_path": "manus:test/cipher",
              "payload_encryption": envelope, "name": "private.txt", "content_type": "text/plain"}

    class Files:
        async def find_one(self, query):
            return record if query["user_id"] == "owner" else None
    class Database:
        backend_name = "mysql"
        files = Files()
    async def provider(path, max_bytes):
        assert path == record["storage_path"]
        return encrypted, "application/octet-stream"
    monkeypatch.setattr(workspace, "db", Database())
    monkeypatch.setattr(workspace, "manus_get_object", provider)
    async def scenario():
        response = await workspace.download_file("f_crypto", {"_id": "owner"})
        assert response.body == b"owner-only"
        assert response.headers["cache-control"] == "private, no-store"
        assert response.headers["x-content-type-options"] == "nosniff"
        assert response.headers["content-disposition"].startswith("attachment;")
        with pytest.raises(HTTPException) as error:
            await workspace.download_file("f_crypto", {"_id": "intruder"})
        assert error.value.status_code == 404
    asyncio.run(scenario())


def test_public_file_representations_exclude_encryption_key():
    source = (Path(__file__).resolve().parents[1] / "backend/workspace.py").read_text()
    assert source.count('"payload_encryption": 0') >= 2
    assert 'doc.pop("extracted_text", None)' in source
