"""Domain integration: isolated loopback SQL only, never Manus DATABASE_URL."""
from __future__ import annotations

import asyncio
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import pytest
import pytest_asyncio
from fastapi import HTTPException
from starlette.requests import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from mysql_repository import MySQLDatabase
from sql_schema import COLLECTION_TABLES
import auth
import coupons
import tokens
import referrals
import workspace


@pytest_asyncio.fixture
async def sql(monkeypatch):
    if os.environ.get("RUN_MYSQL_TESTS") != "1":
        pytest.skip("Opt-in local SQL integration")
    url = os.environ.get("RSVX7_MYSQL_DOMAIN_TEST_URL", "")
    parsed = urlsplit(url)
    if parsed.hostname not in {"127.0.0.1", "localhost"} or parsed.path != "/rsvx7_test_mysql_domain":
        raise AssertionError("Use the dedicated loopback rsvx7_test_mysql_domain fixture")
    db = MySQLDatabase(url, allow_local_plaintext=True)
    await db.initialize()
    for name in COLLECTION_TABLES:
        await getattr(db, name).delete_many({})
    for module in (auth, coupons, tokens, referrals, workspace):
        monkeypatch.setattr(module, "db", db)
    async def no_network(*args, **kwargs):
        return None
    monkeypatch.setattr(coupons, "tg_send", no_network)
    monkeypatch.setattr(auth, "_bot_send", no_network)
    monkeypatch.setenv("FILE_STORAGE_BACKEND", "manus")
    try:
        yield db
    finally:
        for name in COLLECTION_TABLES:
            await getattr(db, name).delete_many({})
        await db.close()


async def add_user(db, uid, **extra):
    await db.users.insert_one({"_id": uid, "username": uid, "role": "user",
                               "status": "active", "token_balance": 0,
                               "total_used_tokens": 0, "total_input_tokens": 0,
                               "total_output_tokens": 0, **extra})


def request():
    return Request({"type": "http", "method": "POST", "path": "/api/coupons/redeem",
                    "headers": [], "client": ("127.0.0.1", 42000), "query_string": b""})


@pytest.mark.asyncio
async def test_owner_requires_new_protected_password_and_is_not_reset(sql, monkeypatch):
    monkeypatch.setattr(auth, "OWNER_USERNAME", "test-domain-owner")
    monkeypatch.setenv("OWNER_INITIAL_PASSWORD", "LegacyFixtureMustNotSeed1!")
    monkeypatch.delenv("RSVX7_MANAGED_OWNER_PASSWORD", raising=False)
    with pytest.raises(RuntimeError, match="RSVX7_MANAGED_OWNER_PASSWORD"):
        await auth.seed_admin()
    assert await sql.users.count_documents({}) == 0
    monkeypatch.setenv("RSVX7_MANAGED_OWNER_PASSWORD", "NewSQLFixtureOwnerPassword1!")
    def no_plaintext_file(*args):
        raise AssertionError("SQL owner must never write credentials")
    monkeypatch.setattr(auth, "_write_owner_credentials_file", no_plaintext_file)
    await asyncio.gather(auth.seed_admin(), auth.seed_admin())
    owner = await sql.users.find_one({"is_owner": True})
    assert await sql.users.count_documents({"is_owner": True}) == 1
    assert owner["must_change_password"] is True
    original = owner["password_hash"]
    monkeypatch.setenv("RSVX7_MANAGED_OWNER_PASSWORD", "ReplacementMustNotReset1!")
    await auth.seed_admin()
    assert (await sql.users.find_one({"_id": owner["_id"]}))["password_hash"] == original


@pytest.mark.asyncio
async def test_atomic_charge_concurrency_and_idempotency(sql):
    await add_user(sql, "wallet", token_balance=50000)
    results = await asyncio.gather(*(tokens.charge_user(
        "wallet", prompt_tokens=10, completion_tokens=20, user_input_tokens=10,
        idempotency_key="same-charge", model="fixture",) for _ in range(12)))
    charged = int(round(30 * tokens.BILLING_MULTIPLIER))
    assert all(result["total_tokens"] == charged for result in results)
    assert await sql.token_usage_history.count_documents({"user_id": "wallet"}) == 1
    user = await sql.users.find_one({"_id": "wallet"})
    assert user["token_balance"] == 50000 - charged and user["total_used_tokens"] == charged
    assert user["billing_charge_markers"] == ["same-charge"]


@pytest.mark.asyncio
async def test_history_failure_rolls_back_balance_and_marker(sql, monkeypatch):
    await add_user(sql, "rollback-wallet", token_balance=100)
    async def fail(*args, **kwargs):
        raise RuntimeError("fixture history failure")
    monkeypatch.setattr(sql.token_usage_history, "insert_one", fail)
    with pytest.raises(RuntimeError):
        await tokens.charge_user("rollback-wallet", prompt_tokens=10, completion_tokens=20,
                                 user_input_tokens=10, idempotency_key="failed")
    user = await sql.users.find_one({"_id": "rollback-wallet"})
    assert user["token_balance"] == 100 and user["total_used_tokens"] == 0
    assert not user.get("billing_charge_markers")


@pytest.mark.asyncio
async def test_coupon_max_uses_and_idempotent_credit(sql):
    await add_user(sql, "redeemer-a")
    await add_user(sql, "redeemer-b")
    await sql.coupons.insert_one({"_id": "ONE", "enabled": True, "tokens": 90,
                                 "max_uses": 1, "used_count": 0, "per_user_once": True})
    async def redeem(uid):
        try:
            return await coupons.redeem_coupon(coupons.RedeemBody(code="ONE"), request(), {"_id": uid})
        except HTTPException as error:
            return error.status_code
    results = await asyncio.gather(redeem("redeemer-a"), redeem("redeemer-b"))
    assert sum(isinstance(result, dict) for result in results) == 1
    assert 400 in results
    assert (await sql.coupons.find_one({"_id": "ONE"}))["used_count"] == 1
    assert await sql.redemptions.count_documents({"status": "completed"}) == 1
    users = await sql.users.find({}).to_list(10)
    assert sum(user["token_balance"] for user in users) == 90
    winner = next(user["_id"] for user in users if user["token_balance"] == 90)
    repeated = await asyncio.gather(*(redeem(winner) for _ in range(8)))
    assert all(result.get("idempotent") for result in repeated)
    assert (await sql.users.find_one({"_id": winner}))["token_balance"] == 90
    stats = await coupons.admin_coupon_stats({})
    assert stats["total_redemptions"] == 1 and stats["tokens_distributed"] == 90


@pytest.mark.asyncio
async def test_referral_rewards_commit_once_and_missing_referrer_rolls_back(sql):
    await add_user(sql, "inviter")
    await add_user(sql, "invitee", referred_by="inviter", referral_pending=True)
    results = await asyncio.gather(*(referrals.finalize_referral("invitee") for _ in range(8)))
    assert sum(result.get("claimed", False) for result in results) == 1
    assert (await sql.users.find_one({"_id": "invitee"}))["token_balance"] == 2500
    assert (await sql.users.find_one({"_id": "inviter"}))["token_balance"] == 10000
    await add_user(sql, "orphan", referred_by="missing", referral_pending=True)
    with pytest.raises(HTTPException) as error:
        await referrals.finalize_referral("orphan")
    assert error.value.status_code == 503
    orphan = await sql.users.find_one({"_id": "orphan"})
    assert orphan["token_balance"] == 0 and orphan["referral_pending"] is True


@pytest.mark.asyncio
async def test_usage_aggregation_applies_date_match_and_regex_is_scoped(sql):
    await sql.usage.insert_one({"_id": "today", "user_id": "a", "date": "2026-10-05", "msgs": 3})
    await sql.usage.insert_one({"_id": "past", "user_id": "a", "date": "2026-10-04", "msgs": 7})
    result = await sql.usage.aggregate([
        {"$match": {"date": "2026-10-05"}}, {"$group": {"_id": None, "s": {"$sum": "$msgs"}}}
    ]).to_list(1)
    assert result == [{"_id": None, "s": 3}]
    await add_user(sql, "RegexName")
    assert await sql.users.count_documents({"username": {"$regex": "^regex", "$options": "i"}}) == 1
    assert await sql.users.count_documents({"username": {"$regex": "^regex"}}) == 0


@pytest.mark.asyncio
async def test_conversation_order_and_owner_id_collision(sql, monkeypatch):
    async def allow(*args, **kwargs):
        return None
    monkeypatch.setattr(workspace, "require_membership", allow)
    monkeypatch.setattr(workspace, "require_active_subscription", allow)
    project = await workspace.create_project(workspace.ProjectCreate(name="SQL project"), {"_id": "chat-user"})
    pid = project["_id"]
    conversation = await workspace.create_conversation(pid, workspace.ConversationCreate(id="c_sql_domain", title="SQL chat"), {"_id": "chat-user"})
    async def save(i):
        body = workspace.TurnBody(messages=[workspace.MessagePayload(id=f"m_sql_domain_{i}", role="user", content=str(i))])
        return await workspace.append_turn(conversation["_id"], body, {"_id": "chat-user"})
    await asyncio.gather(*(save(i) for i in range(16)))
    messages = await sql.messages.find({"conversation_id": "c_sql_domain"}).sort("order_index", 1).to_list(20)
    assert [message["order_index"] for message in messages] == list(range(1, 17))
    with pytest.raises(HTTPException) as error:
        await workspace.get_conversation("c_sql_domain", after=0, limit=500, u={"_id": "other-user"})
    assert error.value.status_code == 404


@pytest.mark.asyncio
async def test_verified_telegram_is_unique_and_private_challenge_cas(sql):
    expires = (datetime.now(timezone.utc) + auth.timedelta(minutes=5)).isoformat()
    for uid in ("tg-first", "tg-second"):
        await add_user(sql, uid, telegram={"verified": False, "challenge_nonce": uid,
                                         "challenge_expires_at": expires, "challenge_completed": False})
    async def verify(uid):
        return await auth._tg_complete_challenge("fixture", {"id": 101, "type": "private"},
                                                 {"id": 101, "username": "tg"}, uid)
    results = await asyncio.gather(verify("tg-first"), verify("tg-second"))
    assert sum(result is not None for result in results) == 1
    assert await sql.users.count_documents({"telegram.verified": True, "telegram.telegram_id": 101}) == 1


@pytest.mark.asyncio
async def test_generation_lease_concurrency_expiry_and_scoped_release(sql, monkeypatch):
    import ai_settings
    monkeypatch.setattr(ai_settings, "db", sql)
    async def claim():
        try:
            return await ai_settings.claim_generation("lease-user")
        except HTTPException as error:
            return error.status_code
    results = await asyncio.gather(*(claim() for _ in range(8)))
    assert sum(isinstance(result, str) for result in results) == 1
    assert results.count(409) == 7
    first = next(result for result in results if isinstance(result, str))
    await ai_settings.release_generation("lease-user", "wrong-owner")
    assert await sql.ai_request_leases.count_documents({}) == 1
    await sql.ai_request_leases.update_one({"_id": "lease-user"}, {"$set": {"expires_at": datetime(2000, 1, 1, tzinfo=timezone.utc)}})
    second = await ai_settings.claim_generation("lease-user")
    assert second != first
    await ai_settings.release_generation("lease-user", first)
    assert await sql.ai_request_leases.count_documents({}) == 1
    await ai_settings.release_generation("lease-user", second)
    assert await sql.ai_request_leases.count_documents({}) == 0


@pytest.mark.asyncio
async def test_no_automatic_import_into_managed_database(sql):
    with pytest.raises(HTTPException) as error:
        await workspace.migrate_from_local(workspace.MigrateBody(chats=[]), {"_id": "user"})
    assert error.value.status_code == 409
    assert await sql.projects.count_documents({}) == 0


@pytest.mark.asyncio
async def test_nonrepeat_coupon_cannot_be_redeemed_with_new_retry_keys(sql):
    await add_user(sql, "nonrepeat")
    await sql.coupons.insert_one({"_id": "SINGLE", "enabled": True, "tokens": 7,
                                 "max_uses": 0, "used_count": 0, "repeat_allowed": False})
    async def redeem(i):
        return await coupons.redeem_coupon(coupons.RedeemBody(code="SINGLE", idempotency_key=f"new-key-{i}"), request(), {"_id": "nonrepeat"})
    results = await asyncio.gather(*(redeem(i) for i in range(8)))
    assert all(result["ok"] for result in results)
    assert (await sql.users.find_one({"_id": "nonrepeat"}))["token_balance"] == 7
    assert (await sql.coupons.find_one({"_id": "SINGLE"}))["used_count"] == 1
    assert await sql.redemptions.count_documents({"user_id": "nonrepeat"}) == 1


@pytest.mark.asyncio
async def test_nonrepeat_respects_old_request_suffixed_redemption_without_mutation(sql):
    await add_user(sql, "historical", token_balance=7)
    await sql.coupons.insert_one({"_id": "OLD", "enabled": True, "tokens": 7,
                                 "max_uses": 0, "used_count": 1, "repeat_allowed": False})
    row = {"_id": "old-redemption", "user_id": "historical", "code": "OLD", "tokens": 7,
           "dedup_key": "historical:OLD:request:old-client", "status": "completed"}
    await sql.redemptions.insert_one(row)
    result = await coupons.redeem_coupon(coupons.RedeemBody(code="OLD", idempotency_key="new-key"), request(), {"_id": "historical"})
    assert result["idempotent"]
    assert (await sql.users.find_one({"_id": "historical"}))["token_balance"] == 7
    assert await sql.redemptions.find_one({"_id": "old-redemption"}) == row
    assert await sql.redemptions.count_documents({}) == 1


@pytest.mark.asyncio
async def test_conversation_create_and_delete_roll_back_all_related_writes(sql, monkeypatch):
    async def allow(*args, **kwargs):
        return None
    monkeypatch.setattr(workspace, "require_membership", allow)
    monkeypatch.setattr(workspace, "require_active_subscription", allow)
    project = await workspace.create_project(workspace.ProjectCreate(name="Atomic"), {"_id": "atomic-user"})
    pid = project["_id"]
    original_update = sql.projects.update_one
    async def fail_counter(*args, **kwargs):
        raise RuntimeError("fixture project write failure")
    monkeypatch.setattr(sql.projects, "update_one", fail_counter)
    with pytest.raises(RuntimeError):
        await workspace.create_conversation(pid, workspace.ConversationCreate(id="c_atomic_fail"), {"_id": "atomic-user"})
    assert await sql.conversations.count_documents({}) == 0
    assert (await sql.projects.find_one({"_id": pid}))["conversation_count"] == 0
    monkeypatch.setattr(sql.projects, "update_one", original_update)
    conversation = await workspace.create_conversation(pid, workspace.ConversationCreate(id="c_atomic_keep"), {"_id": "atomic-user"})
    await workspace.append_turn(conversation["_id"], workspace.TurnBody(messages=[workspace.MessagePayload(id="m_atomic_keep", role="user", content="keep")]), {"_id": "atomic-user"})
    monkeypatch.setattr(sql.projects, "update_one", fail_counter)
    with pytest.raises(RuntimeError):
        await workspace.delete_conversation(conversation["_id"], {"_id": "atomic-user"})
    assert await sql.conversations.find_one({"_id": "c_atomic_keep"})
    assert await sql.messages.find_one({"_id": "m_atomic_keep"})
    assert (await sql.projects.find_one({"_id": pid}))["conversation_count"] == 1


@pytest.mark.asyncio
async def test_wallet_user_created_index_is_real_not_only_declared(sql):
    async with sql._connection() as conn:
        rows = await sql._fetchall(conn, "SELECT COLUMN_NAME AS name FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s ORDER BY SEQ_IN_INDEX", ["rsvx7_token_usage_history", "idx_rsvx7_token_usage_history_user_created"])
    assert [row["name"] for row in rows] == ["user_id", "created_at"]
