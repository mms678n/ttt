"""Opt-in real local ASGI/WebSocket transport, native sessions and fake Agent."""
import json,os,secrets,socket,subprocess,tempfile,time
from pathlib import Path
import jwt,pytest,requests
from pymongo import MongoClient
from tests.test_full_stack_regressions import local_catalog
ROOT=Path(__file__).resolve().parents[1]

def port():
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));return sock.getsockname()[1]

@pytest.mark.skipif(os.environ.get('RUN_E2E')!='1',reason='Separate local runtime is opt-in')
def test_real_agent_pairing_terminal_owner_isolation_and_revocation(local_catalog):
    from websockets.sync.client import connect
    env={**os.environ,'RSVX7_DATA_BACKEND':'mongo','MONGO_URL':'mongodb://127.0.0.1:27017','DB_NAME':'rsvx7ai_test_remote_ws_'+secrets.token_hex(6),
         'RSVX7_JWT_SECRET':secrets.token_hex(32),'OWNER_INITIAL_PASSWORD':secrets.token_urlsafe(20),'OWNER_USERNAME':'transport_owner',
         'PORT':str(port()),'BUILDER_ENGINE_PORT':str(port()),'OPENROUTER_API_KEY':'','OPENROUTER_BASE_URL':local_catalog,'COOKIE_SECURE':'false'}
    base='http://127.0.0.1:'+env['PORT'];wsbase=base.replace('http','ws')+'/api/remote/api/ws'
    mongo=MongoClient(env['MONGO_URL']);db=mongo[env['DB_NAME']]
    def token(uid):return jwt.encode({'sub':uid,'role':'user','session_version':0,'exp':int(time.time())+600},env['RSVX7_JWT_SECRET'],algorithm='HS256')
    alice,bob=token('alice'),token('bob')
    with tempfile.TemporaryDirectory(prefix='remote-transport-') as folder:
        env['OWNER_CREDENTIALS_FILE']=folder+'/credentials.md'
        with open(folder+'/runtime.log','w') as log:
            process=subprocess.Popen([str(ROOT/'.venv/bin/python'),'scripts/run_services.py'],cwd=ROOT,env=env,stdout=log,stderr=log)
        try:
            for _ in range(150):
                try:
                    if requests.get(base+'/readyz',timeout=1).status_code==200:break
                except requests.RequestException:pass
                time.sleep(.2)
            else:raise AssertionError(Path(folder+'/runtime.log').read_text()[-5000:])
            assert requests.get(base+'/remote-ui/',timeout=3).status_code==200
            db.users.insert_many([{'_id':uid,'username':uid,'status':'active','role':'user','session_version':0,'token_balance':1000,'monthly':{'plan':'max','remaining':0,'allowance':25000000,'starts_at':'2026-01-01T00:00:00+00:00','ends_at':'2099-01-01T00:00:00+00:00','version':'fixture-max'}} for uid in ('alice','bob')])
            with connect(wsbase+'/devices?token=',origin=base,additional_headers={'Cookie':'access_token='+bob},open_timeout=3) as cookie_session:
                assert json.loads(cookie_session.recv(timeout=3))['type']=='snapshot'
            secret=secrets.token_urlsafe(64)  # Real Agent secrets exceed bcrypt's 72-byte input limit.
            result=requests.post(base+'/api/remote/api/devices/register',headers={'Authorization':'Bearer '+alice},json={'device_id':'HG-AB12CD34-EF56','device_secret':secret},timeout=5)
            assert result.status_code==200,result.text
            target=result.json()['id']
            with connect(wsbase+'/agent',open_timeout=3) as agent:
                agent.send(json.dumps({'type':'auth','device_id':'HG-AB12CD34-EF56','secret':secret,'agent_version':'1.2.0'}))
                assert json.loads(agent.recv(timeout=3))['type']=='authok'
                agent.send(json.dumps({'type':'heartbeat','ts':1}))
                assert json.loads(agent.recv(timeout=3))['type']=='ack'
                with connect(wsbase+'/device-terminal/'+target+'?token='+alice,origin=base,open_timeout=3) as terminal:
                    start=json.loads(agent.recv(timeout=3));assert start['type']=='shell_start'
                    assert json.loads(terminal.recv(timeout=3))['type']=='connected'
                    terminal.send(json.dumps({'type':'input','data':'echo test\n'}))
                    assert json.loads(agent.recv(timeout=3))['type']=='shell_input'
                    agent.send(json.dumps({'type':'shell_output','shell_id':start['shell_id'],'data':'مرحبا actual-terminal'}))
                    assert json.loads(terminal.recv(timeout=3))['data']=='مرحبا actual-terminal'
                    db.users.update_one({'_id':'alice'},{'$inc':{'session_version':1}})
                    terminal.send(json.dumps({'type':'input','data':'MUST NOT EXECUTE'}))
                    with pytest.raises(Exception):terminal.recv(timeout=3)
                # Drain shell_close emitted by normal teardown, never the rejected command.
                closing=json.loads(agent.recv(timeout=3));assert closing['type']=='shell_close'
                with connect(wsbase+'/monitor/'+target+'?token='+bob,origin=base,open_timeout=3) as foreign:
                    event=json.loads(foreign.recv(timeout=3));assert event['type']=='error'
            assert requests.get(base+'/api/remote/api/devices',headers={'Authorization':'Bearer '+alice},timeout=3).status_code==401
        finally:
            process.terminate()
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:process.kill();process.wait()
            mongo.drop_database(env['DB_NAME']);mongo.close()
