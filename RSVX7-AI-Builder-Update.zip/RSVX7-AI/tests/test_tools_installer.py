import base64, gzip, hashlib, json, runpy, subprocess, sys, zlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
INSTALLER=ROOT/'scripts/install_tools_update.py'

def test_installer_checks_preserves_files_and_is_idempotent(tmp_path):
    subprocess.run(['git','init','-q',str(tmp_path)],check=True)
    state=runpy.run_path(str(INSTALLER))
    patch=zlib.decompress(base64.b85decode(state['PAYLOAD']))
    baseline=json.loads(gzip.decompress((ROOT/'tests/fixtures/tools_v20.json.gz').read_bytes()))
    for rel in state['FILES']:
        path=tmp_path/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(baseline[rel])
    deploy=tmp_path/'deploy';deploy.mkdir();(deploy/'compose.selfhost.yaml').write_text('fixture')
    env=tmp_path/'.env.selfhost';env.write_text('fixture-only')
    subprocess.run(['git','apply','--reverse','-'],input=patch,cwd=tmp_path,check=True,capture_output=True)
    # Independent local features outside patched hunks must survive.
    server=tmp_path/'backend/server.py';server.write_text('# local admin switch preserved\n'+server.read_text())
    def run(*args):return subprocess.run([sys.executable,str(INSTALLER),'--project',str(tmp_path),*args],capture_output=True,text=True)
    before=server.read_bytes()
    result=run('--check');assert result.returncode==0,result.stdout+result.stderr
    assert server.read_bytes()==before
    result=run();assert result.returncode==0,result.stdout+result.stderr
    assert server.read_text().startswith('# local admin switch preserved')
    assert (tmp_path/'backend/tool_protocol.py').read_bytes()==(ROOT/'backend/tool_protocol.py').read_bytes()
    assert env.read_text()=='fixture-only'
    assert run().returncode==0
    manifests=list((tmp_path/'.rsvx7-backups').glob('tools-*/manifest.json'))
    assert len(manifests)==1
    original=manifests[0].parent/'original/backend/server.py'
    assert original.read_bytes()==before
