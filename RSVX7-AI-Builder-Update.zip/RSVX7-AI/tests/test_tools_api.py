import asyncio,json,copy
from unittest.mock import AsyncMock
import httpx,pytest
from openai import AsyncOpenAI
from tests.test_developer_api import env
from tests.test_builder import auth,server,tokens
from tests.test_hf_chat_stream import sdk_chunk

TOOL={'type':'function','function':{'name':'read_file','description':'Read a file','parameters':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']}}}

@pytest.mark.parametrize('streaming',[False,True])
@pytest.mark.parametrize('requested',[32000,999999999])
def test_tool_roundtrip_stream_and_json_preserve_wallet_and_large_budget(env,monkeypatch,streaming,requested):
    env.users.rows['alice']['token_balance']=1000000
    monkeypatch.setattr(tokens,'db',env)
    monkeypatch.setattr(server,'require_membership',AsyncMock())
    monkeypatch.setattr(server,'current_settings',AsyncMock(return_value={'model':'fixture/tool-model','context_length':131072,'max_completion_tokens':65536,'supported_parameters':['tools','tool_choice'],'reasoning':None}))
    monkeypatch.setattr(server,'claim_generation',AsyncMock(side_effect=['lease-one','lease-two']))
    monkeypatch.setattr(server,'release_generation',AsyncMock())
    requests=[]
    async def handler(request):
        body=json.loads(request.content);requests.append(body)
        if body['messages'][-1]['role']=='tool':
            chunks=[sdk_chunk({'content':'File has hello'},'stop')]
        else:
            chunks=[sdk_chunk({'tool_calls':[{'index':0,'id':'call_read','type':'function','function':{'name':'read_file','arguments':'{"path":'}}]}),sdk_chunk({'tool_calls':[{'index':0,'function':{'arguments':'"demo.txt"}'}}]},'tool_calls')]
        chunks.append(sdk_chunk(usage={'prompt_tokens':23,'completion_tokens':7,'total_tokens':30}))
        return httpx.Response(200,headers={'content-type':'text/event-stream'},content=''.join('data: '+json.dumps(c)+'\n\n' for c in chunks)+'data: [DONE]\n\n')
    provider=AsyncOpenAI(api_key='fixture',base_url='https://fixture.test/v1',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)),max_retries=0)
    monkeypatch.setattr(server,'request_client',lambda _:provider)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://fixture.test') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user')}
            key=(await c.post('/api/developer/key',headers=session)).json()['key']
            headers={'Authorization':'Bearer '+key}
            payload={'model':'kaligpt','messages':[{'role':'user','content':'Read demo.txt'}],'tools':[TOOL],'tool_choice':'auto','max_tokens':requested,'stream':streaming}
            result=await c.post('/api/v1/chat/completions',headers=headers,json=payload)
            assert result.status_code==200,result.text
            if streaming:
                chunks=[json.loads(line[6:]) for line in result.text.splitlines() if line.startswith('data: ') and line!='data: [DONE]']
                assert any(x['choices'] and x['choices'][0]['finish_reason']=='tool_calls' for x in chunks)
                deltas=[x['choices'][0]['delta']['tool_calls'][0] for x in chunks if x['choices'] and x['choices'][0]['delta'].get('tool_calls')]
                arguments=''.join(x.get('function',{}).get('arguments','') for x in deltas)
                calls=[{'id':'call_read','type':'function','function':{'name':'read_file','arguments':arguments}}]
            else:
                body=result.json();assert body['choices'][0]['finish_reason']=='tool_calls'
                calls=body['choices'][0]['message']['tool_calls']
            assert json.loads(calls[0]['function']['arguments'])=={'path':'demo.txt'}
            assert requests[0]['max_tokens']==min(requested,65536) and requests[0]['tools']==[TOOL]
            assert len(env.token_usage_history.rows)==1
            second=copy.deepcopy(payload);second['stream']=False
            second['messages'] += [{'role':'assistant','content':None,'tool_calls':calls},{'role':'tool','tool_call_id':'call_read','content':'hello'}]
            result=await c.post('/api/v1/chat/completions',headers=headers,json=second)
            assert result.status_code==200,result.text
            assert result.json()['choices'][0]['message']['content']=='File has hello'
            assert len(env.token_usage_history.rows)==2
            assert requests[1]['messages'][-1]==second['messages'][-1]
        await provider.close()
    asyncio.run(scenario())


def test_chat_large_limit_is_clamped_to_model_instead_of_rejected():
    body=server.ChatStreamRequest(messages=[{'role':'user','content':'Hi'}],max_tokens=32000)
    assert body.max_tokens==32000

from backend.tool_protocol import ToolAccumulator, ToolDefinition, ToolMessage, validate_tools

def test_parallel_calls_and_protocol_rejections():
    tools=[ToolDefinition.model_validate(TOOL)]
    calls=ToolAccumulator(tools)
    calls.push([{'index':1,'id':'two','function':{'name':'read_','arguments':'{"path":'}}, {'index':0,'id':'one','function':{'name':'read_file','arguments':'{"path":"a"}'}}])
    calls.push([{'index':1,'function':{'name':'file','arguments':'"b"}'}}])
    calls.finish('tool_calls')
    assert [c['id'] for c in calls.values()]==['one','two']
    with pytest.raises(ValueError):
        ToolAccumulator(tools).finish('tool_calls')
    broken=ToolAccumulator(tools)
    broken.push([{'index':0,'id':'bad','function':{'name':'read_file','arguments':'{'}}])
    with pytest.raises(ValueError):broken.finish('tool_calls')
    from fastapi import HTTPException
    with pytest.raises(HTTPException):
        validate_tools([ToolMessage(role='tool',content='hi',tool_call_id='orphan')],tools,None)
    with pytest.raises(HTTPException):
        validate_tools([ToolMessage(role='assistant',tool_calls=calls.values())],tools,None)
    history=[ToolMessage(role='assistant',tool_calls=calls.values()),ToolMessage(role='tool',content='',tool_call_id='one'),ToolMessage(role='tool',content='ok',tool_call_id='two')]
    validate_tools(history,tools,'auto')

def test_tools_and_tool_history_count_towards_prompt_budget():
    baseline=tokens.estimate_messages_tokens([{'role':'assistant','content':''}])
    with_calls=tokens.estimate_messages_tokens([{'role':'assistant','content':None,'tool_calls':[{'id':'x','function':{'name':'read_file','arguments':'x'*10000}}]}])
    assert with_calls>baseline+100

def test_hf_known_output_limit_is_not_capped_at_8192():
    from backend.huggingface_provider import model_metadata
    data=[{'id':'Qwen/fixture','providers':[{'provider':'one','status':'live','context_length':131072,'max_completion_tokens':65536,'supports_tools':True}]}]
    assert model_metadata('Qwen/fixture',data)['max_completion_tokens']==65536

def test_admin_output_limit_bounded_by_context():
    from backend.ai_settings import OutputLimitsBody
    assert OutputLimitsBody(limits={'Qwen/test':65536}).limits['Qwen/test']==65536
    with pytest.raises(ValueError):OutputLimitsBody(limits={'Qwen/test':0})

def test_openai_new_output_parameter_alias():
    from backend.developer_api import Completion
    assert Completion(model='kaligpt',messages=[{'role':'user','content':'hi'}],max_completion_tokens=32000).max_tokens==32000

def test_effective_limits_keep_known_provider_cap_and_allow_unknown_override():
    from backend.ai_settings import effective_output_limit
    saved={'output_limits':{'Qwen/test':65536}}
    selected={'model':'Qwen/test','context_length':131072,'max_completion_tokens':8192}
    assert effective_output_limit(saved,selected)==65536
    assert effective_output_limit(saved,{**selected,'output_limit_known':True})==8192
    assert effective_output_limit({},selected)==8192

def test_admin_limit_update_checks_catalog_and_persists_without_credits(env,monkeypatch):
    import ai_settings
    from fastapi import HTTPException
    env.settings.rows['ai']={'_id':'ai','model':'Qwen/test','context_length':131072}
    metadata={'model':'Qwen/test','context_length':131072,'max_completion_tokens':8192,'output_limit_known':False}
    monkeypatch.setattr(ai_settings,'validate_catalog_model',AsyncMock(return_value=metadata))
    async def scenario():
        result=await ai_settings.update_output_limits(ai_settings.OutputLimitsBody(limits={'Qwen/test':65536}),{'_id':'owner'})
        assert result['limits']=={'Qwen/test':65536}
        assert (await ai_settings.current_settings())['max_completion_tokens']==65536
        with pytest.raises(HTTPException):
            await ai_settings.update_output_limits(ai_settings.OutputLimitsBody(limits={'Qwen/test':131072}),{'_id':'owner'})
        metadata['output_limit_known']=True
        with pytest.raises(HTTPException):
            await ai_settings.update_output_limits(ai_settings.OutputLimitsBody(limits={'Qwen/test':65536}),{'_id':'owner'})
    asyncio.run(scenario())
