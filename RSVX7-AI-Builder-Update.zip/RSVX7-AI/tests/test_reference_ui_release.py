"""The frontend installer must reject the missing remote build before modifying a host."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path


def test_installer_rejects_build_missing_remote(tmp_path):
    source = tmp_path / 'release'
    target = tmp_path / 'existing'
    (source / 'scripts').mkdir(parents=True)
    shutil.copy2(Path(__file__).resolve().parents[1] / 'scripts/install_reference_ui.py', source / 'scripts')
    (target / 'backend').mkdir(parents=True)
    (target / 'backend/server.py').write_text('# existing server')
    (target / 'deploy').mkdir()
    (target / 'deploy/compose.selfhost.yaml').write_text('services: {}')
    content = {'frontend/build/index.html': b'new', 'frontend/build/static/js/main.js': b'new js'}
    for name, value in content.items():
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    (source / 'REFERENCE-UI-MANIFEST.json').write_text(json.dumps({'files': {
        name: hashlib.sha256(value).hexdigest() for name, value in content.items()
    }}))
    result = subprocess.run([sys.executable, str(source / 'scripts/install_reference_ui.py'), '--target', str(target)], text=True, capture_output=True)
    assert result.returncode != 0
    assert 'remote interface assets are missing' in result.stderr
    assert not (target / '.rsvx7-backups').exists()
    assert (target / 'backend/server.py').read_text() == '# existing server'
