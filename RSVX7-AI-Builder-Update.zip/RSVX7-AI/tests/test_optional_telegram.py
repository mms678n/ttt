"""Telegram remains voluntary even with legacy verification settings enabled.

No Mongo server, Telegram bot, AI provider, or paid requests are used here.
"""
import asyncio
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import BackgroundTasks, HTTPException, Response
from starlette.requests import Request

os.environ["JWT_SECRET"] = "optional-linking-test-secret"
os.environ["MONGO_URL"] = "mongodb://127.0.0.1:27017"
os.environ["DB_NAME"] = "rsvx7ai_test_optional_linking"
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
import auth
import tg_verify


@pytest.mark.parametrize("standalone", ["false", "true"])
def test_public_settings_never_require_linking(monkeypatch, standalone):
    monkeypatch.setenv("RSVX7_STANDALONE", standalone)
    monkeypatch.setattr(auth, "db", SimpleNamespace(settings=SimpleNamespace(find_one=AsyncMock(return_value={"telegram_bot_token": "test"}))))
    result = asyncio.run(auth.get_settings_public())
    assert result["telegram_required"] is False
    assert result["telegram_bot_configured"] is True


def test_registration_returns_recovery_and_session_without_linking(monkeypatch):
    monkeypatch.setenv("RSVX7_STANDALONE", "false")
    users = SimpleNamespace(find_one=AsyncMock(return_value=None), insert_one=AsyncMock())
    monkeypatch.setattr(auth, "db", SimpleNamespace(users=users))
    import referrals
    monkeypatch.setattr(referrals, "ensure_referral_code", AsyncMock(return_value="TESTCODE"))
    request = Request({"type": "http", "method": "POST", "path": "/api/auth/register", "headers": [], "client": ("127.0.0.1", 1234)})
    result = asyncio.run(auth.register(auth.RegisterBody(username="optional_user", password="SafePassword1!"), request, Response(), BackgroundTasks()))
    assert result["telegram_required"] is False
    assert len(result["recovery_code"].split("-")) == 4
    assert auth.jwt.decode(result["token"], auth.JWT_SECRET, algorithms=[auth.ALG])["sub"] == result["id"]
    saved = users.insert_one.call_args.args[0]
    assert auth.verify_pw(result["recovery_code"], saved["recovery_hash"])
    assert not saved.get("telegram", {}).get("challenge_nonce")


@pytest.mark.parametrize("telegram", [{}, None, {"verified": False}, {"verified": True, "telegram_id": 42}])
def test_feature_access_ignores_legacy_group_gate_and_bot_failures(monkeypatch, telegram):
    monkeypatch.setenv("RSVX7_STANDALONE", "false")
    monkeypatch.setattr(tg_verify, "is_verification_enabled", AsyncMock(return_value=True))
    monkeypatch.setattr(tg_verify, "list_groups", AsyncMock(return_value=[{"_id": "group", "username": "@required"}]))
    monkeypatch.setattr(tg_verify, "_get_bot_token", AsyncMock(side_effect=RuntimeError("Bot unavailable")))
    # This is the shared guard used by chat, builder, workspace and remote AI.
    assert asyncio.run(tg_verify.require_membership({"_id": "member", "role": "user", "telegram": telegram})) is None


@pytest.mark.parametrize("change,expected", [({"status": "suspended"}, "Account suspended"), ({"must_change_password": True}, "must_change_password")])
def test_optional_linking_preserves_account_security_guards(monkeypatch, change, expected):
    user = {"_id": "member", "role": "user", "status": "active", "session_version": 0, "telegram": {}, **change}
    monkeypatch.setattr(auth, "db", SimpleNamespace(users=SimpleNamespace(find_one=AsyncMock(return_value=user))))
    token = auth.make_token("member", "user")
    request = Request({"type": "http", "path": "/api/workspace", "method": "GET", "headers": [(b"authorization", f"Bearer {token}".encode())]})
    with pytest.raises(HTTPException) as exc:
        asyncio.run(auth.current_user(request))
    assert exc.value.status_code == 403
    assert expected in str(exc.value.detail)
