import os
os.environ.setdefault('RSVX7_DATA_BACKEND','mongo')
os.environ.setdefault('MONGO_URL','mongodb://127.0.0.1:27017')
os.environ.setdefault('DB_NAME','rsvx7ai_test_remote_core')
os.environ.setdefault('RSVX7_JWT_SECRET','fixture-only-session-key-not-production-0000000')
