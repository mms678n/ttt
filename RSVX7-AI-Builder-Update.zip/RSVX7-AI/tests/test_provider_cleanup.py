"""Cancellation and hung sockets must not prevent callers releasing leases."""
import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from provider_cleanup import close_provider_stream


def test_stalled_close_is_bounded():
    async def scenario():
        class Stream:
            async def close(self):
                await asyncio.Event().wait()
        await asyncio.wait_for(close_provider_stream(Stream(), timeout=.01), timeout=.5)
    asyncio.run(scenario())


def test_close_failure_does_not_mask_original_outcome():
    async def scenario():
        class Stream:
            async def close(self):
                raise RuntimeError('broken socket')
        await close_provider_stream(Stream())
        await close_provider_stream(None)
    asyncio.run(scenario())


def test_outer_cancellation_allows_bounded_cleanup():
    async def scenario():
        import anyio
        closed = []
        class Stream:
            async def close(self):
                await anyio.sleep(.01)
                closed.append(True)
        with anyio.CancelScope() as scope:
            scope.cancel()
            await close_provider_stream(Stream())
        assert closed == [True]
    asyncio.run(scenario())
