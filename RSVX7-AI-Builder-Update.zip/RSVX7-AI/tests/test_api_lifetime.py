import asyncio, json
from types import SimpleNamespace
from unittest.mock import AsyncMock
import pytest
from tests.test_reasoning_regressions import patch_chat, chunk, FakeStream, usage, server
from tests.test_hf_chat_stream import SETTINGS, USER
import developer_api
from stream_buffer import _STREAMS, cancel_stream

class WaitingStream:
    def __init__(self):
        self.entered = asyncio.Event()
        self.close = AsyncMock()
    async def __aiter__(self):
        self.entered.set()
        yield chunk(SimpleNamespace(content='partial'))
        await asyncio.Event().wait()

async def invoke(response, disconnected, fail=False):
    scope = {'type':'http','asgi':{'version':'3.0','spec_version':'2.0'},'method':'POST','headers':[]}
    sent=[]
    async def receive():
        await disconnected.wait()
        return {'type':'http.disconnect'}
    async def send(message):
        if fail: raise OSError('client gone')
        sent.append(message)
    await response(scope, receive, send)
    return sent

def body(stream=True):
    return developer_api.Completion(model='kaligpt',messages=[{'role':'user','content':'hello'}],stream=stream)

@pytest.mark.parametrize('streaming',[True,False])
def test_disconnect_releases_and_closes(monkeypatch,streaming):
    async def scenario():
        upstream=WaitingStream();patch_chat(monkeypatch,upstream,SETTINGS)
        response=await developer_api.completion(body(streaming),USER)
        disconnected=asyncio.Event();task=asyncio.create_task(invoke(response,disconnected))
        await upstream.entered.wait();disconnected.set()
        await asyncio.wait_for(task,1)
        upstream.close.assert_awaited_once();server.release_generation.assert_awaited_once()
    asyncio.run(scenario())

@pytest.mark.parametrize('early',[False,True])
def test_disconnect_before_first_byte_and_send_failure(monkeypatch,early):
    async def scenario():
        upstream=WaitingStream();patch_chat(monkeypatch,upstream,SETTINGS)
        response=await developer_api.completion(body(),USER)
        disconnected=asyncio.Event()
        if early:disconnected.set()
        try:await asyncio.wait_for(invoke(response,disconnected,fail=not early),1)
        except (OSError,BaseExceptionGroup):
            if early:raise
        server.release_generation.assert_awaited_once()
    asyncio.run(scenario())

@pytest.mark.parametrize('streaming',[False,True])
def test_finished_response_charges_once(monkeypatch,streaming):
    async def scenario():
        upstream=FakeStream([chunk(SimpleNamespace(content='OK'),finish='stop'),chunk(usage=usage())])
        _,charge=patch_chat(monkeypatch,upstream,SETTINGS)
        response=await developer_api.completion(body(streaming),USER)
        sent=await invoke(response,asyncio.Event())
        assert sent[0]['status']==200
        charge.assert_awaited_once();server.release_generation.assert_awaited_once();upstream.close.assert_awaited_once()
    asyncio.run(scenario())

@pytest.mark.parametrize('streaming',[True,False])
def test_disconnect_during_billing_finishes_charge_before_release(monkeypatch,streaming):
    async def scenario():
        upstream=FakeStream([chunk(SimpleNamespace(content='OK'),finish='stop'),chunk(usage=usage())])
        patch_chat(monkeypatch,upstream,SETTINGS)
        entered,finish=asyncio.Event(),asyncio.Event();order=[]
        async def charge(*a,**kw):
            entered.set();await finish.wait();order.append('billed')
        async def release(*a,**kw):order.append('released')
        monkeypatch.setattr(server,'charge_user',AsyncMock(side_effect=charge))
        monkeypatch.setattr(server,'release_generation',AsyncMock(side_effect=release))
        response=await developer_api.completion(body(streaming),USER)
        disconnected=asyncio.Event();task=asyncio.create_task(invoke(response,disconnected))
        await entered.wait();disconnected.set()
        await asyncio.sleep(.02)
        assert not order and not task.done()
        finish.set();await asyncio.wait_for(task,1)
        assert order==['billed','released'];server.charge_user.assert_awaited_once()
    asyncio.run(scenario())

def test_ui_disconnect_remains_resumable(monkeypatch):
    async def scenario():
        upstream=WaitingStream();patch_chat(monkeypatch,upstream,SETTINGS)
        response=await server.chat_stream(server.ChatStreamRequest(messages=[{'role':'user','content':'hi'}]),USER)
        disconnected=asyncio.Event();task=asyncio.create_task(invoke(response,disconnected))
        await upstream.entered.wait();disconnected.set();await task
        server.release_generation.assert_not_awaited()
        for state in list(_STREAMS.values()):
            if state['user']==USER['_id']:
                cancel_stream(state);await asyncio.gather(state['task'],return_exceptions=True)
        server.release_generation.assert_awaited_once()
    asyncio.run(scenario())

def test_overflow_and_busy_errors(monkeypatch):
    from fastapi import HTTPException
    async def scenario():
        create,_=patch_chat(monkeypatch,WaitingStream(),{**SETTINGS,'context_length':50})
        result=await developer_api.completion(body(),USER)
        assert result.status_code==400
        assert json.loads(result.body)['error']['code']=='context_length_exceeded'
        create.assert_not_awaited();server.claim_generation.assert_not_awaited()
        patch_chat(monkeypatch,WaitingStream(),SETTINGS)
        monkeypatch.setattr(server,'claim_generation',AsyncMock(side_effect=HTTPException(409,'busy')))
        result=await developer_api.completion(body(),USER)
        assert result.status_code==429 and result.headers['retry-after']=='2'
        server.release_generation.assert_not_awaited()
    asyncio.run(scenario())
