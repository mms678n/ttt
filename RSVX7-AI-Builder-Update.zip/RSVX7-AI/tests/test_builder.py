"""Builder integration contracts against isolated in-memory records and model fixtures."""
import asyncio
import copy
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import jwt
import pytest
from fastapi import HTTPException
from starlette.requests import Request

os.environ.update(RSVX7_DATA_BACKEND='mongo', MONGO_URL='mongodb://127.0.0.1:27017/?serverSelectionTimeoutMS=100', DB_NAME='rsvx7_test_builder')
os.environ.setdefault('RSVX7_JWT_SECRET', 'fixture-builder-signing-key-not-for-production-000000')
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
import server, auth, workspace, builder, tokens, ai_settings
from sql_document_ops import matches_document, apply_update, apply_projection, upsert_seed

class MemoryCollection:
    def __init__(self): self.rows = {}
    async def find_one(self, query, projection=None):
        return next((apply_projection(copy.deepcopy(r), projection) for r in self.rows.values() if matches_document(r, query)), None)
    async def insert_one(self, document):
        self.rows[document['_id']] = copy.deepcopy(document)
        return SimpleNamespace(inserted_id=document['_id'])
    async def update_one(self, query, update, upsert=False):
        for key, row in self.rows.items():
            if matches_document(row, query):
                next_row = apply_update(row, update); self.rows[key] = next_row
                return SimpleNamespace(matched_count=1, modified_count=int(next_row != row))
        if upsert:
            row = apply_update(upsert_seed(query), update, is_insert=True)
            self.rows[row['_id']] = row
            return SimpleNamespace(matched_count=0, modified_count=0)
        return SimpleNamespace(matched_count=0, modified_count=0)
    async def find_one_and_update(self, query, update, upsert=False, **kwargs):
        old = await self.find_one(query); await self.update_one(query, update, upsert)
        return old
    async def delete_one(self, query):
        row = await self.find_one(query)
        if row: self.rows.pop(row['_id'])
        return SimpleNamespace(deleted_count=int(row is not None))

class MemoryDB:
    def __init__(self): self.cols = {}
    def __getattr__(self, key): return self.cols.setdefault(key, MemoryCollection())

def run(awaitable): return asyncio.run(awaitable)
USER = {'_id': 'alice', 'username': 'alice', 'role': 'user', 'status': 'active', 'session_version': 0, 'token_balance': 100000, 'monthly': {'plan':'max','remaining':0,'allowance':25000000,'starts_at':'2026-01-01T00:00:00+00:00','ends_at':'2099-01-01T00:00:00+00:00','version':'fixture-max'}}
SETTINGS = {'model': 'admin/selected-model', 'key_configured': True, 'max_completion_tokens': 8192, 'context_length': 32000, 'supported_parameters': []}
SOURCE = {'/home/project/index.html': {'type': 'file', 'content': '<h1>Original</h1>', 'isBinary': False}}

def reviewed_pipeline(files):
    return [{'type': 'pipeline', 'stage': stage, 'completed': 1, 'total': 1, 'files': files}
            for stage in ('structure', 'writing', 'reviewing')]

@pytest.fixture
def setup(monkeypatch, request):
    db = MemoryDB(); db.users.rows['alice'] = copy.deepcopy(USER)
    db.users.rows['bob'] = {**USER, '_id': 'bob', 'username': 'bob'}
    db.projects.rows['p_owned'] = {'_id': 'p_owned', 'user_id': 'alice', 'name': 'Project'}
    for module in (auth, workspace, builder, tokens, ai_settings): monkeypatch.setattr(module, 'db', db)
    monkeypatch.setattr(builder, 'current_settings', AsyncMock(return_value=SETTINGS))
    monkeypatch.setattr(builder, 'require_membership', AsyncMock())
    monkeypatch.setattr(builder, 'project_memory_prompt', AsyncMock(return_value='Private project memory'))
    builder._tasks.clear()
    if not request.node.name.startswith('test_engine_handshake_'):
        monkeypatch.setattr(builder, 'ensure_engine', AsyncMock())
    return db

async def call(path, uid=None, method='GET', body=None):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://fixture.local') as client:
        headers = {'Authorization': 'Bearer ' + auth.make_token(uid, 'user')} if uid else {}
        return await client.request(method, path, headers=headers, json=body)

def test_authentication_and_owner_isolation(setup):
    assert run(call('/api/builder/projects/p_owned')).status_code == 401
    assert run(call('/api/builder/projects/p_owned', 'bob')).status_code == 404
    assert run(call('/api/builder/projects/p_owned', 'alice')).json()['model'] == SETTINGS['model']
    response = run(call('/api/builder/internal/model', 'alice', 'POST', {'callId': 'fixture-call', 'messages': [{'role': 'user', 'content': 'hello'}]}))
    assert response.status_code == 401  # Ordinary login tokens are not engine capabilities.

def test_source_paths_revision_conflicts_and_shared_project(setup):
    path = '/api/builder/projects/p_owned/files'
    response = run(call(path, 'alice', 'PUT', {'revision': 0, 'files': SOURCE}))
    assert response.json() == {'revision': 1}
    assert setup.projects.rows['p_owned']['user_id'] == 'alice'
    assert run(call(path, 'alice', 'PUT', {'revision': 0, 'files': SOURCE})).status_code == 409
    bad = {'../escape.py': {'type': 'file', 'content': 'bad'}}
    assert run(call(path, 'alice', 'PUT', {'revision': 1, 'files': bad})).status_code == 400
    assert setup.projects.rows['p_owned']['builder']['files'] == SOURCE

def test_aliased_source_paths_cannot_silently_overwrite_a_file(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files': copy.deepcopy(SOURCE)}
    duplicate = {
        'src/App.jsx': {'type': 'file', 'content': 'first version'},
        '/home/project/src/App.jsx': {'type': 'file', 'content': 'other version'},
    }
    response = run(call('/api/builder/projects/p_owned/files', 'alice', 'PUT', {'revision': 0, 'files': duplicate}))
    assert response.status_code == 400
    saved = setup.projects.rows['p_owned']['builder']
    assert saved['files'] == SOURCE and saved['revision'] == 0

def test_approval_cannot_be_forged_and_calls_are_idempotent(setup, monkeypatch):
    plan = {'kind': 'proposal', 'title': 'A site', 'summary': 'Portfolio', 'pages': [{'name': 'Home', 'purpose': 'Profile'}], 'features': ['Contact'], 'design': 'Existing theme', 'assumptions': [], 'steps': ['Build']}
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'plan': plan, 'proposalId': 'reviewed-id', 'files': SOURCE}
    async def pending(*args): await asyncio.Event().wait()
    monkeypatch.setattr(builder, '_run_job', pending)
    async def scenario():
        body = {'requestId': 'request-one', 'revision': 0, 'action': 'approve', 'proposalId': 'forged'}
        assert (await call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)).status_code == 409
        body['proposalId'] = 'reviewed-id'
        first = await call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)
        assert first.status_code == 202
        second = await call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)
        assert second.json()['job']['id'] == first.json()['job']['id']
        assert len(builder._tasks) == 1
        await call('/api/builder/projects/p_owned/cancel', 'alice', 'POST', {})
        await asyncio.sleep(0)
        assert setup.projects.rows['p_owned']['builder']['job']['status'] == 'cancelled'
        assert setup.projects.rows['p_owned']['builder']['files'] == SOURCE
    run(scenario())

def test_membership_and_balance_gate_before_start(setup, monkeypatch):
    body = {'requestId': 'request-budget', 'revision': 0, 'text': 'Build a site'}
    monkeypatch.setattr(builder, 'require_membership', AsyncMock(side_effect=HTTPException(403, 'Membership required')))
    assert run(call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)).status_code == 403
    monkeypatch.setattr(builder, 'require_membership', AsyncMock())
    setup.users.rows['alice']['token_balance'] = 0
    assert run(call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)).status_code == 402
    assert not builder._tasks

def test_all_seven_checks_and_source_revision_required(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'revision': 2, 'files': SOURCE}
    path = '/api/builder/projects/p_owned/checks'
    checks = [{'id': id, 'status': 'passed'} for id in builder.CHECKS]
    assert run(call(path, 'alice', 'POST', {'revision': 2, 'checks': checks[:-1]})).status_code == 400
    assert run(call(path, 'alice', 'POST', {'revision': 1, 'checks': checks})).status_code == 409
    assert run(call(path, 'alice', 'POST', {'revision': 2, 'checks': checks})).json()['passed'] is True

@pytest.mark.parametrize("supports_json", [False, True])
def test_model_uses_administrator_choice_and_original_cached_token_pricing(setup, monkeypatch, supports_json):
    monkeypatch.setattr(builder, "current_settings", AsyncMock(return_value={**SETTINGS, "supported_parameters": ["response_format"] if supports_json else []}))
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id': 'job-one', 'status': 'running'}}
    captured = []
    class Stream:
        def __aiter__(self): return self.events()
        async def events(self):
            yield SimpleNamespace(usage=None, choices=[SimpleNamespace(delta=SimpleNamespace(content='Complete source', reasoning=None), finish_reason='stop')])
            yield SimpleNamespace(choices=[], usage=SimpleNamespace(prompt_tokens=100, completion_tokens=50, prompt_tokens_details=SimpleNamespace(cached_tokens=20)))
        async def close(self): pass
    async def create(**kwargs): captured.append(kwargs); return Stream()
    monkeypatch.setattr(ai_settings, 'client', SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket = jwt.encode({'sub': 'alice', 'pid': 'p_owned', 'job': 'job-one', 'aud': 'rsvx7-builder-model'}, auth.JWT_SECRET, algorithm='HS256')
    request = SimpleNamespace(headers={'Authorization': 'Bearer ' + ticket}, is_disconnected=AsyncMock(return_value=False))
    body = builder.ModelBody(callId='same-call-id', jsonMode=True, messages=[{'role': 'user', 'content': 'Build a portfolio'}])
    assert run(builder.model_call(body, request))['text'] == 'Complete source'
    assert captured[0]['model'] == SETTINGS['model']
    assert captured[0].get('response_format') == ({'type':'json_object'} if supports_json else None)
    assert setup.users.rows['alice']['token_balance'] == 100000 - 195  # (100 - 20 + 50) × existing 1.5 rate.
    assert len(setup.token_usage_history.rows) == 1
    run(builder.model_call(body, request))
    assert setup.users.rows['alice']['token_balance'] == 100000 - 195
    assert len(setup.token_usage_history.rows) == 1
    assert not setup.ai_request_leases.rows

def test_scope_ends_on_cancellation_before_model_call(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id': 'job-ended', 'status': 'cancelled'}}
    ticket = jwt.encode({'sub': 'alice', 'pid': 'p_owned', 'job': 'job-ended', 'aud': 'rsvx7-builder-model'}, auth.JWT_SECRET, algorithm='HS256')
    request = SimpleNamespace(headers={'Authorization': 'Bearer ' + ticket}, is_disconnected=AsyncMock(return_value=False))
    with pytest.raises(HTTPException) as exc: run(builder.model_call(builder.ModelBody(callId='fixture-call', messages=[{'role': 'user', 'content': 'hello'}]), request))
    assert exc.value.status_code == 403

def test_late_job_reply_cannot_replace_cancelled_source(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files': SOURCE, 'job': {'id': 'ended', 'status': 'cancelled'}}
    changed = run(builder._save_job('alice', 'p_owned', 'ended', {'files': {}}))
    assert changed.modified_count == 0
    assert setup.projects.rows['p_owned']['builder']['files'] == SOURCE

def test_disconnect_cancels_provider_and_releases_existing_wallet_lease(setup, monkeypatch):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id': 'job-one', 'status': 'running'}}
    closed = []
    class Stream:
        def __aiter__(self): return self.events()
        async def events(self):
            await asyncio.Event().wait()
            yield None
        async def close(self): closed.append(True)
    async def create(**kwargs): return Stream()
    monkeypatch.setattr(ai_settings, 'client', SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket = jwt.encode({'sub': 'alice', 'pid': 'p_owned', 'job': 'job-one', 'aud': 'rsvx7-builder-model'}, auth.JWT_SECRET, algorithm='HS256')
    request = SimpleNamespace(headers={'Authorization': 'Bearer ' + ticket}, is_disconnected=AsyncMock(return_value=True))
    with pytest.raises(HTTPException) as exc:
        run(builder.model_call(builder.ModelBody(callId='cancel-request', messages=[{'role': 'user', 'content': 'hello'}]), request))
    assert exc.value.status_code == 499
    assert closed and not setup.ai_request_leases.rows
    assert setup.users.rows['alice']['token_balance'] == USER['token_balance']

@pytest.mark.parametrize('complete', [False, True])
def test_only_terminal_reviewed_output_can_replace_source(setup, monkeypatch, complete):
    state = {**builder._empty(), 'files': SOURCE, 'messages': [{'id':'input','role':'user','content':'Build'}], 'job': {'id':'job-one','status':'running','mode':'build'}}
    setup.projects.rows['p_owned']['builder'] = copy.deepcopy(state)
    import json
    class Response:
        status_code = 200
        async def aiter_lines(self):
            for event in reviewed_pipeline({'/home/project/index.html':{'type':'file','content':'<h1>Reviewed</h1>','isBinary':False}}):
                yield json.dumps(event)
            yield json.dumps({'type':'files','files':{'/home/project/index.html':{'type':'file','content':'<h1>Reviewed</h1>','isBinary':False}},'annotation':{'type':'agentTeam','tasks':[]}})
            if complete: yield json.dumps({'type':'done'})
    class Context:
        async def __aenter__(self): return Response()
        async def __aexit__(self, *args): pass
    class Client:
        def __init__(self, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        def stream(self, *args, **kwargs): return Context()
    monkeypatch.setattr(builder.httpx, 'AsyncClient', Client)
    run(builder._run_job(USER, 'p_owned', 'job-one', state, builder.RunBody(requestId='fixture-job',revision=0,text='Build')))
    saved = setup.projects.rows['p_owned']['builder']
    assert saved['job']['status'] == ('completed' if complete else 'failed')
    assert saved['files'] == ({'/home/project/index.html':{'type':'file','content':'<h1>Reviewed</h1>','isBinary':False}} if complete else SOURCE)
    assert saved['revision'] == (1 if complete else 0)

def test_provider_limit_retains_native_safe_error_and_releases_lease(setup, monkeypatch):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id':'job-one','status':'running'}}
    class LimitError(Exception): status_code = 429
    async def create(**kwargs): raise LimitError('Upstream private response must not escape')
    monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket=jwt.encode({'sub':'alice','pid':'p_owned','job':'job-one','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request=SimpleNamespace(headers={'Authorization':'Bearer '+ticket},is_disconnected=AsyncMock(return_value=False))
    with pytest.raises(HTTPException) as exc:
        run(builder.model_call(builder.ModelBody(callId='rate-limit-test',messages=[{'role':'user','content':'Build'}]),request))
    assert exc.value.detail['code']=='provider_rate_limit'
    assert 'Upstream' not in str(exc.value.detail)
    assert not setup.ai_request_leases.rows

QUESTION_PLAN = {'kind': 'questions', 'message': '', 'questions': [
    {'id': 'goal', 'label': 'Purpose?', 'options': ['Portfolio', 'Store'], 'multiple': False},
    {'id': 'features', 'label': 'Features?', 'options': ['Booking', 'Contact', 'Blog'], 'multiple': True},
]}

def question_state(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'plan': copy.deepcopy(QUESTION_PLAN), 'proposalId': 'questions-one',
        'messages': [{'id': 'questions-one', 'role': 'assistant', 'content': '', 'plan': copy.deepcopy(QUESTION_PLAN)}]}

def question_body():
    return {'requestId': 'answers-request', 'revision': 0, 'action': 'answers', 'questionMessageId': 'questions-one',
        'answers': [{'id': 'goal', 'options': ['Portfolio']}, {'id': 'features', 'options': ['Booking', 'Contact'], 'text': 'Dark layout'}]}

def test_complete_questionnaire_and_retry_preserve_one_turn(setup, monkeypatch):
    question_state(setup)
    async def pending(*args): await asyncio.Event().wait()
    monkeypatch.setattr(builder, '_run_job', pending)
    async def scenario():
        body = question_body()
        first = await call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)
        assert first.status_code == 202, first.text
        saved = setup.projects.rows['p_owned']['builder']
        assert len(saved['messages']) == 2
        assert 'Booking، Contact، Dark layout' in saved['messages'][-1]['content']
        assert saved['messages'][-1]['questionMessageId'] == 'questions-one'
        repeated = await call('/api/builder/projects/p_owned/run', 'alice', 'POST', body)
        assert repeated.json()['job']['id'] == first.json()['job']['id']
        assert len(setup.projects.rows['p_owned']['builder']['messages']) == 2
        await call('/api/builder/projects/p_owned/cancel', 'alice', 'POST', {})
        await asyncio.sleep(0)
        retried = await call('/api/builder/projects/p_owned/run', 'alice', 'POST', {'requestId': 'retry-answers', 'revision': 0, 'action': 'retry'})
        assert retried.status_code == 202, retried.text
        assert retried.json()['job']['mode'] == 'planning'
        assert len(setup.projects.rows['p_owned']['builder']['messages']) == 2
        assert not setup.projects.rows['p_owned']['builder']['files']
        await call('/api/builder/projects/p_owned/cancel', 'alice', 'POST', {})
        await asyncio.sleep(0)
    run(scenario())

@pytest.mark.parametrize('invalid', ['missing', 'duplicate', 'unknown', 'single', 'stale'])
def test_questionnaire_rejects_incomplete_or_stale_choices_without_starting(setup, invalid):
    question_state(setup); body = question_body()
    if invalid == 'missing': body['answers'].pop()
    if invalid == 'duplicate': body['answers'][1]['id'] = 'goal'
    if invalid == 'unknown': body['answers'][1]['options'] = ['invented']
    if invalid == 'single': body['answers'][0]['options'] = ['Portfolio', 'Store']
    if invalid == 'stale': body['questionMessageId'] = 'old-question'
    response = run(call('/api/builder/projects/p_owned/run', 'alice', 'POST', body))
    assert response.status_code in (400, 409), response.text
    assert not builder._tasks
    assert len(setup.projects.rows['p_owned']['builder']['messages']) == 1

def test_custom_answers_and_legacy_multi_select_are_supported(setup):
    question_state(setup)
    state = setup.projects.rows['p_owned']['builder']
    del state['plan']['questions'][1]['multiple']
    body = question_body(); body['answers'][0] = {'id':'goal','text':'My own idea'}
    text = builder.question_answer_text(state, builder.RunBody(**body))
    assert 'My own idea' in text and 'Booking، Contact' in text

def test_a_second_tab_cannot_overwrite_new_questions_at_the_same_file_revision(setup, monkeypatch):
    question_state(setup)
    async def settings_after_newer_turn(*args):
        state = setup.projects.rows['p_owned']['builder']
        state['lastRequestId'] = 'newer-turn'
        state['proposalId'] = 'newer-questions'
        return SETTINGS
    monkeypatch.setattr(builder, 'current_settings', settings_after_newer_turn)
    response = run(call('/api/builder/projects/p_owned/run', 'alice', 'POST', question_body()))
    assert response.status_code == 409
    assert setup.projects.rows['p_owned']['builder']['proposalId'] == 'newer-questions'
    assert len(setup.projects.rows['p_owned']['builder']['messages']) == 1
    assert not builder._tasks

def test_retry_refuses_an_old_request_after_source_edit(setup):
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'revision': 2, 'files': SOURCE,
        'job': {'id': 'failed-build', 'status': 'failed', 'revision': 1},
        'messages': [{'id': 'previous-request', 'role': 'user', 'content': 'Change the page'}]}
    response = run(call('/api/builder/projects/p_owned/run', 'alice', 'POST', {'requestId':'retry-old-version','revision':2,'action':'retry'}))
    assert response.status_code == 409
    assert setup.projects.rows['p_owned']['builder']['files'] == SOURCE
    assert not builder._tasks

@pytest.mark.parametrize('ending', ['stop', 'length', 'empty_choices_usage', 'repeated_finish', 'no_finish', 'error', 'content_after_finish', 'changed_finish', 'content_filter', 'tool_calls', 'empty'])
def test_actual_sdk_stream_framing_and_terminal_contract(setup, monkeypatch, ending):
    """Exercise OpenAI's real SSE decoder with split UTF-8 bytes and accounting frames."""
    import json
    from openai import AsyncOpenAI
    setup.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id':'job-one','status':'running'}}
    closed = []
    def frame(content='', finish=None, usage=None, error=None):
        value = {'id':'fixture','object':'chat.completion.chunk','created':0,'model':SETTINGS['model'],
                 'choices':[{'index':0,'delta':{'content':content},'finish_reason':finish}]}
        if usage: value['usage'] = {'prompt_tokens':20,'completion_tokens':10,'total_tokens':30}
        if error: value['error'] = {'code':'server_error','message':'PRIVATE PROVIDER DIAGNOSTIC'}
        return 'data: ' + json.dumps(value,ensure_ascii=False) + '\n\n'
    data = ': OPENROUTER PROCESSING\n\n'
    if ending != 'empty': data += frame('مرحبا &lt;script&gt;')
    if ending in ('stop','length','empty'): data += frame(finish='length' if ending=='length' else 'stop')
    elif ending == 'empty_choices_usage':
        data += frame(finish='stop')
        data += 'data: '+json.dumps({'id':'fixture','object':'chat.completion.chunk','created':0,'model':SETTINGS['model'],'choices':[],'usage':{'prompt_tokens':20,'completion_tokens':10,'total_tokens':30}})+'\n\n'
    elif ending == 'repeated_finish': data += frame(finish='stop') + frame(finish='stop',usage=True)
    elif ending == 'error': data += frame(finish='error',error=True)
    elif ending == 'content_after_finish': data += frame(finish='stop') + frame('late source')
    elif ending == 'changed_finish': data += frame(finish='stop') + frame(finish='length')
    elif ending in ('content_filter','tool_calls'): data += frame(finish=ending)
    if ending != 'no_finish': data += 'data: [DONE]\n\n'
    class Bytes(httpx.AsyncByteStream):
        async def __aiter__(self):
            encoded = data.encode()
            # One-byte boundaries split Arabic codepoints, JSON tokens and SSE delimiters.
            for index in range(len(encoded)): yield encoded[index:index+1]
        async def aclose(self): closed.append(True)
    async def scenario():
        async def respond(request): return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Bytes())
        client = AsyncOpenAI(api_key='fixture-not-a-secret',http_client=httpx.AsyncClient(transport=httpx.MockTransport(respond)),max_retries=0)
        monkeypatch.setattr(ai_settings,'client',client)
        monkeypatch.setattr(ai_settings,'request_client',lambda value:value)
        token = jwt.encode({'sub':'alice','pid':'p_owned','job':'job-one','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
        request = SimpleNamespace(headers={'Authorization':'Bearer '+token},is_disconnected=AsyncMock(return_value=False))
        body = builder.ModelBody(callId='stream-fixture',messages=[{'role':'user','content':'Build'}])
        try:
            if ending in ('stop','length','empty_choices_usage','repeated_finish'):
                result = await builder.model_call(body,request)
                assert result['text'] == 'مرحبا &lt;script&gt;'
                assert result['finishReason'] == ('length' if ending=='length' else 'stop')
                assert len(setup.token_usage_history.rows) == 1
            else:
                with pytest.raises(HTTPException) as error: await builder.model_call(body,request)
                assert error.value.status_code == 502
                assert 'PRIVATE' not in str(error.value.detail)
                assert not setup.token_usage_history.rows
            assert not setup.ai_request_leases.rows
            assert closed
        finally: await client.close()
    run(scenario())

@pytest.mark.parametrize('sequence', ['duplicate_result','early_done','late_result','late_error','unknown','heartbeat'])
def test_engine_event_order_is_atomic(setup,monkeypatch,sequence):
    import json
    state={**builder._empty(),'files':SOURCE,'messages':[],'job':{'id':'job-one','status':'running','mode':'build'}}
    setup.projects.rows['p_owned']['builder']=copy.deepcopy(state)
    files={'type':'files','files':{'/home/project/index.html':{'type':'file','content':'new','isBinary':False}},'annotation':{'type':'studioAgentTeam','tasks':[]}}
    done={'type':'done'}
    events={'duplicate_result':[files,files,done],'early_done':[done,files], 'late_result':[files,done,files], 'late_error':[files,done,{'type':'error','message':'failed'}], 'unknown':[{'type':'oops'},files,done], 'heartbeat':[None,files,None,done,None]}[sequence]
    events = reviewed_pipeline(files['files']) + events
    class Response:
        status_code=200
        async def aiter_lines(self):
            for event in events: yield json.dumps(event) if event else ''
    class Context:
        async def __aenter__(self): return Response()
        async def __aexit__(self,*args): pass
    class Client:
        def __init__(self,**kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*args): pass
        def stream(self,*args,**kwargs): return Context()
    monkeypatch.setattr(builder.httpx,'AsyncClient',Client)
    run(builder._run_job(USER,'p_owned','job-one',state,builder.RunBody(requestId='fixture-stream',revision=0,text='Build')))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']==('completed' if sequence=='heartbeat' else 'failed')
    assert saved['files']==(files['files'] if sequence=='heartbeat' else SOURCE)

@pytest.mark.parametrize('kind',['direct','recovery','duplicate_role','unknown_role','invalid_status'])
def test_on_demand_agents_stream_into_saved_jobs_atomically(setup,monkeypatch,kind):
    import json
    state={**builder._empty(),'files':SOURCE,'messages':[],'job':{'id':'on-demand','status':'running','mode':'build'}}
    setup.projects.rows['p_owned']['builder']=copy.deepcopy(state)
    tasks=[{'role':'coder','status':'running'},{'role':'reviewer','status':'pending'}]
    events=[{'type':'agents','tasks':copy.deepcopy(tasks)}]
    if kind=='recovery':
        tasks[0]['status']='failed';tasks.append({'role':'architect','status':'running'})
        events.append({'type':'agents','tasks':copy.deepcopy(tasks)})
        tasks[2]['status']='completed';tasks.append({'role':'designer','status':'running'})
        events.append({'type':'agents','tasks':copy.deepcopy(tasks)})
    elif kind=='duplicate_role':tasks.append({'role':'coder','status':'running'})
    elif kind=='unknown_role':tasks.append({'role':'outsider','status':'running'})
    elif kind=='invalid_status':tasks[0]['status']='pretend_success'
    if kind in ('direct','recovery'):
        for task in tasks:task['status']='completed'
    events += [{'type':'agents','tasks':tasks}, *reviewed_pipeline({'/home/project/index.html':{'type':'file','content':'fixed','isBinary':False}}),
        {'type':'files','files':{'/home/project/index.html':{'type':'file','content':'fixed','isBinary':False}},'annotation':{'type':'studioAgentTeam','tasks':tasks}},
        {'type':'done'}]
    class Response:
        status_code=200
        async def aiter_lines(self):
            for event in events:yield json.dumps(event)
    class Context:
        async def __aenter__(self):return Response()
        async def __aexit__(self,*args):pass
    class Client:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        def stream(self,*args,**kwargs):return Context()
    monkeypatch.setattr(builder.httpx,'AsyncClient',Client)
    run(builder._run_job(USER,'p_owned','on-demand',state,builder.RunBody(requestId='agents-stream',revision=0,text='Build')))
    saved=setup.projects.rows['p_owned']['builder']
    if kind in ('direct','recovery'):
        assert saved['job']['status']=='completed'
        assert saved['files']['/home/project/index.html']['content']=='fixed'
        assert saved['job']['agents']==tasks
    else:
        assert saved['job']['status']=='failed'
        assert saved['files']==SOURCE

@pytest.mark.parametrize('advisory',[False,True])
def test_closed_empty_advice_is_optional_but_empty_code_remains_invalid(setup,monkeypatch,advisory):
    setup.projects.rows['p_owned']['builder']={**builder._empty(),'job':{'id':'advice-job','status':'running'}}
    closed=[]
    class Stream:
        def __aiter__(self):return self.events()
        async def events(self):
            yield SimpleNamespace(usage=None,choices=[SimpleNamespace(delta=SimpleNamespace(content='',reasoning=None),finish_reason='stop')])
            yield SimpleNamespace(choices=[],usage=SimpleNamespace(prompt_tokens=100,completion_tokens=50,prompt_tokens_details=SimpleNamespace(cached_tokens=20)))
        async def close(self):closed.append(True)
    async def create(**kwargs):return Stream()
    monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket=jwt.encode({'sub':'alice','pid':'p_owned','job':'advice-job','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request=SimpleNamespace(headers={'Authorization':'Bearer '+ticket},is_disconnected=AsyncMock(return_value=False))
    body=builder.ModelBody(callId='optional-advice',advisory=advisory,messages=[{'role':'user','content':'Inspect diagnostic'}])
    if advisory:
        result=run(builder.model_call(body,request))
        assert result=={'text':'','finishReason':'stop'}
        assert setup.users.rows['alice']['token_balance']==100000-195
    else:
        with pytest.raises(HTTPException) as error:run(builder.model_call(body,request))
        assert error.value.status_code==502
        assert setup.users.rows['alice']['token_balance']==100000
    assert closed and not setup.ai_request_leases.rows

@pytest.mark.parametrize('plan,status',[('free',403),('pro',200),('max',200)])
def test_builder_read_apis_enforce_monthly_entitlement(setup,plan,status):
    import memberships
    setup.users.rows['alice']['monthly']={**memberships.period(plan,memberships.utcnow()),'remaining':0}
    assert run(call('/api/builder/projects/p_owned','alice')).status_code==status

@pytest.mark.parametrize('model,deep,efforts,expected',[
    ('deepseek/deepseek-v4-flash',False,['xhigh','high','none'],None),
    ('deepseek/deepseek-v4-flash',True,['xhigh','high','none'],'high'),
    ('deepseek/deepseek-v4.1-flash',True,['max','high','low','none'],'low'),
    ('deepseek/deepseek-v4-flash',True,[],None)])
def test_deepseek_output_budget_and_supported_reasoning_effort(setup,monkeypatch,model,deep,efforts,expected):
    calls=[]
    monkeypatch.setattr(builder,'current_settings',AsyncMock(return_value={**SETTINGS,'model':model,'context_length':131072,
        'max_completion_tokens':65536,'supported_parameters':['reasoning','reasoning_effort','response_format'],
        'reasoning':{'mandatory':False,'supported_efforts':efforts}}))
    setup.users.rows['alice']['role']='admin'
    setup.projects.rows['p_owned']['builder']={**builder._empty(),'job':{'id':'deepseek-job','status':'running'}}
    class Stream:
        async def close(self):pass
        def __aiter__(self):return self.events()
        async def events(self):
            yield SimpleNamespace(usage=None,choices=[SimpleNamespace(delta=SimpleNamespace(content='{"actions":[]}',reasoning=None),finish_reason='stop')])
    async def create(**kwargs):calls.append(kwargs);return Stream()
    monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket=jwt.encode({'sub':'alice','pid':'p_owned','job':'deepseek-job','deepThink':deep,'aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request=SimpleNamespace(headers={'Authorization':'Bearer '+ticket},is_disconnected=AsyncMock(return_value=False))
    run(builder.model_call(builder.ModelBody(callId='deepseek-test',jsonMode=True,messages=[{'role':'user','content':'Return JSON file actions'}]),request))
    assert calls[0]['max_tokens']==32768
    assert calls[0]['response_format']=={'type':'json_object'}
    assert calls[0]['extra_body']['reasoning']['enabled']==deep
    assert calls[0]['extra_body']['reasoning'].get('effort')==expected
