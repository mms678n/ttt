import base64,gzip,json,runpy,subprocess,sys,zlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts/install_tool_compat.py'

def stage(root):
    state=runpy.run_path(str(SCRIPT))
    baseline=json.loads(gzip.decompress((ROOT/'tests/fixtures/tools_v20.json.gz').read_bytes()))
    # The frozen requirements are read from the older upgrade's native fixture
    # below; compatibility-only edits are reversed from the current lock files.
    for name in state['FILES']:
        if name=='backend/tool_compat.py':continue
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(baseline.get(name,(ROOT/name).read_text()))
    patch=zlib.decompress(base64.b85decode(state['PAYLOAD']))
    # Reconstruct the pre-update dependency files without modifying the server.
    lines=patch.decode().splitlines(True);segments=[];segment=[]
    for line in lines:
        if line.startswith('--- '):
            if segment:segments.append(''.join(segment))
            segment=[]
        segment.append(line)
    if segment:segments.append(''.join(segment))
    deps=''.join(s for s in segments if s.startswith('--- a/backend/requirements'))
    subprocess.run(['git','apply','--reverse','-'],input=deps.encode(),cwd=root,check=True,capture_output=True)
    deploy=root/'deploy';deploy.mkdir();(deploy/'compose.selfhost.yaml').write_text('fixture')
    subprocess.run(['git','init','-q',str(root)],check=True)
    server=root/'backend/server.py'
    server.write_text('# local provider logging stays\n'+server.read_text().replace('if req.dark_mode:', 'if False:  # removed Dark Mode'))
    (root/'.env.selfhost').write_text('fixture-private-setting')
    return state

def run(root,*args):
    return subprocess.run([sys.executable,str(SCRIPT),'--project',str(root),*args],capture_output=True,text=True)

def test_compat_installer_preserves_dark_removal_local_logging_and_environment(tmp_path):
    state=stage(tmp_path)
    before=(tmp_path/'backend/server.py').read_bytes()
    result=run(tmp_path,'--check');assert result.returncode==0,result.stdout+result.stderr
    assert (tmp_path/'backend/server.py').read_bytes()==before
    result=run(tmp_path);assert result.returncode==0,result.stdout+result.stderr
    server=(tmp_path/'backend/server.py').read_text()
    assert server.startswith('# local provider logging stays')
    assert 'if False:  # removed Dark Mode' in server
    assert 'compatibility.wrap_client' in server
    assert (tmp_path/'.env.selfhost').read_text()=='fixture-private-setting'
    assert (tmp_path/'backend/tool_compat.py').read_bytes()==(ROOT/'backend/tool_compat.py').read_bytes()
    assert run(tmp_path).returncode==0
    backups=list((tmp_path/'.rsvx7-backups').glob('tool-compat-*/original/backend/server.py'))
    assert len(backups)==1 and backups[0].read_bytes()==before

def test_conflicting_source_aborts_without_partial_changes(tmp_path):
    state=stage(tmp_path)
    p=tmp_path/'backend/server.py';p.write_text(p.read_text().replace("'tools' not in (settings.get('supported_parameters') or [])", "'changed_tools' not in (settings.get('supported_parameters') or [])"))
    before={name:(tmp_path/name).read_bytes() for name in state['FILES'] if (tmp_path/name).exists()}
    result=run(tmp_path)
    assert result.returncode!=0
    assert not (tmp_path/'backend/tool_compat.py').exists()
    assert all((tmp_path/name).read_bytes()==data for name,data in before.items())
