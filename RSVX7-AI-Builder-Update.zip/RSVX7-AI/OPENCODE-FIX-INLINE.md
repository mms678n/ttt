# RSVX7 OpenCode fix

The API cancels its producer on disconnect, but lets completed responses finish billing.
UI reconnection, billing access controls and the account lease remain in place.
Context overflow is a structured400 error; legitimate account concurrency gets429 with Retry-After.

Run block1 on the VPS and block2 on the OpenCode device.

```bash
(
set -eu
cd ~/j/RSVX7-AI
python3 - <<'PY'
import ast
import shutil
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
paths = ['backend/server.py', 'backend/developer_api.py', 'backend/api_lifetime.py']
original = {n: (root / n).read_text() if (root / n).exists() else None for n in paths}
if any(original[n] is None for n in paths[:2]):
    raise SystemExit('Run inside ~/j/RSVX7-AI')
updated = dict(original)

def replace_once(text, old, new):
    if text.count(new) == 1:
        return text
    if text.count(old) == 1:
        return text.replace(old, new, 1)
    raise SystemExit('Source differs from reviewed version; no files changed.')

module = '''"""HTTP API owns its generation, unlike reconnectable web chat."""
import asyncio
from contextlib import suppress
import anyio
from fastapi import HTTPException
from starlette.responses import JSONResponse, Response
from stream_buffer import cancel_stream

async def close_generation(source):
    with anyio.CancelScope(shield=True):
        state = getattr(source, '_rsvx7_stream_state', None)
        if state is not None:
            if not state.get('finalizing'):
                cancel_stream(state)
            with suppress(asyncio.CancelledError):
                await asyncio.shield(state['task'])
        await source.body_iterator.aclose()

class APIResponse(Response):
    def __init__(self, source, *, stream=None, collect=None):
        super().__init__()
        self.source, self.stream, self.collect = source, stream, collect

    async def __call__(self, scope, receive, send):
        try:
            if self.stream is not None:
                await self.stream(scope, receive, send)
            else:
                async with anyio.create_task_group() as group:
                    async def disconnect():
                        while True:
                            if (await receive())['type'] == 'http.disconnect':
                                group.cancel_scope.cancel()
                                return
                    group.start_soon(disconnect)
                    try:
                        response = JSONResponse(await self.collect())
                    except HTTPException as error:
                        response = JSONResponse({'detail': error.detail},
                            status_code=error.status_code, headers=error.headers)
                    await response(scope, receive, send)
                    group.cancel_scope.cancel()
        finally:
            await close_generation(self.source)
'''
if original[paths[2]] not in (None, module):
    raise SystemExit('api_lifetime.py differs; no files changed.')
updated[paths[2]] = module
s = updated[paths[0]]
s = replace_once(s,
    '    return _sse_response(follow(get_stream(sid, user["_id"])))',
    '''    state = get_stream(sid, user["_id"])
    response = _sse_response(follow(state))
    response._rsvx7_stream_state = state
    return response''')
s = replace_once(s,
    '        raise HTTPException(413, "المحادثة أكبر من نافذة سياق النموذج. ابدأ محادثة جديدة أو قلّل المرفقات.")',
    '''        raise HTTPException(400, {
            "code": "context_length_exceeded", "type": "invalid_request_error",
            "message": f"Prompt including system instructions and tools needs about {est_prompt} tokens; model context is {settings['context_length']}. Reduce the prompt/tools or select a model with a larger verified context.",
            "param": "messages", "context_length": int(settings["context_length"]),
            "estimated_prompt_tokens": est_prompt,
        })''')
s = replace_once(s,
    '            tool_output.finish(finish_reason)\n',
    '            tool_output.finish(finish_reason)\n            state["finalizing"] = True  # Finish billing even after HTTP disconnect.\n')
updated[paths[0]] = s
s = updated[paths[1]]
s = replace_once(s,
    '    source = await server.chat_stream(request, user)',
    '''    from api_lifetime import APIResponse
    try:
        source = await server.chat_stream(request, user)
    except HTTPException as error:
        if isinstance(error.detail, dict) and error.detail.get('code') == 'context_length_exceeded':
            return JSONResponse({'error': error.detail}, status_code=400)
        if error.status_code == 409:
            return JSONResponse({'error': {'code': 'generation_in_progress',
                'type': 'rate_limit_error', 'message': 'An account generation is still active. Stop it or wait for completion.'}},
                status_code=429, headers={'Retry-After': '2'})
        raise''')
s = replace_once(s,
    '        return server._sse_response(stream_response())',
    '        return APIResponse(source, stream=server._sse_response(stream_response()))')
if '    async def collect_response():' not in s:
    anchor = '    text, finish, usage, reasoning = [], None, None, []'
    if s.count(anchor) != 1 or not s.rstrip().endswith("'finish_reason': finish}], 'usage': usage}"):
        raise SystemExit('Unexpected API collector; no files changed.')
    start = s.index(anchor)
    s = s[:start] + '    async def collect_response():\n' + ''.join(
        '    ' + line if line.strip() else line for line in s[start:].splitlines(keepends=True)
    ) + '\n    return APIResponse(source, collect=collect_response)\n'
updated[paths[1]] = s
for name, text in updated.items():
    ast.parse(text, filename=name)
changed = [n for n in paths if original[n] != updated[n]]
if not changed:
    print('Patch already installed.')
    raise SystemExit(0)
backup = root / '.rsvx7-backups' / ('api-lifetime-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
backup.mkdir(parents=True, mode=0o700)
for name in changed:
    if original[name] is not None:
        target = backup / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, target)
try:
    for name in changed:
        (root / name).write_text(updated[name])
except BaseException:
    for name in changed:
        if original[name] is None:
            (root / name).unlink(missing_ok=True)
        else:
            shutil.copy2(backup / name, root / name)
    raise
print('Patch installed. Backup:', backup)
PY
export RSVX7_SELFHOST_ENV="$PWD/.env.selfhost"
docker compose -p rsvx7 --env-file "$RSVX7_SELFHOST_ENV" -f deploy/compose.selfhost.yaml up -d --build --no-deps --wait --wait-timeout 300 app
)
```

```bash
(
set -eu
python3 - <<'PY'
import json
import os
import shutil
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

folder = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'opencode'
path = folder / 'opencode.json'
config = json.loads(path.read_text())
key = config.get('provider', {}).get('rsvx7', {}).get('options', {}).get('apiKey', '').strip()
if not key or key.startswith('{'):
    raise SystemExit('No literal RSVX7 API key in ' + str(path))
base = 'https://rsvx7-ai.com/api/v1'
request = urllib.request.Request(base + '/models', headers={'Authorization': 'Bearer ' + key})
with urllib.request.urlopen(request, timeout=30) as response:
    rows = json.load(response)['data']
models = {}
for row in rows:
    name = row.get('id')
    if name not in ('kaligpt', 'deepdark', 'rsvx7-ai'):
        continue
    context, output = row.get('context_length'), row.get('max_output_tokens')
    if not isinstance(context, int) or not isinstance(output, int) or context < 4096 or output < 1:
        raise SystemExit('Server did not return usable limits: ' + str(name))
    models[name] = {'name': name, 'limit': {'context': context, 'output': min(2048, output, context // 4)}}
if not models:
    raise SystemExit('No accessible models returned.')
selected = 'kaligpt' if 'kaligpt' in models else next(iter(models))
patch = {
    '$schema': 'https://opencode.ai/config.json',
    'provider': {'rsvx7': {'npm': '@ai-sdk/openai-compatible', 'name': 'RSVX7-AI',
        'options': {'baseURL': base, 'apiKey': key}, 'models': models}},
    'model': 'rsvx7/' + selected,
    'small_model': 'rsvx7/' + selected,
    'compaction': {'auto': True, 'prune': True, 'reserved': 1024},
    'agent': {'rsvx7-lite': {
        'description': 'Coding with a small context window', 'mode': 'primary',
        'prompt': 'You are a coding assistant. Follow the user language. Inspect relevant files, make focused changes, and verify them. Read small file ranges. Use tools only when needed and never claim unobserved results. Keep responses concise.',
        'permission': {'*': 'deny', 'read': 'allow', 'edit': 'ask', 'bash': 'ask', 'glob': 'allow', 'grep': 'allow'},
    }},
}
target = folder / 'rsvx7-fixed.json'
if target.exists():
    backup = target.with_name(target.name + '.backup-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    shutil.copy2(target, backup)
    backup.chmod(0o600)
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
os.fchmod(fd, 0o600)
with os.fdopen(fd, 'w') as file:
    json.dump(patch, file, ensure_ascii=False, indent=2)
    file.write('\n')
print('Saved:', target)
for name, model in models.items():
    print(name, model['limit'])
PY
export PATH="$HOME/.opencode/bin:$PATH"
cd ~/rsvx7-test
OPENCODE_CONFIG_CONTENT="$(cat "${XDG_CONFIG_HOME:-$HOME/.config}/opencode/rsvx7-fixed.json")" opencode --agent rsvx7-lite
)
```

The lightweight agent retains bash, read, write, edit, glob and grep. Other tools are disabled for this agent.
The2048 reply cap is client-specific; platform-wide caps are unchanged.
Validation:139 backend regressions; OpenCode1.19.5 exercised with a fixture provider through the real API, including a read tool/result roundtrip. No live Hugging Face call or VPS deployment was performed.
Actual model tool-call reliability and availability remain provider/model dependent.
