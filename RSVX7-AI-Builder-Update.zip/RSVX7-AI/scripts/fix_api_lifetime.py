import ast
import shutil
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
paths = ['backend/server.py', 'backend/developer_api.py', 'backend/api_lifetime.py']
original = {n: (root / n).read_text() if (root / n).exists() else None for n in paths}
if any(original[n] is None for n in paths[:2]):
    raise SystemExit('Run inside ~/j/RSVX7-AI')
updated = dict(original)

def replace_once(text, old, new):
    if text.count(new) == 1:
        return text
    if text.count(old) == 1:
        return text.replace(old, new, 1)
    raise SystemExit('Source differs from reviewed version; no files changed.')

module = '''"""HTTP API owns its generation, unlike reconnectable web chat."""
import asyncio
from contextlib import suppress
import anyio
from fastapi import HTTPException
from starlette.responses import JSONResponse, Response
from stream_buffer import cancel_stream

async def close_generation(source):
    with anyio.CancelScope(shield=True):
        state = getattr(source, '_rsvx7_stream_state', None)
        if state is not None:
            if not state.get('finalizing'):
                cancel_stream(state)
            with suppress(asyncio.CancelledError):
                await asyncio.shield(state['task'])
        await source.body_iterator.aclose()

class APIResponse(Response):
    def __init__(self, source, *, stream=None, collect=None):
        super().__init__()
        self.source, self.stream, self.collect = source, stream, collect

    async def __call__(self, scope, receive, send):
        try:
            if self.stream is not None:
                await self.stream(scope, receive, send)
            else:
                async with anyio.create_task_group() as group:
                    async def disconnect():
                        while True:
                            if (await receive())['type'] == 'http.disconnect':
                                group.cancel_scope.cancel()
                                return
                    group.start_soon(disconnect)
                    try:
                        response = JSONResponse(await self.collect())
                    except HTTPException as error:
                        response = JSONResponse({'detail': error.detail},
                            status_code=error.status_code, headers=error.headers)
                    await response(scope, receive, send)
                    group.cancel_scope.cancel()
        finally:
            await close_generation(self.source)
'''
if original[paths[2]] not in (None, module):
    raise SystemExit('api_lifetime.py differs; no files changed.')
updated[paths[2]] = module
s = updated[paths[0]]
s = replace_once(s,
    '    return _sse_response(follow(get_stream(sid, user["_id"])))',
    '''    state = get_stream(sid, user["_id"])
    response = _sse_response(follow(state))
    response._rsvx7_stream_state = state
    return response''')
s = replace_once(s,
    '        raise HTTPException(413, "المحادثة أكبر من نافذة سياق النموذج. ابدأ محادثة جديدة أو قلّل المرفقات.")',
    '''        raise HTTPException(400, {
            "code": "context_length_exceeded", "type": "invalid_request_error",
            "message": f"Prompt including system instructions and tools needs about {est_prompt} tokens; model context is {settings['context_length']}. Reduce the prompt/tools or select a model with a larger verified context.",
            "param": "messages", "context_length": int(settings["context_length"]),
            "estimated_prompt_tokens": est_prompt,
        })''')
s = replace_once(s,
    '            tool_output.finish(finish_reason)\n',
    '            tool_output.finish(finish_reason)\n            state["finalizing"] = True  # Finish billing even after HTTP disconnect.\n')
updated[paths[0]] = s
s = updated[paths[1]]
s = replace_once(s,
    '    source = await server.chat_stream(request, user)',
    '''    from api_lifetime import APIResponse
    try:
        source = await server.chat_stream(request, user)
    except HTTPException as error:
        if isinstance(error.detail, dict) and error.detail.get('code') == 'context_length_exceeded':
            return JSONResponse({'error': error.detail}, status_code=400)
        if error.status_code == 409:
            return JSONResponse({'error': {'code': 'generation_in_progress',
                'type': 'rate_limit_error', 'message': 'An account generation is still active. Stop it or wait for completion.'}},
                status_code=429, headers={'Retry-After': '2'})
        raise''')
s = replace_once(s,
    '        return server._sse_response(stream_response())',
    '        return APIResponse(source, stream=server._sse_response(stream_response()))')
if '    async def collect_response():' not in s:
    anchor = '    text, finish, usage, reasoning = [], None, None, []'
    if s.count(anchor) != 1 or not s.rstrip().endswith("'finish_reason': finish}], 'usage': usage}"):
        raise SystemExit('Unexpected API collector; no files changed.')
    start = s.index(anchor)
    s = s[:start] + '    async def collect_response():\n' + ''.join(
        '    ' + line if line.strip() else line for line in s[start:].splitlines(keepends=True)
    ) + '\n    return APIResponse(source, collect=collect_response)\n'
updated[paths[1]] = s
for name, text in updated.items():
    ast.parse(text, filename=name)
changed = [n for n in paths if original[n] != updated[n]]
if not changed:
    print('Patch already installed.')
    raise SystemExit(0)
backup = root / '.rsvx7-backups' / ('api-lifetime-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
backup.mkdir(parents=True, mode=0o700)
for name in changed:
    if original[name] is not None:
        target = backup / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, target)
try:
    for name in changed:
        (root / name).write_text(updated[name])
except BaseException:
    for name in changed:
        if original[name] is None:
            (root / name).unlink(missing_ok=True)
        else:
            shutil.copy2(backup / name, root / name)
    raise
print('Patch installed. Backup:', backup)
