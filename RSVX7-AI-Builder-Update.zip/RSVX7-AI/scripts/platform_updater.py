#!/usr/bin/env python3
"""Root-owned GitHub updater. Browser requests carry no commands or settings."""
import argparse
from datetime import datetime, timezone
import fcntl
import getpass
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import threading
import time

BASE = Path('/opt/rsvx7-updater')
STAGES = ('fetch', 'validate', 'build', 'restart', 'verify')

def write_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value))
    temp.chmod(0o644)
    temp.replace(path)

def status(config, result, stage, commit=None):
    write_json(BASE / 'control/status.json', dict(status=result, stage=stage,
        repository=config['repository'], branch=config['branch'], commit=commit,
        updated_at=datetime.now(timezone.utc).isoformat()))

def run(args, *, env=None, capture=False, timeout=1800):
    # Raw output remains root-only. Never returned through the application API.
    with (BASE / 'update.log').open('ab') as log:
        return subprocess.run(args, env=env, stdout=subprocess.PIPE if capture else log,
            stderr=log, check=True, timeout=timeout).stdout

def git_env():
    env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GIT_CONFIG_COUNT='4',
        GIT_CONFIG_KEY_0='credential.helper', GIT_CONFIG_VALUE_0='',
        GIT_CONFIG_KEY_1='credential.helper',
        GIT_CONFIG_VALUE_1='!python3 /opt/rsvx7-updater/platform_updater.py credential',
        GIT_CONFIG_KEY_2='credential.useHttpPath', GIT_CONFIG_VALUE_2='true',
        GIT_CONFIG_KEY_3='http.followRedirects', GIT_CONFIG_VALUE_3='false')
    return env

def credential():
    import sys
    if sys.argv[-1] != 'get':
        return
    fields = dict(line.rstrip('\n').split('=', 1) for line in sys.stdin if '=' in line)
    config = json.loads((BASE / 'config.json').read_text())
    if fields.get('protocol') == 'https' and fields.get('host') == 'github.com' and fields.get('path') == config['repository'] + '.git':
        print('username=x-access-token')
        print('password=' + (BASE / 'token').read_text().strip())

def export_tree(repository, commit, destination):
    archive = run(['git', '-C', str(repository), 'archive', commit], capture=True)
    destination.mkdir(mode=0o700)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar.getmembers():
            name = Path(member.name)
            if name.is_absolute() or '..' in name.parts or not (member.isfile() or member.isdir()):
                raise ValueError('Unsafe archive entry')
        tar.extractall(destination, filter='data')
    required = ('Dockerfile.selfhost', 'deploy/compose.selfhost.yaml', 'backend/server.py',
                'frontend/build/index.html', 'frontend/build/asset-manifest.json', 'builder/dist/service.mjs')
    if not all((destination / p).is_file() for p in required):
        raise ValueError('Repository must include production builds')
    build = destination / 'frontend/build'
    manifest = json.loads((build / 'asset-manifest.json').read_text())
    for asset in set(manifest['files'].values()) | set(manifest['entrypoints']):
        target = (build / asset.lstrip('/')).resolve()
        if not target.is_relative_to(build.resolve()) or not target.is_file():
            raise ValueError('Missing production asset')

def compose(source, config, *args):
    # Preserve the original private env and fixed Compose project/volumes.
    env = dict(os.environ, RSVX7_SELFHOST_ENV=config['env_file'],
               RSVX7_RELEASE_ID=source.name, RSVX7_UPDATE_CONTROL=str(BASE / 'control'))
    settings = dict(x.split('=', 1) for x in Path(config['env_file']).read_text().splitlines() if '=' in x)
    command = ['docker', 'compose', '-p', 'rsvx7', '--env-file', config['env_file'],
               '-f', str(source / 'deploy/compose.selfhost.yaml')]
    if settings.get('AI_PROVIDER') == 'local': command += ['--profile', 'local']
    return run(command + list(args), env=env)

def verify(source, config):
    probe = ('import json,urllib.request;'
        'd=json.load(urllib.request.urlopen("http://127.0.0.1:3000/readyz",timeout=4));'
        'assert d.get("release")=='+repr(source.name)+';'
        'assert urllib.request.urlopen("http://127.0.0.1:3000/",timeout=4).status==200')
    for attempt in range(60):
        try:
            compose(source, config, 'exec', '-T', 'app', 'python', '-c', probe)
            return
        except subprocess.CalledProcessError:
            if attempt == 59: raise
            time.sleep(5)

def update(config):
    repository = BASE / 'repository'
    source = None
    activated = False
    old = Path(config['source'])
    try:
        status(config, 'running', 'fetch')
        env = git_env()
        if not repository.exists():
            run(['git', 'init', '--bare', str(repository)], env=env)
        run(['git', '-C', str(repository), 'fetch', '--depth=1', '--no-tags',
             'https://github.com/' + config['repository'] + '.git', 'refs/heads/' + config['branch']], env=env)
        commit = run(['git', '-C', str(repository), 'rev-parse', 'FETCH_HEAD'], capture=True).decode().strip()
        if not re.fullmatch('[0-9a-f]{40,64}', commit): raise ValueError('Invalid commit')
        if commit == config.get('commit'):
            status(config, 'completed', 'current', commit)
            return
        status(config, 'running', 'validate', commit)
        source = BASE / 'releases' / (commit[:12] + '-' + str(time.time_ns()))
        export_tree(repository, commit, source)
        status(config, 'running', 'build', commit)
        compose(source, config, 'build', 'app')
        status(config, 'running', 'restart', commit)
        activated = True
        compose(source, config, 'up', '-d')
        status(config, 'running', 'verify', commit)
        verify(source, config)
        config.update(source=str(source), commit=commit)
        write_json(BASE / 'config.json', config)
        (BASE / 'config.json').chmod(0o600)
        status(config, 'completed', 'ready', commit)
    except Exception:
        if activated:
            try:
                compose(old, config, 'build', 'app')
                compose(old, config, 'up', '-d')
                verify(old, config)
                status(config, 'failed', 'restored', config.get('commit'))
                return
            except Exception:
                status(config, 'failed', 'restore_failed', config.get('commit'))
                return
        status(config, 'failed', 'failed', config.get('commit'))

def worker():
    with (BASE / 'worker.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        def heartbeat():
            while True:
                (BASE / 'control/heartbeat').touch()
                time.sleep(5)
        threading.Thread(target=heartbeat, daemon=True).start()
        config = json.loads((BASE / 'config.json').read_text())
        # A host restart during update requires explicit retry, not false success.
        previous = json.loads((BASE / 'control/status.json').read_text())
        request = BASE / 'control/requests/update'
        if previous.get('status') == 'running':
            request.unlink(missing_ok=True)
            status(config, 'failed', 'interrupted', config.get('commit'))
        while True:
            if request.exists():
                # Keep the marker until completion to coalesce all concurrent clicks.
                try: update(config)
                finally: request.unlink(missing_ok=True)
            time.sleep(2)

def install(args):
    if os.geteuid() != 0: raise SystemExit('Run as root.')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', args.repository): raise SystemExit('Use OWNER/REPOSITORY.')
    if args.branch.startswith('-') or subprocess.run(['git', 'check-ref-format', '--branch', args.branch], stdout=subprocess.DEVNULL).returncode:
        raise SystemExit('Invalid branch.')
    source = Path(__file__).resolve().parents[1]
    environment = Path(args.env_file).resolve()
    if not environment.is_file(): raise SystemExit('Create .env.selfhost first.')
    if (BASE / 'config.json').exists(): raise SystemExit('Already configured. Edit root-only /opt/rsvx7-updater/config.json to change repository.')
    token = getpass.getpass('GitHub fine-grained token (Contents: read-only, selected repository): ').strip()
    if not token or any(c.isspace() for c in token): raise SystemExit('Invalid token.')
    BASE.mkdir(mode=0o711, exist_ok=True)
    BASE.chmod(0o711)
    for name in ('releases',):
        (BASE / name).mkdir(mode=0o700, exist_ok=True)
    control = BASE / 'control'; control.mkdir(mode=0o755, exist_ok=True); control.chmod(0o755)
    requests = control / 'requests'; requests.mkdir(mode=0o700, exist_ok=True)
    os.chown(requests, 10001, 10001); requests.chmod(0o700)
    for name, content in [('token', token), ('update.log', '')]:
        (BASE / name).write_text(content); (BASE / name).chmod(0o600)
    config = dict(repository=args.repository, branch=args.branch, source=str(source), env_file=str(environment))
    write_json(BASE / 'config.json', config); (BASE / 'config.json').chmod(0o600)
    shutil.copyfile(__file__, BASE / 'platform_updater.py'); (BASE / 'platform_updater.py').chmod(0o700)
    status(config, 'idle', 'ready')
    unit = '[Unit]\nDescription=RSVX7 GitHub updater\nAfter=network-online.target docker.service\nWants=network-online.target\n[Service]\nType=simple\nUser=root\nUMask=0077\nExecStart=/usr/bin/python3 /opt/rsvx7-updater/platform_updater.py worker\nRestart=on-failure\nRestartSec=5\n[Install]\nWantedBy=multi-user.target\n'
    Path('/etc/systemd/system/rsvx7-updater.service').write_text(unit)
    run(['systemctl', 'daemon-reload'])
    run(['systemctl', 'enable', '--now', 'rsvx7-updater.service'])
    print('Updater installed. Re-run sh deploy/install-selfhost.sh once, then use Admin > Servers > Update platform.')

def request():
    target = BASE / 'control/requests/update'
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.close(fd)
    print('Update queued. Check Admin > Servers or systemctl status rsvx7-updater.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    setup = sub.add_parser('install'); setup.add_argument('--repository', required=True); setup.add_argument('--branch', default='main'); setup.add_argument('--env-file', default='.env.selfhost')
    sub.add_parser('worker'); sub.add_parser('request'); helper = sub.add_parser('credential'); helper.add_argument('operation', nargs='?')
    args = parser.parse_args()
    if args.command == 'install': install(args)
    elif args.command == 'worker': worker()
    elif args.command == 'request': request()
    else: credential()
