#!/usr/bin/env python3
"""Create a private Compose .env; never overwrite existing credentials."""
import os
import secrets
from pathlib import Path

root = Path(__file__).resolve().parent.parent
target = root / ".env"
content = (root / ".env.example").read_text()
content = content.replace("REPLACE_WITH_RANDOM_HEX_PASSWORD", secrets.token_hex(24))
content = content.replace("REPLACE_WITH_RANDOM_HEX_SECRET_AT_LEAST_32_CHARACTERS", secrets.token_hex(32))
content = content.replace("OWNER_INITIAL_PASSWORD=\n", "OWNER_INITIAL_PASSWORD=" + secrets.token_urlsafe(24) + "\n")
try:
    descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
except FileExistsError:
    raise SystemExit("Existing .env preserved. Edit it privately if needed.")
with os.fdopen(descriptor, "w", encoding="utf-8") as file:
    file.write(content)
print("Private .env created with new random secrets; no secret values were printed.")
print("Configure optional provider keys privately before enabling their features.")
