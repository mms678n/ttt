import json, sys, time, httpx

API, TOKEN, PERSONA, DEEP = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] == "1"
PROMPT = sys.argv[5] if len(sys.argv) > 5 else "اكتب فقرة من 120 كلمة عن تاريخ التشفير"
H = {"Authorization": "Bearer " + TOKEN}
state = {"sid": None, "n": 0, "text": "", "reasoning": "", "done": False}
t0 = time.time()


def consume(resp):
    print("conn", resp.status_code, round(time.time() - t0, 1))
    buf = ""
    try:
        for chunk in resp.iter_text():
            buf += chunk
            lines = buf.split("\n"); buf = lines.pop()
            for line in lines:
                if not line.startswith("data:"):
                    continue
                state["n"] += 1
                payload = line[5:].strip()
                if payload == "[DONE]":
                    state["done"] = True; return
                o = json.loads(payload)
                if "stream" in o: state["sid"] = o["stream"]["id"]
                state["text"] += o.get("t", ""); state["reasoning"] += o.get("r", "")
                if "error" in o or "finish" in o: print("evt", round(time.time() - t0, 1), {k: o[k] for k in ("error", "finish") if k in o})
    except httpx.HTTPError as e:
        print("dropped", type(e).__name__, round(time.time() - t0, 1))


body = {"messages": [{"role": "user", "content": PROMPT}], "personality": PERSONA, "deep_think": DEEP}
with httpx.stream("POST", API + "/api/chat/stream", json=body, headers=H, timeout=httpx.Timeout(30, read=120)) as r:
    consume(r)
resumes = 0
while not state["done"] and state["sid"] and resumes < 20:
    resumes += 1
    with httpx.stream("GET", f"{API}/api/chat/stream/{state['sid']}?offset={state['n']}", headers=H, timeout=httpx.Timeout(30, read=120)) as r:
        consume(r)
print("done", state["done"], "resumes", resumes, "total", round(time.time() - t0, 1), "text", len(state["text"]), "reasoning", len(state["reasoning"]))
print("TAIL:", state["text"][-200:])
