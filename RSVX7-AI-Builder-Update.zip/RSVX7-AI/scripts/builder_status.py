"""Read-only Builder status: no model calls, prompts, source, keys or balances."""
import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

JOB_FIELDS = ('id','status','mode','model','startedAt','finishedAt','lastProgressAt','deadlineAt','errorCode','error','generation')
CALL_FIELDS = ('id','number','phase','chars','reasoningChars','startedAt','updatedAt')

def job_summary(project):
    state = project.get('builder') or {}
    job = state.get('job') or {}
    result = {'projectId':str(project['_id']), 'phase':state.get('phase')}
    result.update({key:job[key] for key in JOB_FIELDS if key in job})
    result['modelCall'] = {key:value for key,value in (job.get('modelCall') or {}).items() if key in CALL_FIELDS}
    result['pipeline'] = {key:value for key,value in (job.get('pipeline') or {}).items() if key in ('stage','completed','total')}
    validation = job.get('validation') or {}
    result['validation'] = {key:validation[key] for key in ('batch','attempt','reason','at') if key in validation}
    return result

async def main():
    root = Path.cwd() if __file__ == '<stdin>' else Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / 'backend'))
    import httpx, builder
    from persistence import close_database
    try:
        report = {'at':datetime.now(timezone.utc).isoformat(), 'sourceProtocol':builder.ENGINE_PROTOCOL}
        try:
            async with httpx.AsyncClient(timeout=5,trust_env=False) as client:
                response = await client.get(builder.ENGINE_URL+'/health',headers={'Authorization':'Bearer '+builder.engine_secret()})
                try: health=response.json()
                except ValueError: health='legacy response'
                report['engine']={'httpStatus':response.status_code,'health':health}
        except Exception as error:
            report['engine']={'error':type(error).__name__}
        print(json.dumps(report,ensure_ascii=False),flush=True)
        projection={'builder.phase':1}
        projection.update({'builder.job.'+key:1 for key in JOB_FIELDS+('modelCall','validation','pipeline')})
        rows=await asyncio.wait_for(builder.db.projects.find({'builder.job':{'$exists':True}},projection).sort('updated_at',-1).limit(3).to_list(3),10)
        for row in rows: print(json.dumps(job_summary(row),ensure_ascii=False,default=str),flush=True)
        if not rows: print('No saved Builder jobs.',flush=True)
    except Exception as error:
        print(json.dumps({'diagnosticError':type(error).__name__}),flush=True)
        return 1
    finally:
        await close_database()
    return 0

if __name__=='__main__':
    sys.exit(asyncio.run(main()))
