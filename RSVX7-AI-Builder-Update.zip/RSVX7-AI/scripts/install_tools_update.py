#!/usr/bin/env python3
"""Apply only the tested backend tool/limit changes; preserve UI, .env, DB and TLS."""
import argparse, ast, base64, datetime, hashlib, json, os, shutil, subprocess, tempfile, zlib
from pathlib import Path
PAYLOAD = 'c-qxG+j88<b?^L&-dU#rEHNVvZ<0oyEzy#;!dS8tNp>#d2?Eaakg#Te34kHRWmpw&vKz-QDOcq!k1m(**=(g;mE=o?ulbUkOLwDjBPp$uN@Uk^05ndYKIingH@e-f2=5$)lQ%M+-pOQoD%0Nbd}DKSQyewifA~;z`}cPJ?Y`KgzkA~0!wvDFc#$Tj(Nv~llFF%!^C+BWBFn>b!7q1{cz*ssNced!Qu$XandR^|OXjCC6Zwf0S$Ha^Vv$Vcytg6Xf8EJE%rf!lB+Q>>$L_bnOg_V>-e99E;9r`|<v=`*a+!wnQD+4cb$ro*cOsZL&O2isH%a0gFd6_lsThh+A~~PBizp7}GCs~vhJ9Zw!ngWre+&P48=JE<S%^GI=D{*e@??_CMYLEZX)a#F&1W*p!ei;v#bY^(;wX=jn6D2elhtB15A!7T#c4Q?reQ7vgq3Y<Zfus<WkG|LZQg2SaDmWZg-9q-0DP6FGF-f5`qoLd;CV6xp5-Hj!uV#YY!gYoCWzg8-i9C;h|@qkUn0q1g}@jD@SP-<0%Yl_JPs%4u&M~ymH`YDqIe2Y5@ipRJi(tlkK*G@oJDbu!7gQ*A-pI*ZwLMco*yrB@z-K1<#HOPZ{TN|oxZ)>4I_q=%LRZ6^HnM>IJ0>Y=EXXvau%-U`EaXu*B8ffxaEtv9B!)>g2?<pPVyj{wqXLOL@|!hV}Y`Z1U5$$=ZVP9Gr$5LEtWZhL{tN$oCWa+gn&?j-A1d+BA|9I{_Ai4NyG`r(JG#H^E6ueczGIS(a~IL7Amkng#aiUziEa0p?D6PSIm->IhToW3M|M0Tzm|hI0UNWuWYr%{n1mh2CUB$&>xuv7#3G2ArgdW*e4p^>)!`55{z&e1x$)M8Jl2K_pz4Q_drFx`ZX}<vntU@(DomQIqsUW(inpTl2F_Xa{HbIEts4n(L}Oh19^@nc>xLk@X%!lT4XNg0lx#k0S)AEWiY7{;Psr;xY~Rn?mN&WnE)-sTTsN|LOu|0KyXNLYi*8tHVr5EW3dc#6g9FJJNNeeeX+T7f6Kp1)?!0EM6!Z(=4e$C&{Ul}6Hp{~GE!e1*hFD=9#23xX96Dt{J@2&26a8>BW~${2{06o<r1_-=1x{=3Tp`Pp{G@ASsNq3p4MnSuB1ozi=T?dYFn$N0y<%u1388w$fJeqfx4Il6WDFAAXkn3Q2Ys!J?A|`TM})c$j=gS3>akMNWzwqM8ktafs7gGSB2>J#A`X1$7#4g&2R*|?Ic<XH<}3<hd|q@I68-o2>R9|GVk{90ev@jw|5ko^*_D7UbsZUxECF?FP(ufhDBLOxb^tp<+p=p&mTVtUc5Yf_T=TIcN;h*!_)-q;L*1=B+??F<b+LnWuC5`WzoYQr3n^2_4`uoiY5Sy9x))8t`<vIzMafhQyIh{@Wa>XN_rm3BNP1*$SsH@F$77|orM$BYn{Uw?sr7ILN*X5S(}JtMuVRoyn0P<lvV48#BksvZW{Ri83?WcE?}pufaM?%=Sw+71<em<tN9%E>~snoR{EdVyR+x_!Ry-H-SYc;hQS~X8HmXQq%q(<i!<SV9u%BQ!wA&)AHIJ5;>p{IBrWCwzw%WELOYeiy{#P|_F5iB^I>QGFY7O_K41S*tbcy>cUNCreSY<$^}nuvBi8?U_2czd0<Qlae*AR(%k@8ts~=ze<NB-hZ?66U?|(tBtbexta{Y6-3lM&`{tvqN5}vGowf-GGufXkfY^MNrls4?64&BjS9BM&SEU=>heHaIV@1m*j(PFyRTcv?Y?{~(Y5)mMn+2*9(9Qx@H{Xr}Zq~5X2T}Rn8pf0M>g@g^BIi3I^9*wn5X(RFO7B~gYYxHdui+GWDmfBgKCZGmzVr@_*DR$BYfJ0Bbq8CL-x4V;Y8Il1fQX%rGoPiU4A|g=G>_8jz9n1KY2zNVj8S$chY78h!7b0Adutx5bZ~7HTMoqp*Wp@Tn*-6gZN*u4kbV}O{bZxW%U8yz#SQfA|n;18s6DX`1k5*IQmvRJAMXNW421cM2gPPyf*A0SUG1h{$c@3~pp$*wxD67IBfQ!^a4Fn_e>lG4d$XshkLTBuQ&d<Od4Z>^^MMHASyi3g_n&xdDq;e5P<cU?8tVggL0o)Z`dtqI%y|-@|UI+J0(Z4~P?Dj!}bZBRPzWy!l`1P+*0sQppZ`Z$It?`Ap`T_?05H>wL_&3lYKfn5{stiz1`~qJ7sVKww4d|pF!v%r-k+}K{-uj8wC7-Xqy87YOXQ*OOn~=8LyGzD!f4^c3JC-{k$c%#*g!*{+2N~}x{9#2BcnSI&LOJ+3wOmQODrg8-9lw|cA(8^=KnT$Bd<N~?fP**k9QDZKC!ZXA_v!24#gmt>o`2`y>EY`?LpL}s`6iw(s=KL}Tg|I{<~jJ|5@rP<2+zVO$LKIx1jjPQm<E}J$c+fGv6B6FddC-eJ`XYpax%?^_tC*sF^}YJ94s;=fo_v~1maflqdf7E=#!_cY;ocJ$y0RU01+3oEphg4AHB)lds`LGYNdKB=M4WTA<*8h{ztJ;kS&2n@B%`4jdxzD8?NPQkb?+bEO-Ynt`hmXX8T%mk_L~E{qVv?ai2t!?cG4hO8MbOADK8SFhC-inN9BbOrHBYNFKE4{jCyxXvyIWJYNWJQA3As-K`#2C{)$`9_(L=a1m`9;(1=><pxt|*=rW}ra>KLFU#N(6-^-_E(@Aoql&9<jwlHN#tJ~Zk5;WiwkB4Nf63leW>!OJ{>p2upc{g*wkaBhnyDI|ZB(c0Sb2;NuDppigAH*Fc`X1qvk{+$xsqkDyk-`Z&Apv1{~pNZ?yi5oCYt&m@GuWyE|8`$&r_G_3C4vUfK^2@d1R-UK@w9G<t=RgE7B9NlZ!n>&|Lbj*Zd;dKzv6TarK5qi>@pauka$ocnO48r&E^%)&t1+VwD=4#cI9MhOMLj&C(`9VOk+OQER=HVBIF5Ft7xH{7jdq0jLz@gbNoCz^Cx%gJJnC&l@za{2jnEk#3$xwEbgG<t1o-umexh6qItuB&suvm4JO<vnHs(#54r1g)>z8$}|+_w$macuo}#QVemVVv<e?z_Eg^FZGH`QJUWWO)0crQrezD%n@Kq((Cpgm?UDi9+uOfp7uBdd9Ey%a3UuC=UJy%D0!V7=tYZ0gNny?W9O=`_Z%#QiKgNG?k}kj{`V>Q0wJ$8o+FP!&6PF%%?J&+UaRy2PcnB^y#0ZwhebLD$U{<TsTsC^u@M`D#@%Q6SD`5?*uA!toOgkh&*c6*ztF!D^hbW+uJeoK;bMeQg0IIjjCrU8(?~-8L+XF3I6^xodv}1Dpu3_G@Fq}pC2`~x5Q!5f%gy|cZ)&;_5DWl?+ck;$&85g^#R1Hu?IES~Um@OwupIMrNNA#+|4rkz%gD)-4LQpCT+*_PNv+|YV)#GoQ=-e;DPmua5IC$v@Hty7#coTMgb_VDspbQ>}7>ivH+1o?%Gtj_2X4l<aV%PoMiX&UZ5P)r9Ts6*f6kdPTJ&V-(g2^?!)mRr^Yp2uuK@wrKp=A!tcAn8bP>*<3>VBhVWAj!en5#2E@N8{K`-RhR4#9xyHEzc?vP=MVw|N)cCPr_`SXPiW5q6VOtE`W#>efcLR8XCQ2+R}kp@MK3)$6LY$0!%~F>t-FWP*y2t8_k(j?m|WDO3#-?va7Oh=~TxLRil-($5cG9KNLdy07!$emP|Kh0309bm{%&`4q?zO*8;gJM_gPFp|;nV=$9G7bsM5^j%)@#lbuZvq$8DWC~~0Zm_L$*-K@%OyUgov4ZtS5DULlH+{kBeh^N53zw}%hO7L93Af{K?*Qp`{GGn8GpHH^rSk3odG4I{?{E#vDHR#`9!0rBT|a>M+|&-Z;4Hxtj>UzO9AUxE83+ffIgT$Jv^#J;x^SW?{KX0h+%3itd>ojZq0Ahe<4vkMI+qlh;2Y>YW9dAf%LNu+2pw<aD1^u3%Z)DnkITKPX53KZr8sCp9DrR?umZxOJPn5q%y$H6dUhEd^!nGTmea0ahH!yaSF+F0oR3tjb=#F%&VmXrO=d#%BIx3djy_!kYbht3*pv|7ohg2cr{R<{Y4CzVU{rlFZUuqlW2K=KlMSUY9eWKh6>Vi)&%y<$bheeszC|Wm7f@~%aU|>|b}`(tLjpFLxNWmUshhzNp(Nqr-6Y&@H!vbzv@lRHR$=#^T@ddK!gN8fE2T=Ys@C4nfIwN9o7)a*HFxk9uCFUs3htZl2|!g;QCdS(@k3kDyPX0en%d@SgIA(RzzK+K&|1;{|4~YRXcxGR^`Sa<K?1Zx)Kt~K=l8)K>~HV;{lb06L}`RB(FBOeYEtErheyfuoO51U%#}<668ubEE822L$<T`Y!HdyjMq6VluVS3&@KDDp%JLoGp2B`p*^J`(s6QANZ^Jy8&t@Q=_*jtD7?jfw?FF<~jJbl1&Mi=1%#-+7n=qIF6KDpz1k(lQE?10AVb4M8p(ZoVpW_wfXp?ET@M_128e&4sn@_3prHmp5|2WwlGZSZ%41!@Qi#(ZAB;luQ>9n~#JBf;R9j;c^7)C2o978RwT}sDJz$nnBBwpuTLjm1pGV*iN@REQH3XyU!V0JiIP*01Z+U+@GF~%n|*2167Tk@yOox<BLQ?$&eJ5+ydWt5g@+F)gMMZmz~x(&~;<^f&^$EpEEFwW&oB{f>ecVjbsMLjy@o)pT&lWSD(1JuhIj!MlC4b&Z%N>rAP@tc!{jcF}oy!d_VhHux;7`VCitzN64(iQFbp8vT?{o7B9W=KuPT|<^BDeeb4GuvQ2cvQm!Z4r}II*~Q!x7-p{^gw9=osu@5zyL0UIrzo|Y);pKxIUBcB+q(8g5X5Hb^F^Mrxz%_g#U4=F@`MD9<^`v_xGDBN=5F?;oO^3$-Oz0bp*$eDtRMyIc`n9u`an`lF{Sm-+3}_8Oc6ut)k@Q6Y`1)kA`gIb*qR#E?_AIdy4e{)bXWv!)j`{q+b^ms~X4(yuc{E1wx`m92+6=9thRY$lnJIR*eP~(y48_w&6ZUI%Pep>c;)M+w5T7+s8D4EywMm)uiuj|A3>VT6V%!Sm~?==C&4c8ifJ&dJP?P2JX-TyF3ys_X!v)(7eM7=TSI0k=;kwO$jCt=p85B3Eo5d{-<4tm*l+rt<`KMQ<#$nIG4&5;-Ug4R(+N5M2CXQK)&V6S_@EWCCD;a;9OgSc9-ij_@ydac{1O4Gdj0lt&<lD)U&JqXq#9Fv@~R{UF<<|VP(=LxlLAeZ)@AHs3ObC)YJqc%_RtH!&hFhQ7A~Ey{%$fdK;~Kj>uYhBd@)|RJUK_JJ{yL@2C;ujqA2mg-)yDbsji=U?k_l;cRn}s#uLGw}9PFJ!L@yIn6;M@+1%E*FgcTV7+l^wjMf(ys8@<CSt8)Y6e<xA()#I5QU@E{x-9=REj7^_q2R;RB?}4zNxU3ouk}ds?SlalHx#J_2O(eCx;!!yEI<0^>m=;8`%a1a|t|1=f|x!HC=!z-mKdL1fa1qPmRy0(ma$HQ|^M5^Feo^SMZdU%+3TnRlj_lKpTiwH_>6&CsV1>cq-q*PxNaQ;&AnDBnH31DV2>Jy$3E)%2o;}{jGGB+y<G2&Q!g_B;}O9sy@|n{l$HDsxZq>|7A<WWngLy2ezkEZnsAr_?Ox0D4V1a33;Fr0@J_jZHP{%qY~*sFk7Lk8w4gR9)rkJRwmo%s(bU~_!wjW{ox!`cLENpas|QsgxSeFI@;L0{aBy80EL0BP3rmeHTcA;P^kuj1w=EUhUp^}KAk4=#X)@j-t~+>UddEZcZ({a_^02mxvWT3tYx7(oHRH)<(fW@^eG|4Mg7Vn?s`Je#4bN9{kPP1N&l5vNL5t|p^O-UZC5@dJE>a_(ZXh{c`gngv-1Nol18QKBW###wUD}f6JwEH0S*^EBR_`%ZcEYlqPPk`AHX$c%JFYqsZ_f<NH<}kfapLIcr|aA1~s_3tt4TnWj@e7)m%a9)N(=9vj$hwvY%$QT_i39hh44a6L5ae{Sq#pFaSLkE%5MNR#uk^g1D#Zzq;a`EU{10fWf1SC6y3Hrc6=S3zdf`zT4Qey1A`eS51TH!OMeZPhLNH`3jw^QgfEC8?aQ0Rd;c3h!-!Pe{%TrNpScW-*O#w{EbsZeEy9%tq#CpQo+o}uc8?-k2kt_p5tlo$>Ecy3Zki^R0<%zXenm+qPZ4f3mn?$|D~DG@NqSUxE{QTld~A<!0B6<+2|e@TU?{J!ww~L>Ff>gudDe7)X&4?Y&hy19GbRBYNfY3HiH}CMm8XNpS9W!Yc=@O-%$lltX(cwNAqYBsG^A78_E@u6}Rwe#bj*1w%(;t96|9T&u&j9ZusqesO7nUsAuvBBs)weCqa=x8*rIJ6_BXG7vh*n9-Yd-=7LLy8GLhaLhBu^+;oFGKV_sVQbE{TrHu)McVN{TUu_njDg@l%DL6~IxtVZe05<OG#fwXio>gXQp{&OZZ-ipG7KhCreeTj#EA-7;tkXYrJhUXUx-{?VRq)BD(n-5&O%*)!Su{6Q5v#)CiSEZ_6jgA&zeE1a-K|RNQ3s3YoW$y2EinNr;~?4xhp1n^clh|pOR71jC+sNG&Z1!!iHrVj@<a5x92uWRX%b@{+3_ngrxNa_=f-R5aJ9y@XaAs>oie!B&4>dqlmOVCJy+#?#h}cU>SK-*cDC>C-)kU6hmh&;>iRq2#B6((TisGZt4`TcXwwpHB{^FG-g0N!pi0{SaWcfLJW@NvreR~}_&^jF*5D7tD?03?_W=wDseKdHkO}sMbz(dd;1!(0GJt!0UXlxFHZ+KLV(bhv{cL=?!N5n~s3*iBA94-BDZ%s9)~61*rE9ytjT(A;yLvXEwY9%4IW^_fC_P#<zpi|db}NZ;n=~L^<ymhKu~xxgy@VhwSNb-PDMihjP>*jtza~D0$nHI*t7A-D$4cj@0hi3_y?eyz{k#6|R_QP%$)(m4?6hNO9D#2<<x?m()_v}S^<4i7&s$#oWc}6pSJpX7JmX}}Ou+@8nfmSeOBnfUK7RSTs~^IRUy7^G*1u3Eq}IQMd;i{Z%I>T>=~Gqu9@}Q_!gx-6drF)3TM*@!dNH_aNzb@ej|bz4Nme67QE}fT$oS4f3KRm>Igq5TqYbBePLl&)PLe6#AwMU{B2q^@*qva-g<O9-Dgho~h4B;*tx?o-iV+VDGntfX6vJ%z9zNxMSBKZF7AF>~EEh-8VBmPQ6e@vc%9*<V3d{a1`Q2iHg}q%Z=_GndGg3BmP@{Xx5qI4l0D-_F$}$um2LcM+;bs=v>2wZaA>S^+QH*k>1&up1vlNP6a(G1j@f@<BNUaHb9etvK1zi`Wrbj&!#mu638i0@BUN`~emjET_QfYkkRRzHHIHvb6EQ8zT997=xG2z^0`7K%o_dQiW2Fj7KJTol{)o9-i^~>;!{F^EAGOe(<t5Lgsaa#M!vQTE~TrY<B6R=e$unLjbf@qHPYI8RvY~4?zrHzoUm_m{kCB5SiIGDO0x#r^sikmDb?!qbr+w1c5n$4F#d`6@)u!kieO3vHucho+>c#i1hacPq>ppS<*wB9_|xIr6fY0-!G>0Bb+(gbrzc;@RwpB{F~S$mlG8lM^YuTW$RTN?A;4^asZ<&?jBWR8B@f)Kuq7OREExW31<>ZtBAAL6=iz$nbC7MNASlYz}Vzin8+bEv*ZI{!&Cjc<M<#QED#EA*l)nc-oK+|^FPC1Ac<!W=mt*Q<0RHX<$@Eym`t7P!lDCt)0;Bb&rE3s%n4oUAD4ISVH;Fb+vAVbeB>PG4^00XO*XecLAh=g~FNR%zJuu%8K+Ou~xW2KLq*Y>b^pw9Z>@4#h~dc$&l=rL}d*rxxC;ja%<r)e&JOW#2651M7PWDk9afcvtN8$%*VXb*7dxFC~x5&cX~RtgL42ufwGg3yzbuoi3<;O@Ln-Q|`+JaOBC>c;i)?MBZz$RTvF=Xh5>_dtA;Iw%={l)}!_db;3u-oWlvoNy~J+r?(cSStsfF64wf0Fn+h>OzkA>u(}hk=JQ(V!)g)MTV>1N5}SR$-`~cqvI&00_mp*-@;5Nfz_AhLEy{*xpg83OKhXk+vsXgj$xvS_^3{<WFm{q16;(W-I>lx~`9XbR?Y+)3RD4*~mRa0TKr3~Ol4&UX>`zuPX{blY@0yQo_d5@->2{{Un7pTq&9I>r*>2t6^_L+YFpP((^B1Fo?w^O<Pq(`FgYJ0q8^-da$1Cd4FF`DIM5_Y;dL_uG-@_{K!)Z6KVS8_1cO{%Jtxx7TGeu8lJS=`IXGUEPN<^=-qG&4qzr>KKG_^oGEjMiFc5e9?nsq9hyvOpZ0oXPA*2O$r98JT)g@crJ2D&)xV^(a54ht4iFD~`L0YC+_fp#<Wkb6yR!T7z=^y{#@K%$IX(}9|I$E^JA#@5bO-}LNSExThY$*qsz+={;qpPJL%>842@rF?u#aFyP8t_<FY&yAbZ?1WoN?XK|yD|N{CBTZZKK^HfDWc1MC&$3;giy%*m4n$HKqA3eet6d@|s+k9st)NC|I|}6>6a!i|=CldD54d&A!3Wh>)Hr<X`BWt}@o){hYw{lSg*vNOT?-?+skM&vN)ALfYAi>L$GD0@d)9;~T`{08vx83L7wT`u2Tp?QBwR|&l+G%2$6M51J{(%xu1<F(AdS^4)JZ$KX>Fl8l@3f>e@tPVhJfK_QCPQ@E9V+9i=0$W!Axx<CT1DPbn1n_F=_Rz&N5y2sKmaNCDtai=++`5#mNTKE05o4Rq62-GQiBP%^ua`|G|)}GG(kl<9H3T+t2M4^2ZftiUkI%riItkiTwqZccaBi(|&Oz@k9!qO=+M_L&6ZJD5{{9&r+ICQgUCp`Ud5o(4yIJl=rl0>(P-)^MM<ezir0{`|M*IF&&c3K#kCG9MBhht;t+ZTR4wbm@=dz@JLk}?-ZG^hHvDw=|I&4&mA(=y{O=r^C00WPrx$b=X>B!A;j&79>zpMy93|xTIK<!5@fUE`8-)GZ2NOS3YSc%@V&Cf5t>_Hb&*r#8@5s(S}seq!^j?O26;7bwgbe2se{KuVls<wnWl2S8&lwElTj2CD+dx{I*|Aw3Xq*3)aSE`(<EhKP<Kn4zb*=TRB4|p!B8`|bLx4zJPBhI{b^Znxe!y82n7!m!Xkn2x@qbXgELvj_ePwaVPc*>OJVRZpMH%kOWPo>HH4bJq7qF>8AQ`U1JvJZ{?-+$0eIa~2zYgSb%3BTUF|d+)X}t6xq1X_)W(f8du`JyOl6_v72#BEm*{$;=xFt;R^m~s+k8;?5kY`qKoF4KVNL6m4xXb$rb9Xxmk;QQHSfjkG_QImi$0aZEvt%!t>iQ#ee<b&o{d&K9F5C;d;C2qfX{DKWe|@p(UTj#fChv=2{Y?+Q%*5ncT-R~L46ggJPWqV4skAh#sb@C>mrLf&83H)HVYAZM)-5<n?ri`O^7fWtf{TUMdJ*}k72<XOo%JTpC|RXrP;wSi{n<Kz5L=QM75+KX`D%M;N|6IeM!Zl38V!F9r6O`4eMcTUxr@k%Ea!=CO@6r<bwG0hVMAu10=$TF2|cg8dV70CT;4f<86n;7CVb2*=4#GG`T(0B3wJpW}`IVZ5ge1UxW7LaMZ^t3)R2@QY5N|MyG}WX;}|ns7kL6Uqt1Dhss^!F~v4k#|CI4tM3<;tsUP~c22p%<q)GSx+ocpCLg+ZTYUqVKImkeC%d=T(amr-NvAqTqT1cP8<$d5LTH4>b*Ui>5yckDrt;b#GxUX<=}>1YdZmC+(l@}Gzdyt;R@Aa0NTInKXi$7%3J+jn<AzvSE|AkaT_yIWPULwKPN|u@goxQA%4us8Q8Ui;8ie!-9HG)~UZdUDBCBSN8hWp<H}N(eg>5%wNRkZ8zN<)OMV}qTz*}vOQNi9(#8H1lq^E3wTRequ<i7#t915B'
FILES = ['backend/server.py', 'backend/developer_api.py', 'backend/tokens.py', 'backend/ai_settings.py', 'backend/huggingface_provider.py', 'backend/tool_protocol.py']

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',default='.')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    root=Path(args.project).expanduser().resolve()
    if not (root/'deploy/compose.selfhost.yaml').is_file():
        raise SystemExit('Run inside RSVX7-AI or pass --project /absolute/path')
    patch=zlib.decompress(base64.b85decode(PAYLOAD))
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    parent=root/'.rsvx7-backups'
    parent.mkdir(exist_ok=True,mode=0o700)
    backup=parent/('tools-'+stamp)
    backup.mkdir(mode=0o700)
    stage=backup/'stage';stage.mkdir(mode=0o700)
    originals={}
    for rel in FILES:
        source=root/rel
        if source.is_symlink():raise SystemExit('Refusing symlink: '+rel)
        originals[rel]=source.read_bytes() if source.exists() else None
        if source.exists():
            dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    def apply(*flags):
        return subprocess.run(['git','apply',*flags,'-'],input=patch,cwd=stage,capture_output=True)
    check=apply('--check')
    if check.returncode:
        if apply('--reverse','--check').returncode==0:
            shutil.rmtree(backup);print('Tools update is already applied.');return
        print(check.stderr.decode(errors='replace'))
        raise SystemExit('Source differs from the tested baseline. No project files changed. Diagnostics: '+str(backup))
    result=apply()
    if result.returncode:raise SystemExit('Staging patch failed; project unchanged: '+str(backup))
    for rel in FILES:ast.parse((stage/rel).read_text(),filename=rel)
    if args.check:
        shutil.rmtree(backup);print('Patch and Python syntax verified; no project files changed.');return
    old=backup/'original';old.mkdir(mode=0o700)
    for rel,data in originals.items():
        if data is not None:
            target=old/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,target)
    manifest={'project':str(root),'files':{rel:hashlib.sha256(data).hexdigest() if data is not None else None for rel,data in originals.items()}}
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
    changed=[]
    try:
        for rel in FILES:
            target=root/rel
            if (target.read_bytes() if target.exists() else None)!=originals[rel]:
                raise RuntimeError('Source changed during update: '+rel)
            staged=stage/rel
            if originals[rel] is not None:os.chmod(staged,(old/rel).stat().st_mode & 0o777)
            os.replace(staged,target);changed.append(rel)
    except BaseException:
        for rel in reversed(changed):
            target=root/rel
            if originals[rel] is None:target.unlink()
            else:shutil.copy2(old/rel,target)
        raise
    shutil.rmtree(stage)
    print('Backend sources updated. Backup: '+str(backup))
    print('Rebuild the app container to activate; no environment, volumes, gateway or UI changed.')

if __name__=='__main__':main()
