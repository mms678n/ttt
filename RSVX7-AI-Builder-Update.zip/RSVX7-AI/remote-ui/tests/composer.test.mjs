import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../src/lib/composer.js', import.meta.url), 'utf8');
const { shouldSubmitOnEnter } = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));

test('Enter sends a completed request and Shift+Enter keeps a newline', () => {
  assert.equal(shouldSubmitOnEnter({key:'Enter'}), true);
  assert.equal(shouldSubmitOnEnter({key:'Enter',shiftKey:true}), false);
  assert.equal(shouldSubmitOnEnter({key:'a'}), false);
});
test('Enter used to confirm IME composition never executes a request', () => {
  assert.equal(shouldSubmitOnEnter({key:'Enter',nativeEvent:{isComposing:true}}), false);
  assert.equal(shouldSubmitOnEnter({key:'Enter',isComposing:true}), false);
  assert.equal(shouldSubmitOnEnter({key:'Enter',keyCode:229}), false);
});
