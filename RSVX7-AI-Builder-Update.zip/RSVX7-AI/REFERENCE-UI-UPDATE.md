# تحديث حركة الرد داخل الواجهة الأصلية

تستخدم هذه النسخة واجهة RSVX7-AI الأصلية وقائمة النماذج واللغة والميزات المعتادة. تظهر ردود المساعد تدريجياً بحركة مطابقة لمرجع المستخدم؛ تُعرض أيقونة المنصة بجانب الرد وتدور أثناء التوليد. بعد اكتمال العرض يُنسّق النص وMarkdown وكتل الكود، وتبقى أدوات النسخ والتحميل والتفاف الأسطر في كتلة الكود. يستقبل اتصال المنصة الرد ويحفظه مباشرة؛ الحركة عرض فقط.

يتضمن مجلد البناء ملفات واجهة remote كاملة. المثبت يتحقق من وجودها قبل استبدال بناء الواجهة ويحفظ نسخة احتياطية. لا يغير ملفات الخلفية أو قاعدة البيانات أو مفاتيح API.

## التثبيت
ضع الملف في `~/j/RSVX7-AI-Builder-Update.zip` ثم نفّذ:

```bash
(
set -eu
cd ~/j
task_update_dir="$(mktemp -d "$PWD/rsvx7-ui.XXXXXX")"
unzip -q RSVX7-AI-Builder-Update.zip -d "$task_update_dir"
python3 "$task_update_dir/RSVX7-AI/scripts/install_reference_ui.py" --target "$HOME/j/RSVX7-AI"
cd "$HOME/j/RSVX7-AI"
export RSVX7_SELFHOST_ENV="$PWD/.env.selfhost"
docker compose -p rsvx7 --env-file "$RSVX7_SELFHOST_ENV" -f deploy/compose.selfhost.yaml up -d --build --no-deps --wait --wait-timeout 300 app
)
```
