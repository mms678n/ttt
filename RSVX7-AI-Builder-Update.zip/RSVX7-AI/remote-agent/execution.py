"""Streaming, cancellable, non-interactive command execution for the Agent."""
from __future__ import annotations

import codecs
import os
import signal
import subprocess
import sys
import threading
import time


def shell_args(command, shell="auto"):
    shell = ("powershell" if sys.platform == "win32" else "bash") if shell == "auto" else shell
    if shell == "powershell":
        executable = "powershell.exe" if sys.platform == "win32" else "pwsh"
        prefix = (
            "$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; "
            "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); "
            "$OutputEncoding=[Console]::OutputEncoding; $global:LASTEXITCODE=0; "
        )
        wrapped = prefix + "try { & {\n" + command + (
            "\n}; $ok=$?; if (-not $ok) {exit 1}; exit $LASTEXITCODE "
            "} catch {Write-Error $_ -ErrorAction Continue; exit 1}"
        )
        return [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", wrapped]
    if shell == "cmd":
        return ["cmd.exe", "/D", "/S", "/C", "chcp 65001>nul & " + command]
    if shell == "bash":
        return ["/bin/bash", "-c", command]
    raise ValueError("Unsupported shell: " + str(shell))


def terminate_tree(proc):
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, OSError, subprocess.TimeoutExpired):
        try:
            proc.kill()
        except OSError:
            pass


class ExecutionManager:
    def __init__(self, send, log=None):
        self.send = send
        self.log = log or (lambda message: None)
        self._active = {}
        self._lock = threading.Lock()

    def start(self, exec_id, command, shell="auto", timeout=0):
        stop = threading.Event()
        with self._lock:
            if exec_id in self._active:
                return
            self._active[exec_id] = stop
        threading.Thread(target=self._run, args=(exec_id, command, shell, timeout, stop), daemon=True).start()

    def cancel(self, exec_id):
        with self._lock:
            stop = self._active.get(exec_id)
        if stop:
            stop.set()

    def cancel_all(self):
        with self._lock:
            for stop in self._active.values():
                stop.set()

    def _run(self, exec_id, command, shell, timeout, stop):
        started = time.monotonic()
        proc = None
        reader = None
        code = -1
        timed_out = False
        try:
            timeout = int(timeout or 0)
            if timeout < 0:
                raise ValueError("timeout must be nonnegative; 0 means no deadline")
            if stop.is_set():
                return
            env = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"}
            kwargs = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if sys.platform == "win32" else {"start_new_session": True}
            proc = subprocess.Popen(
                shell_args(command, shell), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, bufsize=0, env=env, **kwargs,
            )

            def read_output():
                decoder = codecs.getincrementaldecoder("utf-8")("replace")
                try:
                    while True:
                        chunk = os.read(proc.stdout.fileno(), 4096)
                        if not chunk:
                            break
                        data = decoder.decode(chunk)
                        if data:
                            self.send({"type": "exec_output", "exec_id": exec_id, "data": data})
                    final = decoder.decode(b"", final=True)
                    if final:
                        self.send({"type": "exec_output", "exec_id": exec_id, "data": final})
                except (OSError, ValueError):
                    pass

            reader = threading.Thread(target=read_output, daemon=True)
            reader.start()
            while proc.poll() is None:
                if stop.is_set() or (timeout > 0 and time.monotonic() - started >= timeout):
                    timed_out = not stop.is_set()
                    terminate_tree(proc)
                    break
                stop.wait(0.1)
            code = proc.wait(timeout=5)
            # Drain every output chunk before reporting completion, even over a slow connection.
            while reader.is_alive():
                if stop.is_set():
                    terminate_tree(proc)
                    break
                reader.join(timeout=0.1)
            if timed_out or stop.is_set():
                code = 124 if timed_out else 130
                self.send({"type": "exec_output", "exec_id": exec_id,
                           "data": "\n[command timed out]\n" if timed_out else "\n[command stopped]\n"})
        except Exception as exc:
            if proc:
                terminate_tree(proc)
            self.send({"type": "exec_output", "exec_id": exec_id, "data": "[agent error] " + str(exc) + "\n"})
        finally:
            if proc and proc.stdout:
                proc.stdout.close()
            with self._lock:
                self._active.pop(exec_id, None)
            duration = round(time.monotonic() - started, 2)
            self.send({"type": "exec_done", "exec_id": exec_id, "exit_code": 130 if stop.is_set() else code,
                       "duration": duration, "timed_out": timed_out, "cancelled": stop.is_set()})
            self.log(f"Command finished (exit {code}, {duration}s)")
