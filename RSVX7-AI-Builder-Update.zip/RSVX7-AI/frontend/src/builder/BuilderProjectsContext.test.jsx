import React, {act} from 'react';
import {createRoot} from 'react-dom/client';
import {BuilderProjectsProvider, useBuilderProjects} from './BuilderProjectsContext';
const mockFetch=jest.fn();
let mockUser, context, node, root;
jest.mock('@/context/AuthContext',()=>({useAuth:()=>({user:mockUser,authFetch:mockFetch})}));
function Probe(){context=useBuilderProjects();return <div>{context.projects.map(p=>p.name).join(',')}:{context.activeId}</div>;}
const response=body=>({ok:true,json:async()=>body});
const render=async()=>act(async()=>root.render(<BuilderProjectsProvider><Probe/></BuilderProjectsProvider>));
beforeEach(()=>{global.IS_REACT_ACT_ENVIRONMENT=true;mockFetch.mockReset();mockUser={_id:'alice'};localStorage.clear();node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});

test('a late projects response from the previous account cannot replace the current account',async()=>{
  let oldResponse;
  mockFetch.mockImplementationOnce(()=>new Promise(resolve=>{oldResponse=resolve;}));
  await render();
  mockUser={_id:'bob'};
  mockFetch.mockResolvedValue(response([{_id:'b',name:'Bob project'}]));
  await render();
  expect(context.activeId).toBe('b');
  await act(async()=>oldResponse(response([{_id:'a',name:'Alice project'}])));
  expect(context.projects).toEqual([{_id:'b',name:'Bob project'}]);
  expect(context.activeId).toBe('b');
});

test('an older refresh cannot overwrite a newer project list',async()=>{
  mockFetch.mockResolvedValue(response([{_id:'a',name:'Initial project'}]));
  await render();
  let oldResponse;
  mockFetch.mockImplementationOnce(()=>new Promise(resolve=>{oldResponse=resolve;}));
  let oldRefresh;
  await act(async()=>{oldRefresh=context.refresh();});
  mockFetch.mockResolvedValue(response([{_id:'a',name:'Renamed project'}]));
  await act(async()=>context.refresh());
  await act(async()=>{oldResponse(response([{_id:'a',name:'Initial project'}]));await oldRefresh;});
  expect(context.projects[0].name).toBe('Renamed project');
});

test('a project-list failure is exposed instead of being treated as an empty account',async()=>{
  mockFetch.mockRejectedValue(new Error('Project list is unavailable'));
  await render();
  expect(context.loading).toBe(false);
  expect(context.error).toBe('Project list is unavailable');
});

test('a project created for the previous account cannot select itself in the current account',async()=>{
  mockFetch.mockResolvedValue(response([{_id:'a',name:'Alice project'}]));await render();
  let finishCreate,creating;
  mockFetch.mockImplementationOnce(()=>new Promise(resolve=>{finishCreate=()=>resolve(response({_id:'created-for-alice',name:'Created'}));}));
  await act(async()=>{creating=context.create();});
  mockUser={_id:'bob'};mockFetch.mockResolvedValue(response([{_id:'b',name:'Bob project'}]));await render();
  await act(async()=>{finishCreate();await creating;});
  expect(context.activeId).toBe('b');expect(context.projects).toEqual([{_id:'b',name:'Bob project'}]);
});
