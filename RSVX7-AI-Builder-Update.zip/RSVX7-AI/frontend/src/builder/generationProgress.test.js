import {generationProgress} from './generationProgress';
test.each([['structure','structuring'],['writing','writing'],['reviewing','reviewing']])('persisted %s resumes actual stage',(stage,phase)=>{
  const state={phase:'idle',checks:[],files:0,attempt:0};
  const result=generationProgress(state,{status:'running',mode:'build',request:{action:'repair'},pipeline:{stage,completed:2,total:5}});
  expect(result).toMatchObject({phase,pipeline:{stage,completed:2,total:5}});expect(result.checks).toBe(state.checks);
});
test('completed review belongs only to its exact committed revision',()=>{
  const state={phase:'installing',checks:[],files:5,attempt:0},job={status:'completed',mode:'build',revision:3,pipeline:{stage:'reviewing',completed:5,total:5}};
  expect(generationProgress(state,job,4)).toMatchObject({phase:'installing',pipeline:job.pipeline});
  expect(generationProgress(state,job,5)).toBe(state);
});
test('invalid pipeline counters cannot falsely complete a stage',()=>{
  const result=generationProgress({phase:'idle'},{status:'running',mode:'build',pipeline:{stage:'reviewing',completed:90,total:2}});
  expect(result.pipeline).toBeUndefined();expect(result.phase).toBe('writing');
});
const build={phase:'idle',files:0,checks:[{id:'files',status:'pending'},{id:'tests',status:'pending'}],attempt:0};
test('server progress reaches the card without claiming any test passed',()=>{
  const result=generationProgress(build,{status:'running',mode:'build',startedAt:'2026-10-20T00:00:00Z',generation:{files:6,batches:3},modelCall:{phase:'receiving',number:4,chars:1200,reasoningChars:80}});
  expect(result).toMatchObject({phase:'writing',files:6,startedAt:Date.parse('2026-10-20T00:00:00Z'),generation:{phase:'receiving',chars:1200,reasoningChars:80,calls:4,batches:3}});
  expect(result.checks).toBe(build.checks);
  expect(result.checks.some(check=>check.status==='passed')).toBe(false);
});
test('reopening a running project preserves its original elapsed time',()=>{
  const job={status:'running',mode:'build',startedAt:'2026-10-19T12:00:00Z'};
  const result=generationProgress({...build,startedAt:Date.now(),finishedAt:Date.now()},job);
  expect(result.startedAt).toBe(Date.parse(job.startedAt));expect(result.finishedAt).toBeUndefined();
  expect(result.generation.phase).toBe('waiting_provider');
});
test.each(['completed','failed','cancelled'])('a %s job cannot replace actual runtime verification progress',status=>{
  const verified={...build,phase:'ready',files:9};
  expect(generationProgress(verified,{status,mode:'build',generation:{files:6}})).toBe(verified);
});
test('invalid counters and planning do not create invented source progress',()=>{
  const result=generationProgress(build,{status:'running',mode:'build',generation:{files:-3,batches:'8'},modelCall:{chars:Infinity}});
  expect(result.files).toBe(0);expect(result.generation.chars).toBe(0);expect(result.generation.batches).toBe(0);
  expect(generationProgress(build,{status:'running',mode:'planning'})).toBe(build);
});
