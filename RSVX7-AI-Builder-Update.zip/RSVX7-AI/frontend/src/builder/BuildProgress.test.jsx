import React, {act} from 'react';
import {createRoot} from 'react-dom/client';
import {BuildProgress} from './generated-widgets';
let node,root;
test('actual review precedes dependency installation and runtime checks',async()=>{
  const state={phase:'reviewing',attempt:0,files:5,checks:[{id:'files',status:'pending'},{id:'dependencies',status:'pending'},{id:'tests',status:'pending'},{id:'preview',status:'pending'}],pipeline:{stage:'reviewing',completed:2,total:5},generation:{phase:'receiving',chars:400,calls:5,batches:3}};
  await act(async()=>root.render(<BuildProgress state={state}/>));
  expect(node.textContent).toContain('مراجعة الملفات');expect(node.textContent).toContain('2 / 5');
  const stages=[...node.querySelectorAll('.df-run-stages > span')];
  expect(stages.map(stage=>stage.textContent)).toEqual(['الهيكل','الملفات','المراجعة','المتطلبات','الفحص','المعاينة']);
  expect(stages.map(stage=>stage.dataset.status)).toEqual(['passed','passed','running','pending','pending','pending']);
  expect(node.querySelector('progress').value).toBe(2);
});
beforeEach(()=>{global.IS_REACT_ACT_ENVIRONMENT=true;node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
test.each(['writing','repairing','failed'])('old or current internal agents stay hidden in the %s progress card',async phase=>{
  const state={phase,attempt:phase==='repairing'?1:0,files:3,checks:[],startedAt:Date.now(),agents:[
    {role:'architect',status:phase==='failed'?'failed':'running'},
    {role:'designer',status:'completed'},
    {role:'coder',status:'completed'},
    {role:'reviewer',status:'failed'},
  ]};
  await act(async()=>root.render(<BuildProgress state={state}/>));
  expect(node.querySelector('.df-agent-team')).toBeNull();
  expect(node.textContent).not.toContain('البرمجة');
  expect(node.textContent).not.toContain('مراجعة الكود');
  for(const label of ['تشخيص البنية','تشخيص التصميم','التخطيط'])expect(node.textContent).not.toContain(label);
  expect(node.querySelector('.df-run-stages').textContent).toContain('الملفات');
});

test('live source reception marks only the files stage running and exposes real counters',async()=>{
  const state={phase:'writing',attempt:0,files:4,checks:[{id:'files',label:'كتابة الملفات',status:'pending'},{id:'tests',label:'اختبارات المشروع',status:'pending'}],generation:{phase:'receiving',chars:1234,reasoningChars:0,calls:3,batches:2}};
  await act(async()=>root.render(<BuildProgress state={state}/>));
  expect(node.textContent).toContain('جارٍ استقبال ملفات المشروع');
  expect(node.textContent).toContain('1,234 حرف مستلم');
  expect(node.textContent).toContain('4 ملف');
  expect(node.querySelector('.df-run-stages span').dataset.status).toBe('running');
  expect(node.querySelector('progress').hasAttribute('value')).toBe(false);
  expect(node.querySelectorAll('[data-status=passed]')).toHaveLength(0);
});

test('waiting for a provider is distinguishable from receiving thinking progress',async()=>{
  const state={phase:'writing',attempt:0,files:0,checks:[],generation:{phase:'waiting_provider',chars:0,reasoningChars:0,calls:1,batches:0}};
  await act(async()=>root.render(<BuildProgress state={state}/>));
  expect(node.textContent).toContain('بانتظار رد النموذج');expect(node.textContent).toContain('لم تصل بيانات من النموذج بعد');
  await act(async()=>root.render(<BuildProgress state={{...state,generation:{...state.generation,phase:'receiving',reasoningChars:80}}}/>));
  expect(node.textContent).toContain('النموذج يفكر');expect(node.textContent).toContain('وصل تقدم في التفكير');
});
