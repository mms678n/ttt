import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";
import Message from "./Message";

const mockListeners = new Set();
let mockLiveContent = "";
let mockLiveReasoning = "";

jest.mock("@/context/ChatContext", () => ({
  useChat: () => ({ regenerate: jest.fn(), editAndResend: jest.fn() }),
}));

jest.mock("@/context/streamStore", () => ({
  streamStore: {
    subscribe: (listener) => { mockListeners.add(listener); return () => mockListeners.delete(listener); },
    getSnapshot: () => mockLiveContent,
    getReasoningSnapshot: () => mockLiveReasoning,
  },
}));

jest.mock("@/components/chat/Markdown", () => ({ children }) => <div data-testid="mock-markdown">{children}</div>);
jest.mock("@/components/chat/GateMessage", () => () => null);
jest.mock("@/components/chat/FileChip", () => () => null);
jest.mock("@/components/chat/TokenBalance", () => ({ MessageUsageStats: () => null }));
jest.mock("@/lib/aiClient", () => ({ detectLanguage: () => "en" }));

let container;
let root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockLiveContent = "";
  mockLiveReasoning = "";
  mockListeners.clear();
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("renders a right-aligned user bubble without an avatar", async () => {
  await act(async () => root.render(<Message message={{ id: "user-1", role: "user", content: "Hello" }} isStreamingThis={false} />));
  expect(container.querySelector('[data-testid="user-message-user-1"] .chat-message-avatar')).toBeNull();
  expect(container.querySelector(".chat-user-bubble").textContent).toBe("Hello");
  expect(container.querySelector(".deepseek-message-user")).not.toBeNull();
});

test("uses saved reasoning, duration, and aria-expanded collapse state", async () => {
  await act(async () => root.render(<Message message={{ id: "assistant-1", role: "assistant", content: "Answer", reasoning: "I checked the inputs.", reasoningDurationMs: 2200 }} isStreamingThis={false} />));
  const toggle = container.querySelector('[data-testid="reasoning-toggle-assistant-1"]');
  expect(container.querySelector('[data-testid="reasoning-panel"]').textContent).toContain("I checked the inputs.");
  expect(container.textContent).toContain("2.2s");
  expect(toggle.getAttribute("aria-expanded")).toBe("true");
  await act(async () => toggle.click());
  expect(toggle.getAttribute("aria-expanded")).toBe("false");
  expect(container.querySelector("#reasoning-panel-assistant-1").hidden).toBe(true);
});

test("subscribes to live reasoning separately and does not fake a thinking panel while waiting", async () => {
  await act(async () => root.render(<Message message={{ id: "assistant-2", role: "assistant", content: "" , reasoningStartedAt: Date.now() - 1200 }} isStreamingThis />));
  expect(container.querySelector('[data-testid="reasoning-panel"]')).toBeNull();
  expect(container.querySelector('[role="status"]').textContent).toContain("جارٍ التوليد");
  expect(container.textContent).not.toContain("c/s");

  mockLiveReasoning = "Only provider reasoning is shown.";
  await act(async () => { mockListeners.forEach((listener) => listener()); });
  expect(container.querySelector('[data-testid="reasoning-panel"]').textContent).toContain("Only provider reasoning is shown.");
  expect(container.querySelector('[role="status"]')).toBeNull();
});
