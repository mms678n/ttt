import { parseStreamMarkdown } from "./streamMarkdown";

test("an unfinished code fence never truncates the last three characters", () => {
  const state = parseStreamMarkdown("```python\nprint(123)");
  expect(state.tail).toEqual({ type: "code", language: "python", value: "print(123)", prefix: "" });
});
test("completed prefix segments keep their identity across appended deltas", () => {
  const first = parseStreamMarkdown("intro\n```js\nconst a = 1;\n```\nTail");
  const next = parseStreamMarkdown(first.source + " more", first);
  expect(next.segments).toBe(first.segments);
  expect(next.segments[1].value).toBe("const a = 1;");
  expect(next.tail.value).toBe("Tail more");
});
test("partial language header is plain text until its newline arrives", () => {
  expect(parseStreamMarkdown("```pyt").tail.value).toBe("```pyt");
  expect(parseStreamMarkdown("```python\nx=12").tail.value).toBe("x=12");
});
test("a shorter replacement or different message resets cached content", () => {
  const before = parseStreamMarkdown("```py\nold\n```\nrest");
  const next = parseStreamMarkdown("New message", before);
  expect(next.segments).toEqual([]);
  expect(next.tail.value).toBe("New message");
});
test("supports tilde fences and preserves an interior shorter backtick fence", () => {
  const tilde = parseStreamMarkdown("~~~js\nlet x=1;\n~~~\nend");
  expect(tilde.segments[0].value).toBe("let x=1;");
  const wide = parseStreamMarkdown("````text\n```example\n````\n");
  expect(wide.segments[0].value).toBe("```example");
});
test("closing fence without newline can be extended by a later chunk", () => {
  const before = parseStreamMarkdown("```js\nhello\n```");
  const next = parseStreamMarkdown(before.source + "not-a-close", before);
  expect(next.tail.value).toContain("```not-a-close");
});

test("keeps formatted prose in append-only parts and leaves only the active tail", () => {
  const state = parseStreamMarkdown("## Heading\n\n- one\n- two\n\n| a | b |\n| - | - |\n| 1 | 2 |\n\n[docs](https://example.test)\n\n```js\nconst x =");
  expect(state.segments.map(({ type }) => type)).toEqual(["text", "text", "text", "text"]);
  expect(state.segments[0].value).toContain("## Heading");
  expect(state.segments[1].value).toContain("- two");
  expect(state.segments[2].value).toContain("| 1 | 2 |");
  expect(state.segments[3].value).toContain("[docs](https://example.test)");
  expect(state.tail).toEqual({ type: "code", language: "js", value: "const x =", prefix: "" });
});

test("finalizing a closing fence does not create a replacement segment", () => {
  const live = parseStreamMarkdown("before\n\n```js\nconst x = 1\n```");
  const done = parseStreamMarkdown(live.source, live, { finalize: true });
  expect(done.segments).toBe(live.segments);
  expect(done.tail).toEqual({ type: "code", language: "js", value: "const x = 1", prefix: "", closed: true });
});

test('an open streamed code block preserves every newline received so far', () => {
  const first = parseStreamMarkdown('```js\nconst x = 1;\n');
  expect(first.tail.value).toBe('const x = 1;\n');
  const second = parseStreamMarkdown(first.source + '\n', first);
  expect(second.tail.value).toBe('const x = 1;\n\n');
  const done = parseStreamMarkdown(second.source + '```\n', second);
  expect(done.segments[0].value).toBe('const x = 1;\n');
});

test('a CRLF fence separator is removed as a pair without leaving a stray carriage return', () => {
  const open = parseStreamMarkdown('```js\r\nconst a = 1;\r\n\r\n');
  expect(open.tail.value).toBe('const a = 1;\r\n\r\n');
  const done = parseStreamMarkdown(open.source + '```\r\n', open);
  expect(done.segments[0].value).toBe('const a = 1;\r\n');
});

test('indentation of a fenced code block is removed consistently while streaming and on completion', () => {
  const live = parseStreamMarkdown('  ```js\n  first\n  \n');
  expect(live.tail.value).toBe('first\n\n');
  const complete = parseStreamMarkdown(live.source + '  ```\n', live);
  expect(complete.segments[0].value).toBe('first\n');
});

test('list and quoted fences stay together as Markdown and never create a false standalone fence', () => {
  for (const source of ['- ```unknown\n  first\n  ```\n', '- ```unknown\n  first\n  \n  \n', '> ```unknown\n> first\n> \n> \n']) {
    let state = null;
    for (const chunk of source) state = parseStreamMarkdown((state?.source || '') + chunk, state);
    expect(state.segments).toEqual([]);
    expect(state.tail.type).toBe('text');
    expect(state.tail.value).toBe(source);
    const done = parseStreamMarkdown(source, state, { finalize: true });
    expect(done.tail).toBe(state.tail);
  }
});
