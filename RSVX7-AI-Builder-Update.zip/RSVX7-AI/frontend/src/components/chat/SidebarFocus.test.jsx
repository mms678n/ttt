import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import ChatLayout from './ChatLayout';

jest.mock('@/context/ChatContext', () => ({ useChat: () => ({ prefs: {}, activeChat: null }) }));
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ user: {} }) }));
jest.mock('@/builder/BuilderProjectsContext', () => ({ BuilderProjectsProvider: ({children}) => <>{children}</> }));
jest.mock('@/components/design/ThemeSwitcher', () => () => null);
jest.mock('./SettingsDialog', () => () => null);
jest.mock('./Message', () => () => null);
jest.mock('./ChatInput', () => () => <textarea aria-label="Composer" />);
jest.mock('./ModelPicker', () => () => <button>Models</button>);
jest.mock('./Sidebar', () => ({
  __esModule: true,
  default: ({open, onToggle}) => <aside id="chat-sidebar" hidden={!open}><button onClick={onToggle} data-testid="sidebar-collapse-btn">Close</button><button>Last sidebar action</button></aside>,
  SidebarOpenButton: ({onClick}) => <button onClick={onClick} data-testid="sidebar-open-btn">Open</button>,
}));
let node, root;
beforeEach(() => {
 global.IS_REACT_ACT_ENVIRONMENT = true;
 Object.defineProperty(window, 'innerWidth', {configurable:true, value:390});
 node = document.createElement('div'); document.body.appendChild(node); root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});

test('mobile drawer receives focus, wraps Tab, closes on Escape and restores focus', async()=>{
 await act(async()=>root.render(<ChatLayout/>));
 const open=node.querySelector('[data-testid=sidebar-open-btn]');
 open.focus();
 await act(async()=>open.click());
 const close=node.querySelector('[data-testid=sidebar-collapse-btn]');
 expect(document.activeElement).toBe(close);
 const main=node.querySelector('.chat-main');
 expect(main.hasAttribute('inert')).toBe(true);
 await act(async()=>close.dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true,cancelable:true})));
 expect(document.activeElement.textContent).toBe('Last sidebar action');
 await act(async()=>document.activeElement.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true})));
 expect(node.querySelector('#chat-sidebar').hidden).toBe(true);
 expect(main.hasAttribute('inert')).toBe(false);
 expect(document.activeElement).toBe(node.querySelector('[data-testid=sidebar-open-btn]'));
});
