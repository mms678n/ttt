import React, { useState } from "react";
import { CheckCircle2, Coins, ExternalLink, RefreshCw, Send, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSubscription } from "@/context/SubscriptionContext";
import { useChat } from "@/context/ChatContext";
import { toast } from "sonner";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import "@/i18n/catalogs/monthly";
const BACKEND = process.env.REACT_APP_BACKEND_URL || "";
export default function GateMessage({ message, onOpenDashboard }) {
  const { t, dir } = useI18n("chat");
  const gate = message.gate;
  if (!gate) return null;
  return <div className="chat-message deepseek-assistant-message" data-testid={`gate-message-${gate.kind}-${message.id}`} dir={dir}><div className="chat-message-body">{gate.kind === "plan" && <PlanCard data={gate.data} onOpenDashboard={onOpenDashboard} />}{gate.kind === "topup" && <TopUpCard data={gate.data} />}{gate.kind === "membership" && <MembershipCard data={gate.data} messageId={message.id} onOpenDashboard={onOpenDashboard} />}{gate.kind === "membership-ok" && <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4 text-sm text-emerald-200" data-testid="gate-membership-success">{gate.data?.message || t("تم التحقق بنجاح.")}</div>}</div></div>;
}
function TopUpCard({ data }) {
  const { t, dir } = useI18n("chat");
  const { openRenewalModal } = useSubscription();
  return <div dir={dir} className="deepseek-gate-card max-w-lg rounded-xl border border-[#9D3E59]/50 bg-[#9D3E59]/10 p-5" data-testid="gate-topup-card"><div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-[#E69BB0]"><Coins size={16} aria-hidden="true" />{t("الرصيد")}</div><p className="mb-4 whitespace-pre-wrap text-sm leading-7 text-zinc-200">{data?.message || t("نفد رصيد التوكنات. يرجى شحن الرصيد للمتابعة.")}</p><Button onClick={() => { window.location.hash = "#dashboard"; openRenewalModal?.(data); }} data-testid="gate-topup-cta" className="h-10 rounded-lg bg-[#9D3E59] text-white hover:bg-[#ad4c6b]"><Coins size={15} className="ml-1.5" aria-hidden="true" />{data?.cta || t("شحن الرصيد")}</Button></div>;
}
function MembershipCard({ data, messageId }) {
  const { t, dir } = useI18n("chat");
  const { updateGateData } = useChat();
  const [busy, setBusy] = useState(false);
  const groups = Array.isArray(data?.groups) ? data.groups : [];
  const linked = data?.linked !== false;
  const verify = async () => {
    setBusy(true);
    try {
      const token = localStorage.getItem("rsvx7_token") || "";
      const response = await fetch(`${BACKEND}/api/telegram/membership-check`, { headers: { Authorization: `Bearer ${token}` } });
      const result = await response.json();
      if (!response.ok) throw new Error(result?.detail || t("فشل التحقق"));
      if (result?.ok) { updateGateData?.(messageId, { kind: "membership-ok", data: { message: "تم التحقّق بنجاح. يمكنك الآن استخدام rsvx7." } }); toast.success(t("تم التحقق")); }
      else { const missing = (result.groups || []).filter((group) => !group.joined); updateGateData?.(messageId, { kind: "membership", data: { ...data, linked: result.linked !== false, groups: missing, message: result.linked === false ? "يرجى ربط حساب Telegram أولاً، ثم الانضمام إلى المجموعات التالية." : "لا تزال هناك مجموعات لم تنضم إليها. انضم ثم اضغط تحقّق مرة أخرى." } }); }
    } catch (error) { toast.error(error.message || t("فشل التحقق")); } finally { setBusy(false); }
  };
  return <div dir={dir} className="deepseek-gate-card max-w-lg rounded-xl border border-[#9D3E59]/50 bg-[#9D3E59]/10 p-5" data-testid="gate-membership-card"><div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-[#E69BB0]"><ShieldCheck size={16} aria-hidden="true" />{t("بوابة Telegram")}</div><p className="mb-4 whitespace-pre-wrap text-sm leading-7 text-zinc-200">{data?.message || t("يجب الانضمام إلى مجموعات Telegram المطلوبة قبل استخدام rsvx7.")}</p>{!linked && <div className="mb-3 rounded-md border border-amber-500/30 bg-amber-500/10 p-2 text-xs text-amber-200">{t("حسابك غير مربوط بـ Telegram. اربطه أولاً من الإعدادات.")}</div>}<div className="mb-4 space-y-1.5">{groups.map((group) => <a key={group._id || group.username} href={group.invite_link || `https://t.me/${(group.username || "").replace(/^@/, "")}`} target="_blank" rel="noopener noreferrer" data-testid={`gate-join-${(group.username || "").replace(/^@/, "")}`} className="flex min-h-[44px] items-center gap-2 rounded-md border border-[#30353F] bg-[#101318] px-3 text-sm text-white hover:bg-[#202631]"><Send size={15} className="text-[#E69BB0]" aria-hidden="true" /><span className="min-w-0 flex-1">{t("انضم إلى {group}", { group: group.name || group.username })}</span><ExternalLink size={14} className="text-zinc-500" aria-hidden="true" /></a>)}</div><Button onClick={verify} disabled={busy} data-testid="gate-membership-verify" className="h-10 rounded-lg bg-[#9D3E59] text-white hover:bg-[#ad4c6b]"><RefreshCw size={15} className={busy ? "ml-1.5 animate-spin" : "ml-1.5"} aria-hidden="true" />{busy ? t("جارٍ التحقق…") : t("تحقّق")}</Button></div>;
}

function PlanCard({ data, onOpenDashboard }) {
  const { t } = useI18n("monthly");
  return <div className="deepseek-gate-card max-w-lg rounded-xl border border-[#9D3E59]/50 p-5" data-testid="gate-plan-card"><p>{t("باقتك لا تتيح هذه الميزة.")} <strong dir="ltr">{data?.required_plan?.toUpperCase()}</strong></p><Button className="mt-4" onClick={() => onOpenDashboard ? onOpenDashboard() : (window.location.hash = "#dashboard")}>{t("عرض الباقات")}</Button></div>;
}
