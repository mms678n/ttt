import React, { act } from "react";
import { createRoot } from "react-dom/client";
import WelcomeState from "./WelcomeState";
import ModelPicker, { MODELS } from "./ModelPicker";
import Landing from "@/pages/Landing";
import { setLanguage } from "@/i18n";

jest.mock("@/components/ui/dropdown-menu", () => {
  const Wrap = ({ children }) => <div>{children}</div>;
  const Trigger = ({ children }) => <>{children}</>;
  const Content = ({ children, ...props }) => <div {...props}>{children}</div>;
  const Item = ({ children, onClick, ...props }) => <button type="button" onClick={onClick} {...props}>{children}</button>;
  return {
    DropdownMenu: Wrap,
    DropdownMenuTrigger: Trigger,
    DropdownMenuContent: Content,
    DropdownMenuItem: Item,
    DropdownMenuSub: Wrap,
    DropdownMenuSubContent: Content,
    DropdownMenuSubTrigger: Item,
  };
});

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("ar");
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("uses the cybersecurity and penetration-testing description in Arabic", async () => {
  await act(async () => root.render(<WelcomeState showSuggestions={false} />));
  expect(container.querySelector(".chat-welcome-subtitle").textContent).toBe("مساعد متخصص في الأمن السيبراني واختبار الاختراق");

  await act(async () => root.render(<Landing />));
  expect(container.querySelector(".landing-eyebrow").textContent).toContain("الأمن السيبراني واختبار الاختراق");
});

test("translates the security description to English without removing language switching", async () => {
  setLanguage("en");
  await act(async () => root.render(<WelcomeState showSuggestions={false} />));
  expect(container.querySelector(".chat-welcome").getAttribute("dir")).toBe("ltr");
  expect(container.querySelector(".chat-welcome-subtitle").textContent).toBe("AI for cybersecurity and penetration testing");

  await act(async () => root.render(<Landing />));
  expect(container.querySelector(".landing-eyebrow").textContent).toContain("Cybersecurity & penetration testing");
  expect(container.querySelector('[data-testid="language-switcher"]')).not.toBeNull();
});

test("keeps the three platform models and displays their actual assigned providers", async () => {
  const models = {kaligpt:{model:'provider/fast'},deepdark:{model:'provider/reasoning'},'rsvx7-ai':{model:'provider/code'}};
  await act(async () => root.render(<ModelPicker value="kaligpt" models={models} onChange={jest.fn()} />));
  const options = [...container.querySelectorAll('[data-testid^="model-option-"]')];
  expect(options).toHaveLength(MODELS.length);
  expect(options.map((option) => option.querySelector("strong").textContent)).toEqual(["KaliGPT", "DeepDark", "rsvx7"]);
  expect(options.map(option => option.querySelector('small').textContent)).toEqual(['provider/fast','provider/reasoning','provider/code']);
  expect(container.textContent.toLowerCase()).not.toContain("api key");
  expect(container.textContent).not.toContain("OpenRouter");
});
