import React, { memo, useLayoutEffect, useRef, useState } from 'react';
import { streamStore } from '@/context/streamStore';
import { createRevealQueue } from './referenceReveal';
import Markdown from './Markdown';
function Inline({ text }) {
 return text.split(/(`[^`\n]+`|\*\*[^*\n]+\*\*)/g).map((part,i)=>part.startsWith('`')&&part.endsWith('`')?<code key={i}>{part.slice(1,-1)}</code>:part.startsWith('**')&&part.endsWith('**')?<b key={i}>{part.slice(2,-2)}</b>:part);
}
function Code({ text }) {
 const [copied,setCopied]=useState(false),timer=useRef(null);
 useLayoutEffect(()=>()=>clearTimeout(timer.current),[]);
 const code=text.replace(/^[\w+-]*\n/,'');
 return <div className="code"><button className="cp" type="button" onClick={async()=>{try{await navigator.clipboard.writeText(code);setCopied(true);clearTimeout(timer.current);timer.current=setTimeout(()=>setCopied(false),1500)}catch{setCopied(false)}}}>{copied?'تم النسخ':'نسخ'}</button><pre dir="ltr">{code}</pre></div>;
}
export function ReferenceMarkdown({text}) {return String(text||'').split('```').map((part,i)=>i%2?<Code key={i} text={part}/>:<Inline key={i} text={part}/>)}
export default memo(function ReferenceStream({message,streaming,flushKey=0,onPaint,onBusy,platform=false,hideDots=false}) {
 const host=useRef(null),dots=useRef(null),queue=useRef(null),latest=useRef(null);latest.current={message,streaming,onPaint,onBusy,hideDots};
 const [settled,setSettled]=useState(streaming?null:message.content||'');const sync=useRef(()=>{});
 useLayoutEffect(()=>{
  let mounted=true;const id=message.id;const motion=window.matchMedia?.('(prefers-reduced-motion: reduce)');const paint=()=>latest.current.onPaint?.();
  const replace=text=>{if(host.current)host.current.textContent=text;if(dots.current)dots.current.hidden=Boolean(text)||latest.current.hideDots;paint()};
  const append=text=>{const el=host.current;if(!el)return;if(dots.current)dots.current.hidden=true;const span=document.createElement('span');span.className='w';span.textContent=text;el.append(span);if(el.childNodes.length>128){if(el.firstChild.nodeType!==3)el.prepend(document.createTextNode(''));while(el.childNodes.length>96){el.firstChild.appendData(el.childNodes[1].textContent);el.childNodes[1].remove()}}paint()};
  sync.current=()=>{if(!mounted)return;const current=latest.current,active=current.streaming;const raw=active?streamStore.getSnapshot(id):null;
   if(active&&raw===null&&queue.current)return;
   const target=raw??current.message.content??'';
   if(active&&!queue.current){const initial=current.message.content||'';setSettled(null);replace(initial);current.onBusy?.(id,true);queue.current=createRevealQueue({append,replace,initial,complete:()=>{if(!mounted)return;const completed=host.current?.textContent||'';queue.current=null;setSettled(completed);latest.current.onBusy?.(id,false);paint()}})}
   if(queue.current){queue.current.update(target);if(!active)queue.current.finish(['abort','error'].includes(current.message.finishReason)||document.hidden||motion?.matches);else if(document.hidden||motion?.matches)queue.current.flush()}else if(!active)setSettled(target);
  };
  const unsubscribe=streamStore.subscribe(()=>sync.current());const visibility=()=>{if(document.hidden||motion?.matches)queue.current?.flush()};document.addEventListener('visibilitychange',visibility);motion?.addEventListener?.('change',visibility);sync.current();
  return()=>{mounted=false;unsubscribe();queue.current?.dispose();queue.current=null;document.removeEventListener('visibilitychange',visibility);motion?.removeEventListener?.('change',visibility);latest.current.onBusy?.(id,false)};
 },[message.id]);
 useLayoutEffect(()=>{sync.current()},[message.content,message.finishReason,streaming]);
 useLayoutEffect(()=>{if(flushKey)queue.current?.flush()},[flushKey]);
 useLayoutEffect(()=>{if(settled!==null&&host.current)host.current.textContent='';onPaint?.()},[settled,onPaint]);
 return <><span ref={dots} className="dots" hidden={settled!==null || hideDots} role={hideDots ? undefined : "status"} aria-live="polite" aria-label="جارٍ التوليد"><b/><b/><b/>{platform&&<span className="sr-only">جارٍ التوليد…</span>}</span><div ref={host} className={`reference-live-text${platform ? " markdown" : ""}`} dir="auto" hidden={settled!==null}/>{settled!==null&&(platform ? <Markdown>{settled}</Markdown> : <ReferenceMarkdown text={settled}/>)}</>;
});
