/** Presentation only: persistence and the network retain the complete response. */
export function createRevealQueue({ append, replace, complete, initial = '', schedule = requestAnimationFrame, cancel = cancelAnimationFrame }) {
  let target = initial, shown = initial, ended = false, disposed = false, frame = null, completed = false;
  const stopFrame = () => { if (frame !== null) cancel(frame); frame = null; };
  const done = () => { if (ended && shown === target && !completed) { completed = true; complete(); } };
  const tick = () => {
    frame = null;
    if (disposed) return;
    if (!target.startsWith(shown)) { shown = ''; replace(''); }
    const pending = target.slice(shown.length);
    if (pending) {
      let count = Math.max(2, Math.ceil(pending.length / 14));
      if (count < pending.length && /[\uD800-\uDBFF]/.test(pending[count - 1]) && /[\uDC00-\uDFFF]/.test(pending[count])) count++;
      const part = pending.slice(0, count); shown += part; append(part);
    }
    if (shown !== target) request(); else done();
  };
  const request = () => { if (!disposed && frame === null && shown !== target) frame = schedule(tick); };
  return {
    update(text) { if (disposed) return; target = String(text || ''); request(); },
    finish(immediate = false) { if (disposed) return; ended = true; if (immediate) this.flush(); else { request(); done(); } },
    flush() { if (disposed) return; stopFrame(); if (shown !== target) { shown = target; replace(shown); } done(); },
    dispose() { disposed = true; stopFrame(); },
  };
}
