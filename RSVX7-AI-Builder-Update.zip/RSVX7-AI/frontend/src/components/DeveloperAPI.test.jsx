import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import DeveloperAPI from './DeveloperAPI';
jest.mock('@/i18n', () => ({ useI18n: () => ({ t: value => value }) }));
let root, node;
beforeEach(() => { global.IS_REACT_ACT_ENVIRONMENT = true; node=document.createElement('div'); document.body.appendChild(node); root=createRoot(node); });
afterEach(async () => { await act(async () => root.unmount()); node.remove(); });
const reply = data => ({ok:true,json:async()=>data});
test('paid users can create and revoke their key', async () => {
  const fetcher=jest.fn().mockResolvedValueOnce(reply({configured:false,paid:true}))
    .mockResolvedValueOnce(reply({key:'rsvx7_fixture.secret'})).mockResolvedValueOnce(reply({ok:true}));
  await act(async()=>root.render(<DeveloperAPI authFetch={fetcher}/>));
  await act(async()=>node.querySelector('[data-testid="api-create"]').click());
  expect(node.textContent).toContain('rsvx7_fixture.secret');
  await act(async()=>node.querySelector('[data-testid="api-revoke"]').click());
  expect(node.textContent).not.toContain('rsvx7_fixture.secret');
});
test('free accounts cannot create a key', async () => {
  const fetcher=jest.fn().mockResolvedValue(reply({configured:false,paid:false}));
  await act(async()=>root.render(<DeveloperAPI authFetch={fetcher}/>));
  expect(node.textContent).toContain('Pro أو Max');
  expect(node.querySelector('[data-testid="api-create"]')).toBeNull();
});
