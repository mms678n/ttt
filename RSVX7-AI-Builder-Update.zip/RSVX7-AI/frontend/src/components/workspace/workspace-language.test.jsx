import React, { act } from "react";
import { createRoot } from "react-dom/client";
import ProjectSwitcher from "./ProjectSwitcher";
import { setLanguage } from "@/i18n";
import "@/i18n/catalogs/workspace";

const mockWorkspace = {
  projects: [{ _id: "project-1", name: "مشروعي", description: "", conversation_count: 123, icon: "Folder", color: "var(--workspace-brand)" }],
  archivedProjects: [],
  currentProjectId: "project-1",
  setCurrentProjectId: jest.fn(),
  updateProject: jest.fn(),
  deleteProject: jest.fn(),
  touchProjectOpened: jest.fn(),
  createProject: jest.fn(),
};

jest.mock("@/context/WorkspaceContext", () => ({ useWorkspace: () => mockWorkspace }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("@/components/ui/input", () => {
  const React = require("react");
  return { Input: React.forwardRef((props, ref) => <input ref={ref} {...props} />) };
});
jest.mock("@/components/ui/textarea", () => {
  const React = require("react");
  return { Textarea: React.forwardRef((props, ref) => <textarea ref={ref} {...props} />) };
});
jest.mock("@/components/ui/label", () => ({ Label: ({ children, ...props }) => <label {...props}>{children}</label> }));
jest.mock("@/components/ui/dialog", () => {
  const React = require("react");
  const Wrap = ({ children, ...props }) => <div {...props}>{children}</div>;
  return {
    Dialog: ({ open, children }) => open ? <div role="dialog">{children}</div> : null,
    DialogContent: Wrap,
    DialogHeader: Wrap,
    DialogTitle: ({ children, ...props }) => <h2 {...props}>{children}</h2>,
    DialogFooter: Wrap,
    DialogDescription: ({ children, ...props }) => <p {...props}>{children}</p>,
  };
});
jest.mock("@/components/ui/dropdown-menu", () => {
  const React = require("react");
  const Wrap = ({ children, ...props }) => <div {...props}>{children}</div>;
  return {
    DropdownMenu: Wrap,
    DropdownMenuContent: Wrap,
    DropdownMenuTrigger: ({ children }) => children,
    DropdownMenuItem: ({ children, onClick, ...props }) => <button type="button" onClick={onClick} {...props}>{children}</button>,
    DropdownMenuSeparator: () => null,
  };
});
jest.mock("@/components/design/Primitives", () => ({
  ActionButton: ({ children, ...props }) => <button type="button" {...props}>{children}</button>,
  StatusNote: ({ children }) => <div role="alert">{children}</div>,
}));

describe("workspace English locale", () => {
  let node;
  let root;

  beforeEach(() => {
    global.IS_REACT_ACT_ENVIRONMENT = true;
    localStorage.clear();
    mockWorkspace.setCurrentProjectId.mockClear();
    mockWorkspace.touchProjectOpened.mockClear();
    setLanguage("en");
    node = document.createElement("div");
    document.body.appendChild(node);
    root = createRoot(node);
  });

  afterEach(async () => {
    await act(async () => root.unmount());
    node.remove();
    setLanguage("ar");
  });

  test("project tabs move with the keyboard without activating nested row actions", async () => {
    await act(async () => root.render(<ProjectSwitcher open onClose={jest.fn()} />));
    const active = node.querySelector('[data-testid="tab-active-projects"]');
    const archived = node.querySelector('[data-testid="tab-archived-projects"]');
    active.focus();
    await act(async () => active.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true })));
    expect(archived.getAttribute('aria-selected')).toBe('true');
    expect(document.activeElement).toBe(archived);
    await act(async () => active.click());
    mockWorkspace.setCurrentProjectId.mockClear();
    await act(async () => node.querySelector('[data-testid="project-menu-project-1"]').dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })));
    expect(mockWorkspace.setCurrentProjectId).not.toHaveBeenCalled();
  });

  test("translates UI, formats dynamic count, sets direction, and keeps project selection behavior", async () => {
    await act(async () => root.render(<ProjectSwitcher open onClose={jest.fn()} />));

    expect(node.querySelector('[data-testid="projects-dialog"]').getAttribute("dir")).toBe("ltr");
    expect(node.textContent).toContain("Switch project");
    expect(node.textContent).toContain("123 conversations");
    expect(node.textContent).toContain("مشروعي");
    expect(node.querySelector('[data-testid="projects-search-input"]').getAttribute("placeholder")).toBe("Search projects…");

    await act(async () => node.querySelector('[data-testid="project-row-project-1"]').click());
    expect(mockWorkspace.setCurrentProjectId).toHaveBeenCalledWith("project-1");
    expect(mockWorkspace.touchProjectOpened).toHaveBeenCalledWith("project-1");
  });
});
