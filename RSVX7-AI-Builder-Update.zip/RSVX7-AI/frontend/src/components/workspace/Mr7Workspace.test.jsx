import fs from "fs";
import path from "path";

const readOwned = (name) => fs.readFileSync(path.join(__dirname, name), "utf8");

describe("MR7 workspace visual contract", () => {
  test("uses scoped black/red OKLCH variables and measured control geometry", () => {
    const css = readOwned("workspace-ui.css");

    expect(css).toContain("--workspace-bg: var(--background, oklch(10% .005 0))");
    expect(css).toContain("--workspace-brand: var(--primary, oklch(65% .18 25))");
    expect(css).toContain("border-radius: 8px");
    expect(css).toContain(".workspace-menu { min-width: 185px; border: 1px solid var(--workspace-border); border-radius: 8px");
    expect(css).toContain(".workspace-dialog .ds-input { min-height: 40px");
    expect(css).toContain(".workspace-search-field .ds-input { min-height: 48px");
    expect(css).toContain("border-radius: 6px");
    expect(css).not.toMatch(/#[0-9a-f]{3,8}/i);
    expect(css).not.toMatch(/\b(?:purple|violet|bluegray|blue-grey)\b/i);
  });

  test("keeps inline project colors variable-backed and keeps bilingual dynamic UI", () => {
    const switcher = readOwned("ProjectSwitcher.jsx");
    const settings = readOwned("ProjectSettingsDialog.jsx");
    const search = readOwned("GlobalSearchDialog.jsx");
    const catalog = readOwned("../../i18n/catalogs/workspace.js");

    expect(switcher).toContain('export const WORKSPACE_BRAND_COLOR = "var(--workspace-brand)"');
    expect(switcher).not.toMatch(/style=\{\{[^}]*#[0-9a-f]{3,8}/i);
    expect(settings).not.toMatch(/style=\{\{[^}]*#[0-9a-f]{3,8}/i);
    expect(search).not.toMatch(/style=\{\{[^}]*#[0-9a-f]{3,8}/i);
    expect(catalog).toContain('"إعادة المحاولة": "Try again"');
  });
});
