import React, { useEffect, useState } from 'react';
import { useI18n } from '@/i18n';
import { ActionButton, Panel } from '@/components/design/Primitives';
import { copyToClipboard } from '@/lib/clipboard';

export default function DeveloperAPI({ authFetch }) {
  const { t } = useI18n('account');
  const [status, setStatus] = useState(null);
  const [key, setKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  useEffect(() => {
    let active = true;
    authFetch('/developer/key').then(async r => {
      if (!r.ok) throw new Error();
      const data = await r.json(); if (active) setStatus(data);
    }).catch(() => { if (active) setMessage('تعذر تحميل إعدادات API'); });
    return () => { active = false; };
  }, [authFetch]);
  async function change(method) {
    setBusy(true); setMessage('');
    try {
      const r = await authFetch('/developer/key', { method });
      const data = await r.json();
      if (!r.ok) throw new Error(data?.detail?.message || data?.detail || t('تعذر تنفيذ الطلب'));
      setKey(data.key || '');
      setStatus(old => ({ ...old, configured: method === 'POST' }));
    } catch (e) { setMessage(e.message || t('تعذر تنفيذ الطلب')); }
    finally { setBusy(false); }
  }
  return <Panel className="dashboard-panel">
    <h3>{t('واجهة المطورين API')}</h3>
    <p className="dashboard-muted">{t('استخدم نماذج باقتك من تطبيقاتك، ويُخصم الاستخدام من رصيد حسابك.')}</p>
    <p dir="ltr"><code>{typeof window === 'undefined' ? '' : window.location.origin}/api/v1</code></p>
    {status && !status.paid && <p>{t('يتطلب باقة Pro أو Max نشطة.')}</p>}
    {status?.paid && <>
      <p>{status.configured ? t('لديك مفتاح نشط. إنشاء مفتاح جديد يلغي المفتاح السابق.') : t('لا يوجد مفتاح نشط.')}</p>
      <ActionButton data-testid="api-create" loading={busy} onClick={() => change('POST')}>{t('إنشاء مفتاح API')}</ActionButton>{' '}
    </>}
    {status?.configured && <ActionButton data-testid="api-revoke" tone="ghost" loading={busy} onClick={() => change('DELETE')}>{t('إلغاء المفتاح')}</ActionButton>}
    {key && <div><p>{t('انسخ المفتاح الآن؛ لن يظهر مرة أخرى.')}</p><code dir="ltr" style={{overflowWrap:'anywhere'}}>{key}</code>{' '}
      <ActionButton tone="ghost" onClick={async () => { try { await copyToClipboard(key); setMessage(t('تم النسخ')); } catch { setMessage(t('تعذر النسخ')); } }}>{t('نسخ المفتاح')}</ActionButton></div>}
    {message && <p role="status">{message}</p>}
  </Panel>;
}
