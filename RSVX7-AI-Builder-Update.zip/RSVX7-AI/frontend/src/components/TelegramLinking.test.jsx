import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Register from "@/pages/Register";
import TelegramGate from "./TelegramGate";

const mockRegister = jest.fn();
const mockActivate = jest.fn();
const mockAuthFetch = jest.fn();
const mockRefresh = jest.fn();
const mockLogout = jest.fn();
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ user: { _id: "user1", username: "new_user", role: "user" }, register: mockRegister, activateSession: mockActivate, authFetch: mockAuthFetch, refresh: mockRefresh, logout: mockLogout }) }));
jest.mock("@/components/chat/Logo", () => () => <div />);
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("framer-motion", () => ({ motion: { div: ({ initial, animate, ...props }) => require("react").createElement("div", props) } }));
jest.mock("@/components/ui/button", () => ({ Button: (props) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
const reply = (json, ok = true) => ({ ok, json: async () => json });
const link = () => ({ deep_link: "https://t.me/Test_bot?start=test-nonce", telegram_bot_username: "Test_bot", expires_at: new Date(Date.now() + 600000).toISOString(), telegram_bot_configured: true });
let container, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  [mockRegister, mockActivate, mockAuthFetch, mockRefresh, mockLogout].forEach((fn) => fn.mockReset());
  mockRefresh.mockResolvedValue({}); mockActivate.mockResolvedValue({ _id: "user1" });
  global.fetch = jest.fn();
  container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });
async function input(id, value) {
  await act(async () => {
    const element = container.querySelector(`[data-testid="${id}"]`);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(element, value);
    element.dispatchEvent(new Event("input", { bubbles: true }));
  });
}
async function registerAccount(configured = true) {
  mockRegister.mockResolvedValue({ token: "registration-test-token", recovery_code: "TEST-CODE" });
  fetch.mockResolvedValue(reply({ ...link(), telegram_bot_configured: configured }));
  await act(async () => root.render(<Register />));
  await input("reg-username", "new_user"); await input("reg-password", "TestPassword1");
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
}

test.each([undefined, true, false])("registration always shows recovery before activation without a Telegram request (%s)", async (telegramRequired) => {
  mockRegister.mockResolvedValue({ token: "native-token", recovery_code: "SAVE-THIS", telegram_required: telegramRequired });
  await act(async () => root.render(<Register />));
  await input("reg-username", "local_user"); await input("reg-password", "NativePassword1");
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
  expect(container.querySelector('[data-testid="recovery-code"]').textContent).toBe("SAVE-THIS");
  expect(container.querySelector('[data-testid="register-telegram-step"]')).toBeNull();
  expect(fetch).not.toHaveBeenCalled();
  expect(mockActivate).not.toHaveBeenCalled();
  await act(async () => container.querySelector('[data-testid="recovery-done"]').click());
  expect(mockActivate).toHaveBeenCalledWith("native-token");
});

test("legacy gate opens workspace immediately even when Telegram is unavailable", async () => {
  fetch.mockRejectedValue(new Error("Telegram unavailable"));
  mockAuthFetch.mockRejectedValue(new Error("Telegram unavailable"));
  await act(async () => root.render(<TelegramGate><div data-testid="native-workspace">Workspace</div></TelegramGate>));
  expect(container.querySelector('[data-testid="native-workspace"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="telegram-gate"]')).toBeNull();
  expect(fetch).not.toHaveBeenCalled();
  expect(mockAuthFetch).not.toHaveBeenCalled();
});

test("optional account panel waits for an explicit link action and confirms the nonce", async () => {
  let verified = false;
  fetch.mockResolvedValue(reply({ telegram_required: true, telegram_bot_configured: true }));
  mockAuthFetch.mockImplementation(async (path) => reply(path.endsWith("/status") ? { verified, challenge_active: false } : link()));
  await act(async () => root.render(<TelegramGate showLinking />));
  expect(mockAuthFetch.mock.calls.filter(([path]) => path.endsWith("/start"))).toHaveLength(0);
  expect(container.querySelector('[data-testid="tg-bot-link"]')).toBeNull();
  await act(async () => container.querySelector('[data-testid="tg-new-challenge-btn"]').click());
  expect(container.querySelector('[data-testid="tg-bot-link"]').href).toBe("https://t.me/Test_bot?start=test-nonce");
  expect(mockAuthFetch.mock.calls.filter(([path]) => path.endsWith("/start"))).toHaveLength(1);
  verified = true;
  await act(async () => container.querySelector('[data-testid="tg-check-status-btn"]').click());
  expect(container.querySelector('[data-testid="tg-linked-status"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="tg-bot-link"]')).toBeNull();
  expect(mockRefresh).toHaveBeenCalledTimes(1);
});

test("unconfigured bot is explained in the optional panel without starting a challenge", async () => {
  fetch.mockResolvedValue(reply({ telegram_bot_configured: false }));
  mockAuthFetch.mockResolvedValue(reply({ verified: false, challenge_active: false }));
  await act(async () => root.render(<TelegramGate showLinking />));
  expect(container.querySelector('[role="alert"]').textContent).toContain("مفتاح بوت Telegram غير مهيّأ");
  expect(container.querySelector('[data-testid="tg-new-challenge-btn"]').disabled).toBe(true);
  expect(mockAuthFetch.mock.calls.filter(([path]) => path.endsWith("/start"))).toHaveLength(0);
});

test("failed optional challenge can be retried without a fake private link", async () => {
  fetch.mockResolvedValue(reply({ telegram_bot_configured: true }));
  mockAuthFetch.mockImplementation(async (path) => path.endsWith("/status") ? reply({ verified: false }) : reply({ detail: "Cannot create link" }, false));
  await act(async () => root.render(<TelegramGate showLinking />));
  await act(async () => container.querySelector('[data-testid="tg-new-challenge-btn"]').click());
  expect(container.querySelector('[role="alert"]').textContent).toContain("Cannot create link");
  expect(container.querySelector('[data-testid="tg-bot-link"]')).toBeNull();
  expect(container.querySelector('[data-testid="tg-new-challenge-btn"]').disabled).toBe(false);
});

test("repeated form submission creates only one account while the request is pending", async () => {
  let resolveRegistration;
  mockRegister.mockImplementation(() => new Promise((resolve) => { resolveRegistration = resolve; }));
  await act(async () => root.render(<Register />));
  await input("reg-username", "local_user"); await input("reg-password", "NativePassword1");
  await act(async () => {
    container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  });
  expect(mockRegister).toHaveBeenCalledTimes(1);
  await act(async () => resolveRegistration({ token: "native-token", recovery_code: "SAVE-THIS" }));
  expect(container.querySelector('[data-testid="recovery-code"]').textContent).toBe("SAVE-THIS");
});

test("repeated recovery acknowledgement activates the session only once", async () => {
  let resolveActivation;
  mockActivate.mockImplementation(() => new Promise((resolve) => { resolveActivation = resolve; }));
  await registerAccount();
  await act(async () => {
    container.querySelector('[data-testid="recovery-done"]').click();
    container.querySelector('[data-testid="recovery-done"]').click();
  });
  expect(mockActivate).toHaveBeenCalledTimes(1);
  await act(async () => resolveActivation({ _id: "user1" }));
});

test("opening an already-linked account panel does not refresh or disturb the session", async () => {
  fetch.mockResolvedValue(reply({ telegram_bot_configured: true }));
  mockAuthFetch.mockResolvedValue(reply({ verified: true }));
  await act(async () => root.render(<TelegramGate showLinking />));
  expect(container.querySelector('[data-testid="tg-linked-status"]')).not.toBeNull();
  expect(mockRefresh).not.toHaveBeenCalled();
});
