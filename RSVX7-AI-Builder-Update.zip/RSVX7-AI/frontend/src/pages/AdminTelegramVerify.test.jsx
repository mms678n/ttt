import React, { act } from "react";
import { createRoot } from "react-dom/client";
import { setLanguage } from "@/i18n/runtime";
import AdminTelegramVerify, { safeInviteLink, validateGroupPayload } from "./AdminTelegramVerify";

test("accepts only absolute HTTP(S) invite links", () => {
  expect(safeInviteLink(" https://t.me/+invite ")).toBe("https://t.me/+invite");
  expect(safeInviteLink("javascript:alert(1)")).toBe("");
  expect(safeInviteLink("not-a-url")).toBe("");
});

test("requires HTTPS links for private numeric Telegram groups", () => {
  expect(() => validateGroupPayload({ username: "-100123", invite_link: "http://t.me/private" })).toThrow("HTTPS");
  expect(validateGroupPayload({ username: "-100123", invite_link: "https://t.me/+private" }).invite_link).toBe("https://t.me/+private");
  expect(validateGroupPayload({ username: "@rsvx7", invite_link: "" }).invite_link).toBeNull();
});

// Exercise the rendered switch: its accessible name describes the optional
// diagnostic action and the persisted flag still controls manual checks.

let mockAdminId = 0;
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ user: { _id: `diagnostic-admin-${mockAdminId}` } }) }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));

test.each([["ar", "تفعيل فحص العضوية الاختياري"], ["en", "Enable optional membership checks"]])("membership diagnostic toggle has an accessible optional label in %s", async (language, label) => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockAdminId += 1;
  setLanguage(language);
  global.fetch = jest.fn().mockResolvedValue({ ok: true, json: async () => ({ enabled: true, groups: [] }) });
  const container = document.createElement("div");
  document.body.appendChild(container);
  const root = createRoot(container);
  try {
    await act(async () => root.render(<AdminTelegramVerify />));
    const toggle = container.querySelector('[role="switch"]');
    expect(toggle.getAttribute("aria-label")).toBe(label);
    expect(toggle.getAttribute("aria-checked")).toBe("true");
    await act(async () => toggle.click());
    const saved = fetch.mock.calls.find(([path, options]) => path.endsWith("/settings/telegram-verification") && options.method === "POST");
    expect(JSON.parse(saved[1].body)).toEqual({ enabled: false });
  } finally {
    await act(async () => root.unmount());
    container.remove();
    setLanguage("ar");
  }
});
