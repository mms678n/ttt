import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Login from "./Login";
import { setLanguage } from "@/i18n";
import "@/i18n/catalogs/auth";

const mockLogin = jest.fn();

jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({ login: mockLogin }),
}));

describe("MR7 authentication shell", () => {
  let container;
  let root;

  beforeEach(() => {
    global.IS_REACT_ACT_ENVIRONMENT = true;
    setLanguage("ar");
    mockLogin.mockReset();
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(async () => {
    await act(async () => root.unmount());
    container.remove();
    setLanguage("ar");
  });

  test("renders the measured two-panel shell with home navigation and username auth", async () => {
    await act(async () => root.render(<Login />));

    expect(container.querySelector(".auth-ui-shell.auth-ui-login")).not.toBeNull();
    expect(container.querySelector(".ds-auth-story")).not.toBeNull();
    expect(container.querySelector(".auth-ui-story-brand").getAttribute("href")).toBe("#home");
    expect(container.querySelector(".ds-auth-story h1")).not.toBeNull();
    expect(container.querySelector(".ds-auth-form h2")).not.toBeNull();
    expect(container.querySelector(".auth-ui-story-heading").textContent).toContain("ذكاء اصطناعي للهاكرز");
    expect(container.querySelectorAll('.auth-ui-home-link[href="#home"]').length).toBeGreaterThanOrEqual(1);
    expect(container.querySelector(".auth-ui-form")).not.toBeNull();
    expect(container.querySelector("[data-testid=login-username]").getAttribute("autocomplete")).toBe("username");
    expect(container.querySelector("[data-testid=login-username]").getAttribute("placeholder")).toContain("اسم المستخدم");
  });

  test("does not introduce a fake OAuth or consent control", async () => {
    await act(async () => root.render(<Login />));
    const text = container.textContent;
    expect(text).not.toMatch(/Google|Terms of Service|Privacy Policy|البريد الإلكتروني/);
    expect(container.querySelector('[data-testid="login-submit"]')).not.toBeNull();
  });

  test("translates the story and navigation in English without changing the auth contract", async () => {
    setLanguage("en");
    await act(async () => root.render(<Login />));

    expect(container.querySelector(".ds-auth").getAttribute("dir")).toBe("ltr");
    expect(container.querySelector(".auth-ui-story-heading").textContent).toContain("AI for Ethical Hackers");
    expect(container.querySelector(".auth-ui-home-link").textContent).toContain("Home");
    expect(container.querySelector('[data-testid="login-username"]').placeholder).toBe("Username");
  });
});
