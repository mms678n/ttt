import { requestId as newRequestId } from "@/lib/requestId";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/monthly";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Panel, StatusNote, LoadingState } from "@/components/design/Primitives";

export default function AdminMemberships() {
  const { authFetch } = useAuth(), { t, dir, formatNumber, formatDate } = useI18n("monthly");
  const [users, setUsers] = useState([]), [query, setQuery] = useState(""), [busy, setBusy] = useState(null), [loading, setLoading] = useState(true), [error, setError] = useState(""), [notice, setNotice] = useState(""), [selection, setSelection] = useState({});
  const action = useRef(false), operations = useRef(new Map()), sequence = useRef(0);
  const load = useCallback(async () => {
    const id = ++sequence.current; setLoading(true);
    try {
      const response = await authFetch("/admin/memberships?q=" + encodeURIComponent(query)); const data = await response.json();
      if (!response.ok || !Array.isArray(data.users)) throw Error(typeof data.detail === "string" ? data.detail : t("تعذّر تحميل الاشتراكات."));
      if (id === sequence.current) { setUsers(data.users); setError(""); }
    } catch (error) { if (id === sequence.current) setError(error.message); }
    finally { if (id === sequence.current) setLoading(false); }
  }, [authFetch, query, t]);
  const invalidate = useCallback(() => { sequence.current++; }, []);
  useEffect(() => { const timer = setTimeout(load, 200); return () => { clearTimeout(timer); invalidate(); }; }, [load, invalidate]);
  const activate = async member => {
    if (action.current) return;
    const plan = selection[member._id] || member.request?.plan || (member.plan === "free" ? "pro" : member.plan);
    const key = member._id + ":" + plan;
    const requestId = operations.current.get(key) || newRequestId(); operations.current.set(key, requestId);
    action.current = true; setBusy(member._id); setError(""); setNotice("");
    try {
      const response = await authFetch("/admin/memberships/" + encodeURIComponent(member._id), { method: "POST", body: JSON.stringify({ plan, request_id: requestId }) });
      const data = await response.json(); if (!response.ok || !data.ok) throw Error(typeof data.detail === "string" ? data.detail : t("تعذّر تفعيل الباقة."));
      operations.current.delete(key); setNotice(t("تم تحديث الباقة مع الحفاظ على الرصيد المشحون.")); await load();
    } catch (error) { setError(error.message); }
    finally { action.current = false; setBusy(null); }
  };
  return <section dir={dir} className="space-y-5" data-testid="admin-memberships"><header><h2 className="text-xl font-semibold">{t("الباقات الشهرية")}</h2><p className="text-sm text-muted-foreground mt-2 leading-7">{t("فعّل بعد تأكيد الدفع. يبدأ شهر جديد فورًا ويستبدل الرصيد الشهري السابق؛ رصيد الشحن لا يتغير. اختر Free لإلغاء الباقة المدفوعة فورًا.")}</p></header>
    <div className="flex gap-3"><Input value={query} onChange={event => setQuery(event.target.value)} placeholder={t("ابحث باسم المستخدم")} aria-label={t("ابحث باسم المستخدم")} /><Button variant="outline" onClick={load}>{t("تحديث")}</Button></div>
    {error && <StatusNote tone="error" onRetry={load}>{error}</StatusNote>}{notice && <p role="status">{notice}</p>}{loading && <LoadingState label={t("جارٍ تحميل الاشتراكات…")} />}
    {users.filter(member => member.role === "user").sort((a,b) => Number(b.request?.status === "pending") - Number(a.request?.status === "pending")).map(member => <Panel key={member._id} className="p-5 space-y-3">
      <div className="flex flex-wrap gap-2 justify-between"><strong dir="auto">{member.username}</strong><span dir="ltr">{member.plan.toUpperCase()}</span></div>
      <p className="text-sm text-muted-foreground">{t("شهري متبقٍ")}: {formatNumber(member.monthly_remaining)} · {t("رصيد دائم")}: {formatNumber(member.purchased_remaining)} · {t("نهاية الفترة")}: {member.monthly?.ends_at ? formatDate(member.monthly.ends_at) : "—"}</p>
      {member.request?.status === "pending" && <p className="text-sm text-amber-500">{t("طلب اشتراك قيد الانتظار")}: {member.request.plan.toUpperCase()}</p>}
      <div className="flex flex-wrap gap-3"><select aria-label={t("الباقة") + " " + member.username} className="bg-background border rounded-md px-3 py-2" value={selection[member._id] || member.request?.plan || (member.plan === "free" ? "pro" : member.plan)} onChange={event => setSelection(previous => ({ ...previous, [member._id]: event.target.value }))}>
        <option value="free">Free · 10,000 · $0</option><option value="pro">Pro · 10,000,000 · $25</option><option value="max">Max · 25,000,000 · $50</option>
      </select><Button disabled={busy !== null} onClick={() => activate(member)}>{busy === member._id ? t("جارٍ الحفظ…") : t("تفعيل شهر / تطبيق التغيير")}</Button></div>
    </Panel>)}
    {!loading && users.filter(member => member.role === "user").length === 0 && <p>{t("لا توجد حسابات مطابقة.")}</p>}
  </section>;
}
