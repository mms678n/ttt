import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Loader2, Save, RefreshCw, ShieldCheck, PlugZap, KeyRound } from "lucide-react";
import { ActionButton, EmptyState, LoadingState, Panel, PageHeader, StatusNote } from "@/components/design/Primitives";
import "./admin-ui.css";
import { MODELS } from "@/components/chat/ModelPicker";

const CACHE_TTL = 10_000;
const assignments = settings => Object.fromEntries(MODELS.map(({id}) => [id, settings?.profile_models?.[id] || '']));

function cacheKey(user) {
  return `ai-settings:${user?._id || user?.id || user?.username || "session"}`;
}

function errorText(data, fallback) {
  return typeof data?.detail === "string" ? data.detail : fallback;
}

export default function AdminAISettings() {
  const { authFetch, user } = useAuth();
  const { t, dir, formatNumber } = useI18n("admin");
  const [settings, setSettings] = useState(null);
  const [model, setModel] = useState("");
  const [profileModels, setProfileModels] = useState(() => assignments(null));
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [connecting, setConnecting] = useState("");
  const [connectionError, setConnectionError] = useState("");
  const [connectionTest, setConnectionTest] = useState(null);
  const requestId = useRef(0);
  const abortRef = useRef(null);
  const cacheRef = useRef(null);
  const connectionAbort = useRef(null);
  const alive = useRef(true);
  const key = cacheKey(user);
  const sessionKey = useRef(key);
  sessionKey.current = key;

  const load = useCallback(async ({ force = false } = {}) => {
    const cached = cacheRef.current;
    if (!force && cached && cached.key === key && Date.now() - cached.at < CACHE_TTL) {
      setSettings(cached.value);
      setModel(cached.value.model || "");
      setProfileModels(assignments(cached.value));
      setLoading(false);
      setError("");
      return;
    }
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const id = ++requestId.current;
    setLoading(true);
    setError("");
    try {
      const response = await authFetch("/admin/ai-settings", { signal: controller.signal });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(errorText(data, "تعذّر تحميل إعدادات النموذج."));
      if (controller.signal.aborted || id !== requestId.current) return;
      // The API key is deliberately never copied into state or rendered.
      const safe = { ...data };
      delete safe.key;
      delete safe.api_key;
      cacheRef.current = { key, value: safe, at: Date.now() };
      setSettings(safe);
      setModel(safe.model || "");
      setProfileModels(assignments(safe));
    } catch (e) {
      if (e?.name === "AbortError") return;
      if (id === requestId.current) setError(e?.message || "تعذّر الاتصال بالخادم.");
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }, [authFetch, key]);

  useEffect(() => {
    alive.current = true;
    setApiKey(""); setConnectionError(""); setConnectionTest(null); setConnecting("");
    load();
    return () => { alive.current = false; abortRef.current?.abort(); connectionAbort.current?.abort(); };
  }, [load]);

  const save = async (event) => {
    event.preventDefault();
    const nextModel = model.trim();
    if (!nextModel || saving || connecting || !settings) return;
    const ownerKey = key;
    abortRef.current?.abort();
    const controller = new AbortController(); abortRef.current = controller;
    const id = ++requestId.current;
    setSaving(true);
    setError("");
    try {
      const response = await authFetch("/admin/ai-settings", { method: "PUT", signal: controller.signal,
        body: JSON.stringify({ model: nextModel, profile_models: profileModels, model_revision: settings.model_revision || 0 }) });
      const data = await response.json().catch(() => ({}));
      if (!alive.current || ownerKey !== sessionKey.current || controller.signal.aborted || id !== requestId.current) return;
      if (!response.ok) throw new Error(errorText(data, "اسم النموذج غير صالح. استخدم provider/model."));
      const safe = { ...data };
      delete safe.key;
      delete safe.api_key;
      cacheRef.current = { key, value: safe, at: Date.now() };
      setSettings(safe);
      setModel(safe.model || nextModel);
      setProfileModels(assignments(safe));
      window.dispatchEvent(new Event('rsvx7:ai-settings-updated'));
      toast.success(t("تم حفظ النموذج؛ سيُستخدم في الرسائل التالية فورًا."));
    } catch (e) {
      if (!alive.current || ownerKey !== sessionKey.current || e?.name === 'AbortError') return;
      setError(e?.message || "تعذّر الحفظ؛ لم تتغير الإعدادات.");
      toast.error(e?.message || t("تعذّر حفظ النموذج."));
    } finally {
      if (alive.current && ownerKey === sessionKey.current) setSaving(false);
    }
  };

  const configureConnection = async (action) => {
    if (connecting || saving || !settings) return;
    const ownerKey = key;
    const controller = new AbortController(); connectionAbort.current = controller;
    setConnecting(action); setConnectionError(""); setConnectionTest(null);
    try {
      const response = await authFetch(`/admin/ai-settings/connection${action === "test" ? "/test" : ""}`, {
        method: action === "test" ? "POST" : "PUT",
        signal: controller.signal,
        body: JSON.stringify({ revision: settings.connection_revision || 0, api_key: apiKey }),
      });
      const data = await response.json().catch(() => ({}));
      if (!alive.current || ownerKey !== sessionKey.current || controller.signal.aborted) return;
      if (!response.ok) throw new Error(errorText(data, "تعذّر إعداد اتصال النموذج."));
      if (action === "save") {
        const next = { ...data.settings }; delete next.api_key; delete next.key;
        setSettings(next); cacheRef.current = { key, value: next, at: Date.now() };
        setApiKey(""); setConnectionTest(data.test);
      } else setConnectionTest(data);
    } catch (e) {
      if (alive.current && ownerKey === sessionKey.current && e?.name !== "AbortError") setConnectionError(e?.message || "تعذّر إعداد اتصال النموذج.");
    } finally { if (alive.current && ownerKey === sessionKey.current) setConnecting(""); }
  };
  const warningText = { model_unavailable: "النموذج المحدد غير متاح لدى الخدمة.", free_limit: "وصلت إلى الحد اليومي للنماذج المجانية لدى المزوّد.", key_limit: "وصل المفتاح إلى حد الإنفاق المضبوط لدى المزوّد." };

  return (
    <section dir={dir} className="admin-section space-y-4" data-testid="admin-ai-settings">
      <PageHeader
        eyebrow={settings?.provider === "Local" ? t("النموذج المحلي") : t("النماذج · OpenRouter")}
        title={t("إعدادات نموذج الذكاء الاصطناعي")}
        description={t("غيّر المعرّف الفعّال للرسائل التالية دون إعادة تشغيل الخادم. لا يُعرض مفتاح الخدمة في المتصفح.")}
        actions={<ActionButton tone="ghost" onClick={() => load({ force: true })} disabled={saving || !!connecting} loading={loading} aria-label={t("تحديث إعدادات النموذج")}><RefreshCw size={16} /> {t("تحديث")}</ActionButton>}
      />
      <Panel className="admin-content-card" style={{ padding: "20px" }}>
        <div className="flex items-start justify-between gap-3 mb-5">
          <div>
            <p className="admin-subtitle">{t("المعرّف الكامل بصيغة ")}<span dir="ltr" className="admin-code">{settings?.provider === "Local" ? "model:tag" : "provider/model"}</span>{t("، والتحقق يتم من الخادم قبل الحفظ.")}</p>
          </div>
          <Badge className="bg-brand-500/15 text-brand-400 border-brand-500/30">{settings?.provider || "OpenRouter"}</Badge>
        </div>
        {loading && !settings && <LoadingState label={t("جارٍ تحميل إعدادات النموذج…")} />}
        {error && <StatusNote tone="error" onRetry={() => load({ force: true })}><span data-testid="ai-settings-error">{t(error)}</span></StatusNote>}
        {!settings && !loading && !error && <EmptyState title={t("تعذّر عرض الإعدادات")} description={t("لم تصل بيانات صالحة من الخادم؛ أعد المحاولة بدل عرض لوحة فارغة.")} action={<ActionButton tone="ghost" onClick={() => load({ force: true })}>{t("إعادة المحاولة")}</ActionButton>} />}
        {settings && (
          <form onSubmit={save} className="ds-form-stack">
            <div className="ds-field">
              <Label htmlFor="ai-model-name">{t("النموذج الافتراضي")}</Label>
              <Input id="ai-model-name" dir="ltr" data-testid="ai-model-input" value={model} onChange={(e) => setModel(e.target.value)} maxLength={200} required disabled={saving || !!connecting} placeholder={settings?.provider === "Local" ? "qwen2.5-coder:7b" : "nousresearch/hermes-3-llama-3.1-405b"} className="ds-input admin-code" />
              <p className="admin-soft-note">{t("مثال: ")}<span dir="ltr" className="admin-code">{settings?.provider === "Local" ? "qwen2.5-coder:7b" : "provider/model-name"}</span>{t(". لا يُطبّق التغيير إلا إذا قبله الخادم.")}</p>
            </div>
            <div className="rounded-xl bg-bg-main border border-soft p-4 space-y-2 text-sm" aria-live="polite">
              <p className="text-zinc-400">{t("النموذج الحالي: ")}<span dir="ltr" data-testid="ai-active-model" className="inline-block text-white admin-code">{settings.model}</span></p>
              <p className="text-zinc-400">{t("عنوان API: ")}<span dir="ltr" className="inline-block admin-code text-zinc-300">{settings.base_url}</span></p>
              <p className={settings.key_configured ? "text-emerald-400" : "text-amber-400"}>{settings.provider === "Local" ? t("اتصال محلي؛ لا يتطلب مفتاح API خارجيًا.") : settings.key_reentry_required ? t("أعد إدخال المفتاح بعد تغيير إعداد التشفير.") : settings.key_configured ? t("مفتاح الخدمة مهيأ في الخادم") : t("لم يُضبط اتصال النموذج بعد.")}</p>
              <p className="text-zinc-500 text-xs">{t("سياق النموذج الافتراضي: {count} توكن.", { count: formatNumber(settings.context_length) })}</p>
            </div>
            <div className="ds-form-stack" data-testid="ai-profile-models">
              <h3>{t("نماذج المنصة")}</h3>
              <p className="admin-soft-note">{t("اختر معرّف مزوّد مختلف لكل نموذج. اترك الحقل فارغًا لاستخدام الافتراضي. يُطبّق في الدردشة وBuilder.")}</p>
              {MODELS.map(({id, label}) => <div className="ds-field" key={id}>
                <Label htmlFor={'ai-profile-' + id}>{label}</Label>
                <Input id={'ai-profile-' + id} data-testid={'ai-profile-' + id} dir="ltr" maxLength={200}
                  value={profileModels[id] || ''} placeholder={model.trim() || 'provider/model'} disabled={saving || !!connecting}
                  onChange={event => setProfileModels(previous => ({...previous, [id]: event.target.value}))} className="ds-input admin-code" />
              </div>)}
            </div>
            <p className="admin-soft-note flex items-center gap-2"><ShieldCheck className="w-4 h-4 shrink-0" /> {t("المفتاح المحفوظ لا يظهر عند تحميل الإعدادات.")}</p>
            <div className="admin-inline-actions">
              <Button type="submit" data-testid="ai-model-save" disabled={saving || !!connecting || loading || !model.trim() || (model.trim() === settings.model && MODELS.every(({id}) => (profileModels[id] || '').trim() === (settings.profile_models?.[id] || '')))} className="bg-brand-500 hover:bg-brand-600 text-white gap-2">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} {saving ? t("التحقق والحفظ…") : t("حفظ النموذج")}</Button>
              <Button type="button" onClick={() => load({ force: true })} disabled={saving || !!connecting || loading} variant="ghost" className="border border-soft text-zinc-300 gap-2"><RefreshCw className="w-4 h-4" /> {t("تحديث")}</Button>
            </div>
          </form>
        )}
      </Panel>
      {settings && user?.role === "super_admin" && <Panel className="admin-content-card" style={{ padding: "20px" }}>
        <h3 className="flex items-center gap-2 mb-4"><KeyRound size={17} />{t("اتصال النموذج")}</h3>
        {settings.provider !== "Local" && <div className="ds-field mb-4"><Label htmlFor="ai-provider-key">{t("مفتاح API")}</Label><Input
          id="ai-provider-key" data-testid="ai-provider-key" dir="ltr" type="password" autoComplete="new-password" maxLength={500}
          value={apiKey} onChange={e => { setApiKey(e.target.value); setConnectionTest(null); setConnectionError(""); }} disabled={!!connecting || saving}
          placeholder={settings.key_configured ? t("مهيأ؛ أدخل مفتاحًا جديدًا لاستبداله") : "sk-or-v1-…"} className="ds-input" /></div>}
        {connectionError && <StatusNote tone="error"><span role="alert">{t(connectionError)}</span></StatusNote>}
        {connectionTest && <StatusNote tone={connectionTest.ready ? "success" : "warning"}><span data-testid="ai-connection-result">{t(connectionTest.warning ? warningText[connectionTest.warning] || "الاتصال يحتاج مراجعة." : "نجح فحص الاتصال وإعداد النموذج.")}</span></StatusNote>}
        <div className="admin-inline-actions mt-4">
          <Button data-testid="ai-connection-test" variant="ghost" disabled={!!connecting || saving} onClick={() => configureConnection("test")} className="gap-2"><PlugZap size={16} />{connecting === "test" ? t("جارٍ الفحص…") : t("اختبار الاتصال")}</Button>
          {settings.provider !== "Local" && <Button data-testid="ai-connection-save" disabled={!!connecting || saving || !apiKey.trim()} onClick={() => configureConnection("save")} className="gap-2"><Save size={16} />{connecting === "save" ? t("جارٍ الحفظ…") : t("حفظ الاتصال")}</Button>}
        </div>
      </Panel>}
    </section>
  );
}
