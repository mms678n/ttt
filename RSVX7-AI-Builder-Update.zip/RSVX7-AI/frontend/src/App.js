import React, { lazy, Suspense, useState, useEffect } from "react";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { LoadingState, ActionButton, StatusNote } from "@/components/design/Primitives";
import { LanguageProvider, LanguageSwitcher, useI18n } from "@/i18n";
import { useTheme } from "@/components/design/ThemeSwitcher";
import { isAdmin } from "@/lib/roles";
import { Toaster } from "sonner";
import "@/index.css";
import Login from "@/pages/Login";
const MonthlyPricing = lazy(() => import("@/components/MonthlyPricing"));
const Landing = lazy(() => import("@/pages/Landing"));
const Register = lazy(() => import("@/pages/Register"));
const Recover = lazy(() => import("@/pages/Recover"));
const Admin = lazy(() => import("@/pages/Admin"));
const Dashboard = lazy(() => import("@/pages/Dashboard"));
const ForcePasswordChange = lazy(() => import("@/components/ForcePasswordChange"));
const ChatWorkspace = lazy(() => import("@/components/design/ChatWorkspace"));
const PUBLIC_SECTIONS = ["pricing", "home", "features", "projects", "assistants", "code", "tools", "how-to-use", "faq"];
const ROUTES = [...PUBLIC_SECTIONS, "login", "register", "recover", "chat", "builder", "remote", "dashboard", "admin"];
function readRoute() {
  const path = window.location.pathname.replace(/^\/+|\/+$/g, "");
  const route = window.location.hash ? window.location.hash.slice(1) : path || "home";
  return ROUTES.includes(route) ? route : "home";
}
function PageLoading() {
  const { t, dir } = useI18n();
  return <div className="app-h-svh flex items-center justify-center bg-bg-main" dir={dir}><LanguageSwitcher className="auth-language-switcher" /><LoadingState label={t("جارٍ فتح مساحتك…")} /></div>;
}
function PageFailure() {
  const { t, dir } = useI18n();
  return <main className="app-h-svh flex items-center justify-center p-6 bg-bg-main" dir={dir}><LanguageSwitcher className="auth-language-switcher" /><div className="max-w-md space-y-4"><StatusNote tone="error">{t("تعذّر فتح هذه الشاشة. جرّب إعادة تحميل الصفحة.")}</StatusNote><ActionButton onClick={() => window.location.reload()}>{t("إعادة تحميل الصفحة")}</ActionButton></div></main>;
}
class PageErrorBoundary extends React.Component {
  state = { error: false };
  static getDerivedStateFromError() { return { error: true }; }
  render() { return this.state.error ? <PageFailure /> : this.props.children; }
}
function Gate() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [route, setRoute] = useState(readRoute);
  useEffect(() => {
    const onHash = () => setRoute(readRoute());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  const goto = (next) => { window.location.hash = `#${next}`; setRoute(next); };
  useEffect(() => {
    if (user && route === "admin" && !isAdmin(user)) { window.location.hash = "#chat"; setRoute("chat"); }
  }, [user, route]);
  const onSignIn = () => goto(user ? "chat" : "login");
  if (PUBLIC_SECTIONS.includes(route)) {
    return <Landing onSignIn={onSignIn} onRegister={() => goto(user ? "chat" : "register")} onChat={onSignIn} />;
  }
  if (user === undefined) return <PageLoading />;
  if (!user) {
    if (route === "register") return <Register onSwitch={() => goto("login")} onSuccess={() => goto("chat")} />;
    if (route === "recover") return <Recover onBack={() => goto("login")} />;
    return <Login onSwitch={() => goto("register")} onRecover={() => goto("recover")} onSuccess={() => goto("chat")} />;
  }
  if (user.must_change_password) return <ForcePasswordChange />;
  if (route === "admin") return isAdmin(user) ? <Admin onExit={() => goto("chat")} /> : null;
  if (["remote", "builder"].includes(route) && user.entitlements && !user.entitlements.features?.includes(route === "remote" ? "hacker" : "builder")) return (<main className="min-h-screen bg-background p-5"><ActionButton onClick={() => goto("chat")}>{t("← العودة إلى الدردشة")}</ActionButton><p className="text-center mt-6">{t("باقتك لا تتيح هذه الميزة.")}</p><div className="max-w-6xl mx-auto"><MonthlyPricing wallet={user} /></div></main>);
  if (route === "remote") return (<div style={{height:'100dvh',display:'flex',flexDirection:'column'}}><button className="remote-platform-back" onClick={()=>goto('chat')}>{t("← العودة إلى الدردشة")}</button><iframe src="/remote-ui/" title="Hacker rsvx7 Ai" style={{flex:1,width:'100%',border:0}} /></div>);
  if (route === "dashboard") return (<Dashboard onExit={() => goto("chat")} />);
  return (<ChatWorkspace key={user._id} builderMode={route === "builder"} onOpenDashboard={() => goto("dashboard")} onOpenAdmin={() => goto("admin")} />);
}
function Notifications() {
  const theme = useTheme();
  return <Toaster theme={theme} position="top-center" richColors closeButton toastOptions={{ style:{background:"var(--card)",border:"1px solid var(--border)",color:"var(--foreground)",fontFamily:"inherit"} }} />;
}
export default function App() {
  return <LanguageProvider><AuthProvider><PageErrorBoundary><Suspense fallback={<PageLoading />}><Gate /></Suspense></PageErrorBoundary><Notifications /></AuthProvider></LanguageProvider>;
}
