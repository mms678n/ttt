import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import { AuthProvider, useAuth } from './AuthContext';

function Screen() {
  const { user, refresh } = useAuth();
  return <><span data-testid="name">{user === undefined ? 'loading' : user?.username || 'guest'}</span><button onClick={() => refresh()}>refresh</button></>;
}
const response = (status, body = {}) => ({ status, ok: status === 200, json: async () => body });
let node, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.setItem('rsvx7_token','fixture-token');
  global.fetch = jest.fn().mockResolvedValueOnce(response(200,{_id:'u1', username:'tester'}));
  node = document.createElement('div'); document.body.appendChild(node); root = createRoot(node);
});
afterEach(async () => { await act(async () => root.unmount()); node.remove(); localStorage.clear(); });

test.each([response(503), new TypeError('offline')])('temporary refresh failure keeps an existing session', async failure => {
  await act(async () => root.render(<AuthProvider><Screen /></AuthProvider>));
  expect(node.querySelector('[data-testid="name"]').textContent).toBe('tester');
  if (failure instanceof Error) fetch.mockRejectedValueOnce(failure); else fetch.mockResolvedValueOnce(failure);
  await act(async () => node.querySelector('button').click());
  expect(node.querySelector('[data-testid="name"]').textContent).toBe('tester');
  expect(localStorage.getItem('rsvx7_token')).toBe('fixture-token');
});

test('unauthorized refresh still signs the user out', async () => {
  await act(async () => root.render(<AuthProvider><Screen /></AuthProvider>));
  fetch.mockResolvedValueOnce(response(401));
  await act(async () => node.querySelector('button').click());
  expect(node.querySelector('[data-testid="name"]').textContent).toBe('guest');
  expect(localStorage.getItem('rsvx7_token')).toBeNull();
});
