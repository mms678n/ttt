"""Monthly allowances and entitlements; purchased credits remain in the wallet.

The canonical token_balance includes both buckets. monthly.remaining is the
expiring portion; their difference is the permanent purchased balance. All
rollovers and debits use compare-and-swap, including on standalone MongoDB.
"""
from __future__ import annotations
import calendar, secrets
from datetime import datetime, timezone
from fastapi import HTTPException

STAFF = ("super_admin", "admin", "moderator", "support")
PLANS = {
    "free": {"id": "free", "name": "Free", "usd": 0, "tokens": 10_000, "models": ["kaligpt"], "features": []},
    "pro": {"id": "pro", "name": "Pro", "usd": 25, "tokens": 10_000_000, "models": ["kaligpt", "deepdark"], "features": ["builder"]},
    "max": {"id": "max", "name": "Max", "usd": 50, "tokens": 25_000_000, "models": ["kaligpt", "deepdark", "rsvx7-ai"], "features": ["builder", "hacker"]},
}

def utcnow(): return datetime.now(timezone.utc)
def next_month(now):
    year, month = now.year + (now.month == 12), now.month % 12 + 1
    return now.replace(year=year, month=month, day=min(now.day, calendar.monthrange(year, month)[1]))
def period(plan, now, remaining=None):
    end = next_month(now) if plan != "free" else next_month(now.replace(day=1, hour=0, minute=0, second=0, microsecond=0))
    return {"plan": plan, "allowance": PLANS[plan]["tokens"], "remaining": PLANS[plan]["tokens"] if remaining is None else remaining,
            "starts_at": now.isoformat(), "ends_at": end.isoformat(), "version": secrets.token_hex(12)}
def expires(monthly, now):
    try: return datetime.fromisoformat(monthly["ends_at"]).astimezone(timezone.utc) <= now
    except (ValueError, KeyError, TypeError): return True

def entitlements(user):
    if user.get("role") in STAFF: return {"plan": "admin", "models": PLANS["max"]["models"], "features": PLANS["max"]["features"]}
    monthly = user.get("monthly") or {}
    plan = monthly.get("plan", "free") if not expires(monthly, utcnow()) else "free"
    plan = plan if plan in PLANS else "free"
    return {"plan": plan, "models": PLANS[plan]["models"], "features": PLANS[plan]["features"]}

def wallet_fields(user):
    monthly = user.get("monthly") or {}
    total = max(0, int(user.get("token_balance") or 0))
    remaining = min(total, max(0, int(monthly.get("remaining") or 0)))
    return {"plan": entitlements(user)["plan"], "monthly": monthly or None,
            "monthly_remaining": remaining, "purchased_remaining": total - remaining,
            "entitlements": entitlements(user)}

async def refresh(user, database, *, grant_missing=True, now=None):
    if user.get("role") in STAFF: return user
    now = now or utcnow()
    for _ in range(64):
        monthly = user.get("monthly")
        if not isinstance(monthly, dict) or not monthly.get("version"): monthly = None
        if not monthly and not grant_missing: return user
        if monthly and not expires(monthly, now): return user
        new = period("free", now)
        old_remaining = min(max(0, int(user.get("token_balance") or 0)), max(0, int((monthly or {}).get("remaining") or 0)))
        query = {"_id": user["_id"], "token_balance": user["token_balance"] if "token_balance" in user else {"$exists": False}}
        query["monthly.version"] = monthly["version"] if monthly else {"$exists": False}
        if monthly: query["monthly.remaining"] = monthly["remaining"]
        new_total = max(0, int(user.get("token_balance") or 0)) + new["remaining"] - old_remaining
        result = await database.users.update_one(query, {"$set": {"monthly": new, "token_balance": new_total}})
        user = await database.users.find_one({"_id": user["_id"]})
        if not user: raise HTTPException(404, "User not found")
        if result.matched_count: return user
    raise HTTPException(409, "تغيّر الرصيد أثناء التحديث؛ أعد المحاولة.")

def require_access(user, *, feature=None, model=None):
    access = entitlements(user)
    if (feature and feature not in access["features"]) or (model and model not in access["models"]):
        required = "max" if feature == "hacker" or model == "rsvx7-ai" else "pro"
        raise HTTPException(403, {"code": "plan_required", "required_plan": required,
            "feature": feature or model, "message": "هذه الميزة تتطلب باقة " + required.title() + " أو أعلى. افتح الباقات من لوحة الحساب."})

async def activate(database, uid, plan, operation_id, *, now=None):
    """An explicit admin action starts one new month immediately, once per ID.
    Unspent previous monthly credits are replaced; purchased credits survive.
    Free cancellation retains the current free allowance rather than refilling it.
    """
    now = now or utcnow()
    for _ in range(64):
        user = await database.users.find_one({"_id": uid})
        if not user: raise HTTPException(404, "User not found")
        if user.get("role") in STAFF: raise HTTPException(400, "حسابات الإدارة معفاة من الباقات.")
        if operation_id in (user.get("membership_operations") or []): return user
        user = await refresh(user, database, now=now)
        old = user["monthly"]
        if plan == "free" and old["plan"] == "free":
            new = old
        else: new = period(plan, now)
        result = await database.users.update_one({"_id": uid, "monthly.version": old["version"], "monthly.remaining": old["remaining"],
            "membership_operations": {"$ne": operation_id}}, {"$set": {"monthly": new, "membership_last_action": {
                "id": operation_id, "plan": plan, "at": now.isoformat()}},
            "$inc": {"token_balance": new["remaining"] - old["remaining"]}, "$addToSet": {"membership_operations": operation_id}})
        if result.matched_count: return await database.users.find_one({"_id": uid})
    raise HTTPException(409, "تغيّر الاشتراك؛ حدّث الصفحة وأعد المحاولة.")

async def adjust_wallet(database, uid, *, purchased=None, deduct=0):
    """Manual purchased-credit set or monthly-first deduction with a CAS guard."""
    for _ in range(64):
        user = await database.users.find_one({'_id':uid})
        if not user: raise HTTPException(404, 'User not found')
        user = await refresh(user, database, grant_missing=False)
        total=max(0,int(user.get('token_balance') or 0))
        monthly=user.get('monthly') or {}
        remaining=min(total,max(0,int(monthly.get('remaining') or 0)))
        amount=min(total,max(0,int(deduct)))
        new_total=remaining+int(purchased) if purchased is not None else total-amount
        new_remaining=remaining if purchased is not None else remaining-min(remaining,amount)
        query={'_id':uid,'token_balance':user['token_balance'] if 'token_balance' in user else {'$exists':False},'monthly.version':monthly.get('version') or {'$exists':False}}
        update={'token_balance':new_total}
        if monthly.get('version'):
            query['monthly.remaining']=monthly['remaining']
            update['monthly.remaining']=new_remaining
        result=await database.users.update_one(query,{'$set':update})
        if result.matched_count:return await database.users.find_one({'_id':uid}),amount
    raise HTTPException(409,'تغيّر الرصيد؛ أعد المحاولة.')

async def initialize_monthly_memberships(database):
    """Idempotent upgrade of existing accounts before the API becomes ready."""
    async for user in database.users.find({'monthly.version':{'$exists':False},'role':{'$nin':list(STAFF)}}):
        await refresh(user, database)
