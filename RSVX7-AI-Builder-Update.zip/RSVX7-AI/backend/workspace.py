"""RSVX7-AI Workspace — Projects, Conversations, Messages (Phase 1).

Design notes:
- Client generates conversation & message IDs (short random strings) so the
  local UI can reference them optimistically before the server round-trip. The
  server accepts them as `_id` — collisions are ~0 probability.
- Every document carries `user_id`; every read filter includes it. There is no
  admin-scoped view of a user's workspace (personal data isolation).
- Messages live in a separate collection so we can paginate huge conversations,
  power global search later, and add version history / vector memory without
  reshaping the schema.
- All timestamps are ISO strings for painless JSON round-trips.
"""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, List, Optional
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Response, Query
from pydantic import BaseModel, Field, ConfigDict, field_validator
import secrets, os, io, logging, uuid, base64, asyncio, hashlib, re
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError
from motor.motor_asyncio import AsyncIOMotorGridFSBucket
from bson import ObjectId
from gridfs.errors import NoFile
from starlette.concurrency import run_in_threadpool

from auth import db, current_user, require_active_subscription
from tg_verify import require_membership
from persistence import uses_mysql, database_transaction
from manus_storage import put_object as manus_put_object, get_object as manus_get_object
from file_crypto import encrypt_payload, decrypt_payload, TAG_BYTES

logger = logging.getLogger("workspace")
router = APIRouter(prefix="/api/workspace")


# Attachments use the selected self-hosted storage backend.
APP_NAME = "rsvx7-ai"


async def _put_object(path: str, data: bytes, content_type: str) -> dict:
    if uses_mysql(db):
        if os.environ.get("FILE_STORAGE_BACKEND", "manus") != "manus":
            raise HTTPException(503, "Managed persistence requires Manus file storage")
        # Stable asset paths are publicly addressable. Upload only authenticated
        # ciphertext; its per-file key stays in private SQL metadata, never UI.
        encrypted, envelope = encrypt_payload(data)
        result = await manus_put_object(path, encrypted, "application/octet-stream")
        result["payload_encryption"] = envelope
        return result
    if os.environ.get("FILE_STORAGE_BACKEND", "gridfs") != "gridfs":
        raise HTTPException(503, "Mongo attachments require FILE_STORAGE_BACKEND=gridfs")
    bucket = AsyncIOMotorGridFSBucket(db, bucket_name="attachments")
    oid = await bucket.upload_from_stream(path, data, metadata={"content_type": content_type})
    return {"path": f"gridfs:{oid}"}


async def _get_object(path: str, envelope=None) -> tuple[bytes, str]:
    if path.startswith(("manus:", "/manus-storage/")):
        data, content_type = await manus_get_object(path, max_bytes=MAX_FILE_BYTES + TAG_BYTES)
        if envelope is not None:
            data = decrypt_payload(data, envelope)
        if len(data) > MAX_FILE_BYTES:
            raise HTTPException(413, "Stored file exceeds the supported limit")
        return data, content_type
    if uses_mysql(db):
        # No implicit read of Mongo/legacy provider when managed mode is chosen.
        raise HTTPException(404, "Managed file payload not found")
    if path.startswith("gridfs:"):
        oid = path.removeprefix("gridfs:")
        if not ObjectId.is_valid(oid):
            raise HTTPException(404, "File payload not found")
        bucket = AsyncIOMotorGridFSBucket(db, bucket_name="attachments")
        try:
            output = await bucket.open_download_stream(ObjectId(oid))
            data = await output.read(MAX_FILE_BYTES + 1)
            if len(data) > MAX_FILE_BYTES:
                raise HTTPException(413, "Stored file exceeds the supported limit")
            return data, (output.metadata or {}).get("content_type", "application/octet-stream")
        except NoFile:
            raise HTTPException(404, "File payload not found")
    raise HTTPException(410, "Attachment is not stored locally; import its original file into this server.")


# ─────────────────────── helpers ───────────────────────
def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id(prefix: str = "") -> str:
    return f"{prefix}{secrets.token_urlsafe(9)}"


_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$")
MAX_SEARCH_QUERY_LEN = 200
MAX_LIST_LIMIT = 500


def _validate_id(value: str, label: str = "id") -> str:
    """Reject path/query identifiers that could escape their resource scope."""
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise HTTPException(400, f"Invalid {label}")
    return value


def _default_project_id(uid: str) -> str:
    # Stable per-user id, without making the human name globally unique.
    digest = hashlib.sha256(uid.encode("utf-8")).hexdigest()[:24]
    return f"p_general_{digest}"


async def _get_project(pid: str, uid: str) -> dict:
    _validate_id(pid, "project id")
    p = await db.projects.find_one({"_id": pid, "user_id": uid})
    if not p:
        raise HTTPException(404, "Project not found")
    return p


async def _get_conversation(cid: str, uid: str) -> dict:
    _validate_id(cid, "conversation id")
    c = await db.conversations.find_one({"_id": cid, "user_id": uid})
    if not c:
        raise HTTPException(404, "Conversation not found")
    return c


# ─────────────────────── models ────────────────────────
class ProjectCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: str = Field(min_length=1, max_length=80)
    description: str = ""
    icon: str = "Sparkles"       # lucide icon name; frontend maps to component
    color: str = "#8B1D3F"        # hex color for the project tile
    is_favorite: bool = False


class ProjectUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: Optional[str] = Field(default=None, min_length=1, max_length=80)
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    is_favorite: Optional[bool] = None
    is_archived: Optional[bool] = None
    instructions: Optional[str] = Field(default=None, max_length=8000)
    touch_opened: Optional[bool] = None  # bump last_opened_at


class NoteBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    content: str = Field(min_length=1, max_length=4000)


class FileRename(BaseModel):
    model_config = ConfigDict(extra="ignore")
    name: str = Field(min_length=1, max_length=200)


class ConversationCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: str = Field(default="New chat", max_length=200)
    model_id: Optional[str] = None
    id: Optional[str] = None  # allow client-generated id for optimistic UI
    dark_mode: Optional[bool] = None


class ConversationUpdate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    is_pinned: Optional[bool] = None
    model_id: Optional[str] = None
    hidden_context: Optional[dict] = None  # legacy (userPrompt/aiResponse) — kept
    dark_mode: Optional[bool] = None       # silent auto-injection flag


class MessageCreate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    role: str  # user | assistant
    content: str
    files: List[dict] = []
    dark_mode_activator: Optional[bool] = None
    created_at: Optional[str] = None
    # Reasoning is provider output metadata, never a prompt/system message.
    reasoning: Optional[str] = Field(default=None, max_length=131072)
    reasoning_duration_ms: Optional[int] = Field(default=None, ge=0, le=10 * 60 * 1000)
    finish_reason: Optional[str] = Field(default=None, max_length=30)
    reasoning_started_at: Optional[str] = None

    @field_validator("reasoning_started_at")
    @classmethod
    def validate_reasoning_started_at(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        if not isinstance(value, str):
            raise ValueError("reasoning_started_at must be an ISO timestamp")
        try:
            datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("reasoning_started_at must be an ISO timestamp") from exc
        return value


# Kept as an alias for clients/tests using the original request name.
MessagePayload = MessageCreate


class TurnBody(BaseModel):
    """Persist a full turn (user message + assistant reply). Atomic and idempotent
    by message id."""
    model_config = ConfigDict(extra="ignore")
    messages: List[MessagePayload]
    # Optional convenience fields — server also updates conversation on turn save
    title: Optional[str] = None
    model_id: Optional[str] = None


class MigrateChatIn(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: Optional[str] = None
    title: str = "Chat"
    pinned: bool = False
    modelId: Optional[str] = None
    hiddenContext: Optional[dict] = None
    createdAt: Optional[int] = None
    updatedAt: Optional[int] = None
    messages: List[dict] = []


class MigrateBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    chats: List[MigrateChatIn]
    confirm_managed_import: bool = False


# ─────────────────────── indexes ───────────────────────
async def ensure_indexes():
    if uses_mysql(db):
        if os.environ.get("FILE_STORAGE_BACKEND", "manus") != "manus":
            raise RuntimeError("Managed workspace requires FILE_STORAGE_BACKEND=manus")
        return
    await db.projects.create_index([("user_id", 1), ("is_archived", 1), ("last_opened_at", -1)])
    await db.projects.create_index([("user_id", 1), ("is_favorite", -1)])
    await db.conversations.create_index([("user_id", 1), ("project_id", 1), ("is_pinned", -1), ("updated_at", -1)])
    await db.conversations.create_index([("user_id", 1), ("updated_at", -1)])
    await db.messages.create_index([("conversation_id", 1), ("order_index", 1)])
    await db.messages.create_index([("user_id", 1), ("created_at", -1)])
    await db.files.create_index([("user_id", 1), ("project_id", 1), ("is_deleted", 1), ("created_at", -1)])
    await db.files.create_index([("user_id", 1), ("project_id", 1), ("upload_status", 1), ("is_deleted", 1)])
    await db.notes.create_index([("user_id", 1), ("project_id", 1), ("created_at", -1)])
    if os.environ.get("FILE_STORAGE_BACKEND", "gridfs") != "gridfs":
        raise RuntimeError("Mongo attachments require FILE_STORAGE_BACKEND=gridfs")


# ─────────────────────── Projects ──────────────────────
@router.get("/projects")
async def list_projects(archived: bool = False, u: dict = Depends(current_user)):
    flt = {"user_id": u["_id"], "is_archived": bool(archived), "kind": {"$ne": "builder"}}
    docs = await db.projects.find(flt, {"builder": 0}).sort("last_opened_at", -1).to_list(MAX_LIST_LIMIT)
    return docs


@router.post("/projects")
async def create_project(body: ProjectCreate, u: dict = Depends(current_user)):
    pid = _new_id("p_")
    now = _now()
    doc = {
        "_id": pid, "user_id": u["_id"],
        "name": body.name.strip(), "description": body.description.strip(),
        "icon": body.icon, "color": body.color,
        "is_favorite": bool(body.is_favorite), "is_archived": False,
        "created_at": now, "updated_at": now, "last_opened_at": now,
        "conversation_count": 0, "active_file_count": 0,
    }
    await db.projects.insert_one(doc)
    return doc


@router.get("/projects/{pid}")
async def get_project(pid: str, u: dict = Depends(current_user)):
    p = await _get_project(pid, u["_id"])
    # Live conversation count for accuracy
    p["conversation_count"] = await db.conversations.count_documents({"project_id": pid, "user_id": u["_id"]})
    p.pop("builder", None)
    return p


@router.patch("/projects/{pid}")
async def update_project(pid: str, body: ProjectUpdate, u: dict = Depends(current_user)):
    await _get_project(pid, u["_id"])
    upd: dict[str, Any] = {}
    for k in ("name", "description", "icon", "color", "is_favorite", "is_archived", "instructions"):
        v = getattr(body, k)
        if v is not None:
            upd[k] = v.strip() if isinstance(v, str) else v
    if body.touch_opened:
        upd["last_opened_at"] = _now()
    if upd:
        upd["updated_at"] = _now()
        await db.projects.update_one({"_id": pid, "user_id": u["_id"]}, {"$set": upd})
    return await db.projects.find_one({"_id": pid, "user_id": u["_id"]}, {"builder": 0})


@router.delete("/projects/{pid}")
async def delete_project(pid: str, u: dict = Depends(current_user)):
    project = await _get_project(pid, u["_id"])
    if ((project.get("builder") or {}).get("job") or {}).get("status") == "running":
        raise HTTPException(409, "أوقف Builder قبل حذف المشروع.")
    async with database_transaction(db, collections=("conversations", "files", "messages", "notes", "projects")):
        return await _delete_project(pid, u)


async def _delete_project(pid: str, u: dict):
    await _get_project(pid, u["_id"])
    now = _now()
    conv_ids = [c["_id"] async for c in db.conversations.find({"project_id": pid, "user_id": u["_id"]}, {"_id": 1})]
    if conv_ids:
        await db.messages.delete_many({"conversation_id": {"$in": conv_ids}, "user_id": u["_id"]})
        await db.conversations.delete_many({"_id": {"$in": conv_ids}, "user_id": u["_id"]})
    # Notes have no external payload; remove them. File objects have no delete
    # API, so retain only non-searchable soft-deleted metadata. ``$ne`` also
    # catches legacy file documents that predate the is_deleted field.
    await db.notes.delete_many({"project_id": pid, "user_id": u["_id"]})
    await db.files.update_many(
        {"project_id": pid, "user_id": u["_id"], "is_deleted": {"$ne": True}},
        {"$set": {"is_deleted": True, "deleted_at": now, "upload_status": "deleted"}},
    )
    await db.projects.delete_one({"_id": pid, "user_id": u["_id"]})
    return {"ok": True, "deleted_conversations": len(conv_ids)}


# ───────────────────── Conversations ───────────────────
@router.get("/projects/{pid}/conversations")
async def list_conversations(pid: str, u: dict = Depends(current_user)):
    await _get_project(pid, u["_id"])
    docs = await db.conversations.find({"project_id": pid, "user_id": u["_id"]},
                                       {"messages": 0}).sort([("is_pinned", -1), ("updated_at", -1)]).to_list(MAX_LIST_LIMIT)
    return docs


@router.post("/projects/{pid}/conversations")
async def create_conversation(pid: str, body: ConversationCreate, u: dict = Depends(current_user)):
    async with database_transaction(db, collections=("conversations", "projects")):
        return await _create_conversation(pid, body, u)


async def _create_conversation(pid: str, body: ConversationCreate, u: dict):
    await _get_project(pid, u["_id"])
    cid = body.id or _new_id("c_")
    _validate_id(cid, "conversation id")
    if await db.conversations.find_one({"_id": cid}):
        raise HTTPException(409, "Conversation id already exists")
    now = _now()
    doc = {
        "_id": cid, "user_id": u["_id"], "project_id": pid,
        "title": body.title.strip() or "New chat",
        "is_pinned": False,
        "model_id": body.model_id,
        "hidden_context": None,
        # Dark Mode defaults to ON for new conversations — silent server-side
        # injection, no visible bubble, no round-trip. Users can toggle it off
        # via the Dark Mode button.
        "dark_mode": True if body.dark_mode is None else bool(body.dark_mode),
        "created_at": now, "updated_at": now,
        "message_count": 0, "next_order_index": 1,
    }
    try:
        await db.conversations.insert_one(doc)
    except DuplicateKeyError:
        # The preflight check above is only a fast path; requests can still
        # race between find and insert on standalone MongoDB.
        raise HTTPException(409, "Conversation id already exists")
    await db.projects.update_one({"_id": pid, "user_id": u["_id"]}, {"$set": {"updated_at": now, "last_opened_at": now},
                                                "$inc": {"conversation_count": 1}})
    return doc


@router.get("/conversations/{cid}")
async def get_conversation(cid: str, after: int = Query(0, ge=0), limit: int = Query(500, ge=1, le=MAX_LIST_LIMIT), u: dict = Depends(current_user)):
    c = await _get_conversation(cid, u["_id"])
    msgs = await db.messages.find(
        {"conversation_id": cid, "user_id": u["_id"], "order_index": {"$gt": after}}
    ).sort("order_index", 1).limit(limit).to_list(limit)
    c["messages"] = msgs
    return c


@router.patch("/conversations/{cid}")
async def update_conversation(cid: str, body: ConversationUpdate, u: dict = Depends(current_user)):
    await _get_conversation(cid, u["_id"])
    upd: dict[str, Any] = {}
    for k in ("title", "is_pinned", "model_id", "hidden_context", "dark_mode"):
        v = getattr(body, k)
        if v is not None:
            upd[k] = v.strip() if isinstance(v, str) else v
    if upd:
        upd["updated_at"] = _now()
        await db.conversations.update_one({"_id": cid, "user_id": u["_id"]}, {"$set": upd})
    return await db.conversations.find_one({"_id": cid, "user_id": u["_id"]}, {"messages": 0})


@router.delete("/conversations/{cid}")
async def delete_conversation(cid: str, u: dict = Depends(current_user)):
    async with database_transaction(db, collections=("conversations", "messages", "projects")):
        return await _delete_conversation(cid, u)


async def _delete_conversation(cid: str, u: dict):
    c = await _get_conversation(cid, u["_id"])
    await db.messages.delete_many({"conversation_id": cid, "user_id": u["_id"]})
    await db.conversations.delete_one({"_id": cid, "user_id": u["_id"]})
    await db.projects.update_one({"_id": c["project_id"], "user_id": u["_id"]},
                                 {"$inc": {"conversation_count": -1}, "$set": {"updated_at": _now()}})
    return {"ok": True}


async def _reserve_order_indexes(cid: str, uid: str, amount: int) -> int | None:
    """Reserve a durable contiguous range using the conversation document.

    Existing conversations predate next_order_index; initialize that field from
    the current max under an ``exists:false`` predicate before the atomic $inc.
    Gaps after a crashed request are intentional and safer than duplicate order
    indexes on MongoDB standalone (no replica-set transaction required).
    """
    if amount <= 0:
        return None
    for _ in range(3):
        conv = await db.conversations.find_one({"_id": cid, "user_id": uid}, {"next_order_index": 1})
        if not conv:
            raise HTTPException(404, "Conversation not found")
        if not isinstance(conv.get("next_order_index"), (int, float)):
            last = await db.messages.find(
                {"conversation_id": cid, "user_id": uid}, {"order_index": 1}
            ).sort("order_index", -1).limit(1).to_list(1)
            next_value = int(last[0].get("order_index", 0)) + 1 if last else 1
            init_filter = {"_id": cid, "user_id": uid}
            if "next_order_index" in conv:
                # Repair null/legacy values without overwriting a concurrent
                # reservation made after the read above.
                init_filter["next_order_index"] = conv["next_order_index"]
            else:
                init_filter["next_order_index"] = {"$exists": False}
            await db.conversations.update_one(
                init_filter,
                {"$set": {"next_order_index": next_value}},
            )
        before = await db.conversations.find_one_and_update(
            {"_id": cid, "user_id": uid, "next_order_index": {"$type": "number"}},
            {"$inc": {"next_order_index": amount}},
            return_document=ReturnDocument.BEFORE,
        )
        if before is not None:
            return int(before.get("next_order_index", 1))
    raise HTTPException(409, "Could not reserve message order; retry")


def _assistant_metadata(message: MessageCreate) -> dict[str, Any]:
    """Return only explicitly supplied reasoning metadata for assistant rows."""
    if message.role != "assistant":
        return {}
    supplied = getattr(message, "model_fields_set", set())
    return {
        field: getattr(message, field)
        for field in (
            "reasoning",
            "reasoning_duration_ms",
            "finish_reason",
            "reasoning_started_at",
        )
        if field in supplied
    }


class DropMessagesBody(BaseModel):
    ids: List[str]


@router.post("/conversations/{cid}/messages/drop")
async def drop_messages(cid: str, body: DropMessagesBody, u: dict = Depends(current_user)):
    """Remove messages replaced by a retry or an edit so they don't reappear after reload."""
    await _get_conversation(cid, u["_id"])
    ids = [_validate_id(i, "message id") for i in body.ids[:200]]
    res = await db.messages.delete_many({"_id": {"$in": ids}, "conversation_id": cid, "user_id": u["_id"]})
    total = await db.messages.count_documents({"conversation_id": cid, "user_id": u["_id"]})
    await db.conversations.update_one({"_id": cid, "user_id": u["_id"]}, {"$set": {"message_count": total, "updated_at": _now()}})
    return {"ok": True, "deleted": res.deleted_count}


@router.post("/conversations/{cid}/turn")
async def append_turn(cid: str, body: TurnBody, u: dict = Depends(current_user)):
    async with database_transaction(db, collections=("conversations", "messages", "projects")):
        return await _append_turn(cid, body, u)


async def _append_turn(cid: str, body: TurnBody, u: dict):
    """Persist a completed turn idempotently without cross-conversation id reuse."""
    c = await _get_conversation(cid, u["_id"])
    now = _now()
    ids = [_validate_id(m.id, "message id") for m in body.messages]
    if len(ids) != len(set(ids)):
        raise HTTPException(409, "Duplicate message id in turn")
    for m in body.messages:
        if m.role not in ("user", "assistant"):
            raise HTTPException(422, "Invalid message role")

    existing_docs = {}
    if ids:
        async for existing in db.messages.find({"_id": {"$in": ids}}):
            if existing.get("user_id") != u["_id"] or existing.get("conversation_id") != cid:
                raise HTTPException(409, "Message id belongs to another conversation")
            existing_docs[existing["_id"]] = existing
    new_messages = [m for m in body.messages if m.id not in existing_docs]
    first_order = await _reserve_order_indexes(cid, u["_id"], len(new_messages))
    order_by_id = {
        m.id: first_order + i for i, m in enumerate(new_messages)
    } if first_order is not None else {}

    persisted = 0
    for m in body.messages:
        fields = {"content": m.content, "files": m.files or [], "updated_at": now}
        fields.update(_assistant_metadata(m))
        if m.id in existing_docs:
            await db.messages.update_one({"_id": m.id, "user_id": u["_id"]}, {"$set": fields})
            persisted += 1
            continue
        doc = {
            "_id": m.id, "user_id": u["_id"], "conversation_id": cid,
            "project_id": c["project_id"], "role": m.role, "content": m.content,
            "files": m.files or [], "dark_mode_activator": bool(m.dark_mode_activator or False),
            "order_index": order_by_id[m.id], "created_at": m.created_at or now,
        }
        doc.update(_assistant_metadata(m))
        try:
            await db.messages.insert_one(doc)
        except DuplicateKeyError:
            # Another standalone Mongo request won the race. Reconcile only if
            # it is this conversation; never silently move a message.
            raced = await db.messages.find_one({"_id": m.id})
            if not raced or raced.get("user_id") != u["_id"] or raced.get("conversation_id") != cid:
                raise HTTPException(409, "Message id belongs to another conversation")
            await db.messages.update_one({"_id": m.id, "user_id": u["_id"]}, {"$set": fields})
        persisted += 1

    total = await db.messages.count_documents({"conversation_id": cid, "user_id": u["_id"]})
    conv_upd: dict[str, Any] = {"updated_at": now, "message_count": total}
    if body.title:
        conv_upd["title"] = body.title.strip()[:200]
    if body.model_id:
        conv_upd["model_id"] = body.model_id
    await db.conversations.update_one({"_id": cid, "user_id": u["_id"]}, {"$set": conv_upd})
    await db.projects.update_one({"_id": c["project_id"], "user_id": u["_id"]},
                                 {"$set": {"last_opened_at": now, "updated_at": now}})
    return {"ok": True, "message_count": total, "persisted": persisted}


# ─────────────────── Default Project + Migration ───────
DEFAULT_PROJECT_NAME = "General"


async def _ensure_default_project(uid: str) -> dict:
    """Upsert/revive a per-user General without a global name uniqueness rule."""
    legacy = await db.projects.find_one({"user_id": uid, "name": DEFAULT_PROJECT_NAME})
    now = _now()
    if legacy:
        revived = await db.projects.find_one_and_update(
            {"_id": legacy["_id"], "user_id": uid},
            {"$set": {"is_archived": False, "updated_at": now, "last_opened_at": now}},
            return_document=ReturnDocument.AFTER,
        )
        if revived:
            return revived
    pid = _default_project_id(uid)
    doc = {
        "_id": pid, "user_id": uid,
        "name": DEFAULT_PROJECT_NAME,
        "description": "Your default workspace — general chats and quick tasks.",
        "icon": "MessageSquare", "color": "#8B1D3F",
        "is_favorite": True, "is_archived": False,
        "created_at": now, "updated_at": now, "last_opened_at": now,
        "conversation_count": 0, "active_file_count": 0,
    }
    try:
        return await db.projects.find_one_and_update(
            {"_id": pid, "user_id": uid},
            {"$set": {"is_archived": False, "updated_at": now, "last_opened_at": now},
             "$setOnInsert": {k: v for k, v in doc.items()
                               if k not in {"is_archived", "updated_at", "last_opened_at"}}},
            upsert=True, return_document=ReturnDocument.AFTER,
        )
    except DuplicateKeyError:
        # A concurrent bootstrap may have inserted this same user's default
        # project. Reuse it while retaining the owner filter on every lookup.
        existing = await db.projects.find_one_and_update(
            {"_id": pid, "user_id": uid},
            {"$set": {"is_archived": False, "updated_at": now, "last_opened_at": now}},
            return_document=ReturnDocument.AFTER,
        )
        if existing:
            return existing
        raise HTTPException(409, "Default project id collision; retry")


@router.post("/bootstrap")
async def bootstrap(u: dict = Depends(current_user)):
    """Idempotent: ensures the user has at least the 'General' project. Called on
    workspace mount so first-time users see an immediate destination."""
    p = await _ensure_default_project(u["_id"])
    p.pop("builder", None)
    return {"ok": True, "default_project": p}


@router.post("/migrate")
async def migrate_from_local(body: MigrateBody, u: dict = Depends(current_user)):
    """Import a list of localStorage conversations into the user's 'General'
    project. Idempotent by conversation id — re-running won't duplicate."""
    if uses_mysql(db) and not body.confirm_managed_import:
        raise HTTPException(409, "Importing old local data into managed storage needs explicit confirmation")
    project = await _ensure_default_project(u["_id"])
    pid = project["_id"]
    now = _now()
    imported_conv = 0
    imported_msg = 0
    for chat_idx, ch in enumerate(body.chats):
        cid = ch.id or "c_mig_" + hashlib.sha256(
            f"{u['_id']}|{chat_idx}|{ch.title}|{ch.createdAt or ''}".encode()
        ).hexdigest()[:24]
        _validate_id(cid, "conversation id")
        existing_conv = await db.conversations.find_one({"_id": cid})
        if existing_conv and existing_conv.get("user_id") != u["_id"]:
            raise HTTPException(409, "Conversation id belongs to another user")
        created_iso = (
            datetime.fromtimestamp((ch.createdAt or 0) / 1000, tz=timezone.utc).isoformat()
            if ch.createdAt else now
        )
        updated_iso = (
            datetime.fromtimestamp((ch.updatedAt or 0) / 1000, tz=timezone.utc).isoformat()
            if ch.updatedAt else now
        )
        conv_doc = {
            "_id": cid, "user_id": u["_id"], "project_id": pid,
            "title": (ch.title or "Chat")[:200],
            "is_pinned": bool(ch.pinned),
            "model_id": ch.modelId,
            "hidden_context": ch.hiddenContext or None,
            "created_at": created_iso, "updated_at": updated_iso,
            "message_count": 0, "next_order_index": 1,
        }
        conv_result = await db.conversations.update_one(
            {"_id": cid}, {"$setOnInsert": conv_doc}, upsert=True
        )
        imported_conv += 1 if conv_result.upserted_id is not None else 0
        conv = await db.conversations.find_one({"_id": cid, "user_id": u["_id"]})
        target_pid = conv.get("project_id", pid)
        # Upsert messages individually so a later request resumes after a
        # partial failure instead of skipping the whole conversation.
        for idx, m in enumerate(ch.messages or [], start=1):
            role = m.get("role")
            if role not in ("user", "assistant"): continue
            mid = m.get("id") or "m_mig_" + hashlib.sha256(
                f"{u['_id']}|{cid}|{idx}".encode()
            ).hexdigest()[:24]
            _validate_id(mid, "message id")
            existing_msg = await db.messages.find_one({"_id": mid})
            if existing_msg and (existing_msg.get("user_id") != u["_id"] or
                                  existing_msg.get("conversation_id") != cid):
                raise HTTPException(409, "Message id belongs to another conversation")
            m_created = (
                datetime.fromtimestamp((m.get("createdAt") or 0) / 1000, tz=timezone.utc).isoformat()
                if m.get("createdAt") else now
            )
            msg_doc = {
                "_id": mid, "user_id": u["_id"], "conversation_id": cid,
                "project_id": target_pid,
                "role": role, "content": m.get("content") or "",
                "files": m.get("files") or [],
                "dark_mode_activator": bool(m.get("darkModeActivator") or False),
                "order_index": idx,
                "created_at": m_created,
            }
            msg_result = await db.messages.update_one(
                {"_id": mid},
                {"$set": {k: v for k, v in msg_doc.items() if k not in ("_id", "order_index", "created_at")},
                 "$setOnInsert": {"order_index": idx, "created_at": m_created}},
                upsert=True,
            )
            imported_msg += 1 if msg_result.upserted_id is not None else 0
        # Sync message_count
        total = await db.messages.count_documents({"conversation_id": cid, "user_id": u["_id"]})
        last_msg = await db.messages.find({"conversation_id": cid, "user_id": u["_id"]}, {"order_index": 1}).sort("order_index", -1).limit(1).to_list(1)
        next_idx = int(last_msg[0].get("order_index", 0)) + 1 if last_msg else 1
        await db.conversations.update_one(
            {"_id": cid, "user_id": u["_id"]},
            {"$set": {"message_count": total}, "$max": {"next_order_index": next_idx}},
        )
    # Sync project count
    await db.projects.update_one({"_id": pid}, {"$set": {
        "conversation_count": await db.conversations.count_documents({"project_id": pid, "user_id": u["_id"]}),
        "updated_at": now, "last_opened_at": now,
    }})
    return {"ok": True, "project_id": pid, "conversations_imported": imported_conv, "messages_imported": imported_msg}



# ═══════════════════════ Notes (AI Memory) ═══════════════════════
@router.get("/projects/{pid}/notes")
async def list_notes(pid: str, u: dict = Depends(current_user)):
    await _get_project(pid, u["_id"])
    docs = await db.notes.find({"project_id": pid, "user_id": u["_id"]}).sort("created_at", -1).to_list(MAX_LIST_LIMIT)
    return [{**d, "_id": str(d.get("_id"))} for d in docs]


@router.post("/projects/{pid}/notes")
async def create_note(pid: str, body: NoteBody, u: dict = Depends(current_user)):
    await _get_project(pid, u["_id"])
    nid = _new_id("n_")
    now = _now()
    doc = {"_id": nid, "user_id": u["_id"], "project_id": pid,
           "content": body.content.strip(), "created_at": now, "updated_at": now}
    await db.notes.insert_one(doc)
    return {**doc, "_id": str(doc["_id"])}


@router.patch("/notes/{nid}")
async def update_note(nid: str, body: NoteBody, u: dict = Depends(current_user)):
    _validate_id(nid, "note id")
    r = await db.notes.update_one({"_id": nid, "user_id": u["_id"]},
                                  {"$set": {"content": body.content.strip(), "updated_at": _now()}})
    if not r.matched_count: raise HTTPException(404, "Note not found")
    return await db.notes.find_one({"_id": nid})


@router.delete("/notes/{nid}")
async def delete_note(nid: str, u: dict = Depends(current_user)):
    _validate_id(nid, "note id")
    r = await db.notes.delete_one({"_id": nid, "user_id": u["_id"]})
    if not r.deleted_count: raise HTTPException(404, "Note not found")
    return {"ok": True}


# ═══════════════════════ Files ═══════════════════════
MAX_FILE_BYTES = 25 * 1024 * 1024        # 25 MB per file (matches user spec)
MAX_FILES_PER_PROJECT = 50                # Configurable via admin later
TEXT_EXTS = {".txt", ".md", ".csv", ".json", ".xml", ".yml", ".yaml", ".py", ".js",
             ".ts", ".tsx", ".jsx", ".html", ".css", ".c", ".cpp", ".h", ".hpp",
             ".java", ".kt", ".swift", ".php", ".go", ".rs", ".sql", ".sh"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tiff"}
MAX_EXTRACTED_CHARS = 60_000               # cap per file for AI context injection


async def _read_upload_limited(upload: UploadFile) -> bytes:
    """Read multipart data in bounded chunks and stop at 25MB + one byte."""
    chunks: list[bytes] = []
    total = 0
    while total <= MAX_FILE_BYTES:
        chunk = await upload.read(min(1024 * 1024, MAX_FILE_BYTES + 1 - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
        if total > MAX_FILE_BYTES:
            raise HTTPException(413, f"File too large (>{MAX_FILE_BYTES // (1024*1024)}MB)")
    return b"".join(chunks)


async def _reserve_file_slot(pid: str, uid: str) -> bool:
    """Reserve one slot with an atomic project update; safe on Mongo standalone."""
    project = await _get_project(pid, uid)
    if not isinstance(project.get("active_file_count"), (int, float)):
        count = await db.files.count_documents({
            "project_id": pid, "user_id": uid, "is_deleted": {"$ne": True},
        })
        await db.projects.update_one(
            {"_id": pid, "user_id": uid, "active_file_count": {"$exists": False}},
            {"$set": {"active_file_count": count}},
        )
    result = await db.projects.update_one(
        {"_id": pid, "user_id": uid, "active_file_count": {"$lt": MAX_FILES_PER_PROJECT}},
        {"$inc": {"active_file_count": 1}},
    )
    return bool(result.modified_count)


async def _release_file_slot(pid: str, uid: str) -> None:
    await db.projects.update_one(
        {"_id": pid, "user_id": uid, "active_file_count": {"$gt": 0}},
        {"$inc": {"active_file_count": -1}},
    )


def _extract_text_sync(data: bytes, ext: str) -> tuple[str, str]:
    """Extract text from an uploaded file. Returns (text, kind)."""
    kind = "unknown"
    text = ""
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            chunks = []
            for i, page in enumerate(reader.pages):
                try: t = page.extract_text() or ""
                except Exception: t = ""
                chunks.append(f"--- Page {i+1} ---\n{t}")
            text = "\n\n".join(chunks).strip()
            kind = "pdf"
        elif ext == ".docx":
            from docx import Document as DocxDocument
            doc = DocxDocument(io.BytesIO(data))
            text = "\n".join(p.text for p in doc.paragraphs if p.text).strip()
            kind = "docx"
        elif ext in IMAGE_EXTS:
            kind = "image"
            try:
                from PIL import Image
                import pytesseract
                img = Image.open(io.BytesIO(data))
                if img.mode != "RGB": img = img.convert("RGB")
                try: text = pytesseract.image_to_string(img, lang="ara+eng").strip()
                except Exception: text = pytesseract.image_to_string(img).strip()
            except Exception:
                text = ""
        elif ext in TEXT_EXTS:
            kind = "text"
            try: text = data.decode("utf-8", errors="replace")
            except Exception: text = data.decode("latin-1", errors="replace")
    except Exception as e:
        logger.warning("Extract failed for %s: %s", ext, e)
    if len(text) > MAX_EXTRACTED_CHARS:
        text = text[:MAX_EXTRACTED_CHARS]
    return text, kind


async def _extract_text(data: bytes, ext: str) -> tuple[str, str]:
    return await run_in_threadpool(_extract_text_sync, data, ext)


@router.post("/projects/{pid}/files")
async def upload_file(pid: str, file: UploadFile = File(...), u: dict = Depends(current_user)):
    """Upload to managed Manus storage; local Mongo keeps its own GridFS profile."""
    # Membership → Subscription → project → quota
    await require_membership(u)
    await require_active_subscription(u, feature="files")
    await _get_project(pid, u["_id"])
    if not await _reserve_file_slot(pid, u["_id"]):
        raise HTTPException(400, f"Project file limit reached ({MAX_FILES_PER_PROJECT})")
    try:
        data = await _read_upload_limited(file)
    except Exception:
        await _release_file_slot(pid, u["_id"])
        raise
    name = os.path.basename(file.filename or "file") or "file"
    raw_ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
    ext = raw_ext if re.fullmatch(r"\.[a-z0-9]{1,10}", raw_ext) else ""
    path = f"{APP_NAME}/uploads/{u['_id']}/{uuid.uuid4()}{ext}"
    content_type = file.content_type or "application/octet-stream"
    fid = _new_id("f_")
    now = _now()
    doc = {
        "_id": fid, "user_id": u["_id"], "project_id": pid,
        "storage_path": path,
        "name": name, "ext": ext, "content_type": content_type,
        "size": len(data), "kind": "unknown",
        "extracted_text": "", "extracted_len": 0,
        "in_context": True, "is_deleted": False, "upload_status": "pending",
        "created_at": now, "updated_at": now,
    }
    try:
        await db.files.insert_one(doc)
        result = await _put_object(path, data, content_type)
        text, kind = await _extract_text(data, ext)
        await db.files.update_one(
            {"_id": fid, "user_id": u["_id"], "is_deleted": False},
            {"$set": {"storage_path": result.get("path", path), "kind": kind,
                      "storage_stable_path": result.get("stable_path"),
                      "payload_encryption": result.get("payload_encryption"),
                      "extracted_text": text, "extracted_len": len(text),
                      "upload_status": "ready", "updated_at": _now()}},
        )
    except Exception:
        await db.files.update_one(
            {"_id": fid, "user_id": u["_id"]},
            {"$set": {"is_deleted": True, "upload_status": "failed", "deleted_at": _now()}},
        )
        await _release_file_slot(pid, u["_id"])
        raise
    await db.projects.update_one({"_id": pid, "user_id": u["_id"]}, {"$set": {"updated_at": now, "last_opened_at": now}})
    doc.update({"storage_path": result.get("path", path), "kind": kind,
                "extracted_text": text, "extracted_len": len(text), "upload_status": "ready"})
    doc.pop("extracted_text", None)
    return doc


@router.get("/projects/{pid}/files")
async def list_files(pid: str, u: dict = Depends(current_user)):
    await _get_project(pid, u["_id"])
    docs = await db.files.find(
        {"project_id": pid, "user_id": u["_id"], "is_deleted": False,
         "$or": [{"upload_status": "ready"}, {"upload_status": {"$exists": False}}]},
        {"extracted_text": 0, "payload_encryption": 0},
    ).sort("created_at", -1).to_list(MAX_LIST_LIMIT)
    return docs


@router.patch("/files/{fid}")
async def update_file(fid: str, body: dict, u: dict = Depends(current_user)):
    _validate_id(fid, "file id")
    upd: dict[str, Any] = {}
    if isinstance(body.get("name"), str) and body["name"].strip():
        upd["name"] = body["name"].strip()[:200]
    if "in_context" in body:
        upd["in_context"] = bool(body["in_context"])
    if not upd: return {"ok": True}
    upd["updated_at"] = _now()
    r = await db.files.update_one({"_id": fid, "user_id": u["_id"], "is_deleted": False}, {"$set": upd})
    if not r.matched_count: raise HTTPException(404, "File not found")
    return await db.files.find_one({"_id": fid, "user_id": u["_id"]}, {"extracted_text": 0, "payload_encryption": 0})


@router.delete("/files/{fid}")
async def delete_file(fid: str, u: dict = Depends(current_user)):
    """Soft-delete (object storage has no delete API). The file is invisible in
    all listings and never re-injected into AI context."""
    _validate_id(fid, "file id")
    r = await db.files.update_one(
        {"_id": fid, "user_id": u["_id"], "is_deleted": False},
        {"$set": {"is_deleted": True, "upload_status": "deleted", "deleted_at": _now()}},
    )
    if not r.matched_count: raise HTTPException(404, "File not found")
    doc = await db.files.find_one({"_id": fid, "user_id": u["_id"]}, {"project_id": 1})
    if doc:
        await _release_file_slot(doc["project_id"], u["_id"])
    return {"ok": True}


@router.get("/files/{fid}/download")
async def download_file(fid: str, u: dict = Depends(current_user)):
    """Serve file bytes using the shared current_user dependency only."""
    _validate_id(fid, "file id")
    doc = await db.files.find_one({"_id": fid, "user_id": u["_id"], "is_deleted": False,
                                   "$or": [{"upload_status": "ready"},
                                            {"upload_status": {"$exists": False}}]})
    if not doc: raise HTTPException(404, "File not found")
    try:
        if doc.get("payload_encryption"):
            data, ct = await _get_object(doc["storage_path"], doc["payload_encryption"])
        else:
            data, ct = await _get_object(doc["storage_path"])
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("File download failed")
        raise HTTPException(502, "تعذر قراءة المرفق من التخزين. حاول مرة أخرى.")
    from urllib.parse import quote
    return Response(
        content=data, media_type=doc.get("content_type") or ct or "application/octet-stream",
        headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
                 "Content-Disposition": "attachment; filename*=UTF-8''" + quote(doc.get("name") or "attachment", safe="")},
    )


async def project_memory_prompt(user_id: str, project_id: str) -> str:
    """Build the memory snippet injected into the system prompt for chats inside
    this project. Combines project instructions + notes + attached-file
    extracts. Returns "" if nothing to add."""
    parts: list[str] = []
    proj = await db.projects.find_one({"_id": project_id, "user_id": user_id})
    if not proj: return ""
    instr = (proj.get("instructions") or "").strip()
    if instr:
        parts.append(f"### Project instructions\n{instr}")
    notes = await db.notes.find({"project_id": project_id, "user_id": user_id}).sort("created_at", -1).limit(20).to_list(20)
    if notes:
        joined = "\n".join(f"- {n['content']}" for n in notes)
        parts.append(f"### User notes\n{joined}")
    files = await db.files.find(
        {"project_id": project_id, "user_id": user_id, "is_deleted": False,
         "$or": [{"upload_status": "ready"}, {"upload_status": {"$exists": False}}],
         "in_context": True},
        {"name": 1, "kind": 1, "extracted_text": 1},
    ).sort("created_at", -1).limit(10).to_list(10)
    for f in files:
        text = (f.get("extracted_text") or "").strip()
        if not text: continue
        head = f"### File: {f['name']} ({f.get('kind','?')})"
        parts.append(f"{head}\n```\n{text}\n```")
    if not parts: return ""
    return (
        "The user is working inside a project. Use the following persistent "
        "context (instructions, notes, uploaded files) whenever it is relevant.\n\n"
        + "\n\n".join(parts)
    )


# ═══════════════════════ Global Search ═══════════════════════
@router.get("/search")
async def global_search(q: str = Query("", max_length=MAX_SEARCH_QUERY_LEN),
                        limit: int = Query(8, ge=1, le=50),
                        u: dict = Depends(current_user)):
    """Cross-workspace search across projects / conversations / messages / files."""
    q = (q or "").strip()
    if not q or len(q) < 2:
        return {"projects": [], "conversations": [], "messages": [], "files": []}
    import re
    pat = re.escape(q)
    rx = {"$regex": pat, "$options": "i"}
    projs = await db.projects.find(
        {"user_id": u["_id"], "kind": {"$ne": "builder"}, "$or": [{"name": rx}, {"description": rx}, {"instructions": rx}]}, {"builder": 0},
    ).sort("updated_at", -1).limit(limit).to_list(limit)
    convs = await db.conversations.find(
        {"user_id": u["_id"], "title": rx},
    ).sort("updated_at", -1).limit(limit).to_list(limit)
    msgs = await db.messages.find(
        {"user_id": u["_id"], "content": rx},
    ).sort("created_at", -1).limit(limit).to_list(limit)
    for m in msgs:
        c = m.get("content", "")
        m["snippet"] = c[:240] + ("…" if len(c) > 240 else "")
    files = await db.files.find(
        {"user_id": u["_id"], "is_deleted": False, "name": rx,
         "$or": [{"upload_status": "ready"}, {"upload_status": {"$exists": False}}]},
        {"extracted_text": 0},
    ).sort("created_at", -1).limit(limit).to_list(limit)
    return {"projects": projs, "conversations": convs, "messages": msgs, "files": files}
