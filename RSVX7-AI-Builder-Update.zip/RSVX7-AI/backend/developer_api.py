"""Paid developer keys and a narrow OpenAI-compatible chat facade."""
import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, AliasChoices
from starlette.responses import JSONResponse, StreamingResponse

import auth
from memberships import entitlements, refresh, require_access

router = APIRouter(tags=['Developer API'])


def require_paid(user):
    if entitlements(user)['plan'] not in ('pro', 'max'):
        raise HTTPException(403, {'code': 'plan_required', 'message': 'API access requires an active Pro or Max plan.'})


def digest(token):
    return hashlib.sha256(token.encode('utf-8')).hexdigest()


def require_same_origin(request):
    origin = request.headers.get('origin')
    if not origin:
        return
    try:
        parsed = urlsplit(origin)
    except ValueError:
        raise HTTPException(403, 'Invalid origin')
    allowed = {entry.strip().rstrip('/') for entry in os.environ.get('CORS_ORIGINS', '').split(',') if entry.strip()}
    if not (parsed.scheme in ('http', 'https') and not parsed.path and not parsed.query and not parsed.fragment
            and (parsed.netloc.lower() == request.headers.get('host', '').lower() or origin.rstrip('/') in allowed)):
        raise HTTPException(403, 'Invalid origin')


@router.get('/api/developer/key')
async def key_status(user=Depends(auth.current_user)):
    current = await auth.db.users.find_one({'_id': user['_id']})
    return {'configured': bool((current or {}).get('api_access')), 'paid': entitlements(user)['plan'] in ('pro', 'max')}


@router.post('/api/developer/key')
async def create_key(request: Request, user=Depends(auth.current_user)):
    require_same_origin(request)
    require_paid(user)
    uid = base64.urlsafe_b64encode(user['_id'].encode()).decode().rstrip('=')
    token = 'rsvx7_' + uid + '.' + secrets.token_urlsafe(32)
    await auth.db.users.update_one({'_id': user['_id']}, {'$set': {'api_access': {'hash': digest(token), 'session_version': int(user.get('session_version', 0) or 0)}}})
    return JSONResponse({'key': token}, headers={'Cache-Control': 'no-store'})


@router.delete('/api/developer/key')
async def revoke_key(request: Request, user=Depends(auth.current_user)):
    require_same_origin(request)
    await auth.db.users.update_one({'_id': user['_id']}, {'$unset': {'api_access': ''}})
    return {'ok': True}


async def key_user(request: Request):
    header = request.headers.get('authorization', '')
    token = header[7:] if header.startswith('Bearer ') else ''
    try:
        if len(token) > 400 or not token.startswith('rsvx7_'):
            raise ValueError()
        encoded, secret = token[6:].split('.', 1)
        if not secret or not encoded:
            raise ValueError()
        uid = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8')
        if not uid or len(uid) > 191:
            raise ValueError()
    except (ValueError, UnicodeError):
        raise HTTPException(401, 'Invalid API key')
    user = await auth.db.users.find_one({'_id': uid})
    access = (user or {}).get('api_access') or {}
    if not access.get('hash') or not hmac.compare_digest(access['hash'], digest(token)):
        raise HTTPException(401, 'Invalid API key')
    if int(access.get('session_version', -1)) != int(user.get('session_version', 0) or 0):
        raise HTTPException(401, 'API key revoked')
    if user.get('status') == 'suspended' or user.get('must_change_password'):
        raise HTTPException(403, 'Account unavailable')
    user = await refresh(user, auth.db, grant_missing=False)
    require_paid(user)
    return user


@router.get('/api/v1/models')
async def models(user=Depends(key_user)):
    import server
    rows = []
    for name in entitlements(user)['models']:
        setting = await server.current_settings(name)
        from tool_compat import tool_mode
        mode = tool_mode(setting)
        rows.append({'id': name, 'object': 'model', 'owned_by': 'rsvx7',
                     'context_length': setting['context_length'],
                     'max_output_tokens': setting['max_completion_tokens'],
                     'supports_tools': mode != 'unavailable',
                     'native_supports_tools': mode == 'native', 'tool_calling_mode': mode})
    return {'object': 'list', 'data': rows}


from tool_protocol import ToolMessage as Message, ToolDefinition, ToolAccumulator


class Completion(BaseModel):
    model_config = ConfigDict(extra='forbid')
    model: str
    messages: list[Message] = Field(min_length=1, max_length=2048)
    stream: bool = False
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1, validation_alias=AliasChoices("max_tokens", "max_completion_tokens"))
    stream_options: dict | None = None
    tools: list[ToolDefinition] | None = Field(default=None, max_length=128)
    tool_choice: str | dict | None = None
    parallel_tool_calls: bool | None = None


@router.post('/api/v1/chat/completions')
async def completion(body: Completion, user=Depends(key_user)):
    import server
    require_access(user, model=body.model)
    messages = body.messages
    system = None
    leading = []
    while messages and messages[0].role in ('system', 'developer'):
        leading.append(messages[0].content)
        messages = messages[1:]
    if leading: system = '\n\n'.join(leading)
    if not messages or any(m.role not in ('user','assistant','tool') for m in messages):
        raise HTTPException(400, 'Only leading system/developer messages and user/assistant/tool messages are supported')
    if body.stream_options and set(body.stream_options) - {'include_usage'}:
        raise HTTPException(400, 'Unsupported stream_options')
    request = server.ChatStreamRequest(messages=[m.model_dump() for m in messages], personality=body.model,
                                       temperature=body.temperature, max_tokens=body.max_tokens, api_system=system,
                                       tools=body.tools, tool_choice=body.tool_choice, parallel_tool_calls=body.parallel_tool_calls)
    from api_lifetime import APIResponse
    try:
        source = await server.chat_stream(request, user)
    except HTTPException as error:
        if isinstance(error.detail, dict) and error.detail.get('code') == 'context_length_exceeded':
            return JSONResponse({'error': error.detail}, status_code=400)
        if error.status_code == 409:
            return JSONResponse({'error': {'code': 'generation_in_progress',
                'type': 'rate_limit_error', 'message': 'An account generation is still active. Stop it or wait for completion.'}},
                status_code=429, headers={'Retry-After': '2'})
        raise
    ident, created = 'chatcmpl-' + secrets.token_hex(12), int(time.time())

    async def events():
        async for part in source.body_iterator:
            if isinstance(part, bytes):
                part = part.decode('utf-8')
            for line in part.splitlines():
                if not line.startswith('data: '):
                    continue
                raw = line[6:]
                if raw == '[DONE]':
                    return
                yield json.loads(raw)

    def item(delta, finish=None):
        return {'id': ident, 'object': 'chat.completion.chunk', 'created': created, 'model': body.model,
                'choices': [{'index': 0, 'delta': delta, 'finish_reason': finish}]}

    async def stream_response():
        usage = None
        completed = False
        yield 'data: ' + json.dumps(item({'role': 'assistant'})) + '\n\n'
        async for event in events():
            if 'error' in event:
                yield 'data: ' + json.dumps({'error': event['error']}, ensure_ascii=False) + '\n\n'
                yield 'data: [DONE]\n\n'
                return
            if 'tc' in event:
                yield 'data: ' + json.dumps(item({'tool_calls': event['tc']}), ensure_ascii=False) + '\n\n'
            if 'r' in event:
                yield 'data: ' + json.dumps(item({'reasoning_content': event['r']}), ensure_ascii=False) + '\n\n'
            if 't' in event:
                yield 'data: ' + json.dumps(item({'content': event['t']}), ensure_ascii=False) + '\n\n'
            if 'usage' in event and body.stream_options and body.stream_options.get('include_usage'):
                u = event['usage']
                usage = {'prompt_tokens': u['prompt_tokens'], 'completion_tokens': u['output'], 'total_tokens': u['prompt_tokens'] + u['output']}
            if 'finish' in event:
                completed = True
                yield 'data: ' + json.dumps(item({}, event['finish'])) + '\n\n'
        if not completed:
            yield 'data: ' + json.dumps({'error': {'message': 'Provider response did not complete'}}) + '\n\n'
        elif usage is not None:
            yield 'data: ' + json.dumps({'id': ident, 'object': 'chat.completion.chunk', 'created': created,
                'model': body.model, 'choices': [], 'usage': usage}) + '\n\n'
        yield 'data: [DONE]\n\n'

    if body.stream:
        return APIResponse(source, stream=server._sse_response(stream_response()))
    async def collect_response():
        text, finish, usage, reasoning = [], None, None, []
        calls = ToolAccumulator(body.tools)
        async for event in events():
            if 'error' in event:
                raise HTTPException(502, event['error'])
            if 'tc' in event: calls.push(event['tc'])
            if 'r' in event: reasoning.append(event['r'])
            if 't' in event: text.append(event['t'])
            if 'finish' in event: finish = event['finish']
            if 'usage' in event:
                u = event['usage']; usage = {'prompt_tokens': u['prompt_tokens'], 'completion_tokens': u['output'], 'total_tokens': u['prompt_tokens'] + u['output']}
        if not finish:
            raise HTTPException(502, 'Provider response did not complete')
        calls.finish(finish)
        message = {'role': 'assistant', 'content': ''.join(text) or (None if calls.calls else '')}
        if calls.calls: message['tool_calls'] = calls.values()
        if reasoning: message['reasoning_content'] = ''.join(reasoning)
        return {'id': ident, 'object': 'chat.completion', 'created': created, 'model': body.model,
                'choices': [{'index': 0, 'message': message, 'finish_reason': finish}], 'usage': usage}

    return APIResponse(source, collect=collect_response)
