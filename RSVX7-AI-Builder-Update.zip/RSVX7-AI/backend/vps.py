"""Owner-only VPS provisioning. SSH credentials are encrypted and never returned."""
import asyncio
import base64
import hashlib
import hmac
import io
import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import socket
import tarfile
import uuid
from datetime import datetime, timezone
from urllib.parse import urlsplit

import asyncssh
from cryptography.fernet import Fernet, InvalidToken
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
from pymongo.errors import DuplicateKeyError
from auth import db, JWT_SECRET, require_super_admin

router = APIRouter(prefix='/api/admin/vps', tags=['VPS'])
ROOT = Path(__file__).resolve().parents[1]
TASKS = {}
DEFAULT = {'revision':0,'host':'','port':22,'username':'root','authMethod':'password','fingerprint':'',
           'installPath':'/opt/rsvx7','siteUrl':'','provider':'openrouter','model':'nousresearch/hermes-3-llama-3.1-405b'}
SECRET_FIELDS = ('password','privateKey','passphrase','providerKey')

def now(): return datetime.now(timezone.utc).isoformat()
def cipher(): return Fernet(base64.urlsafe_b64encode(hmac.new(JWT_SECRET.encode(), b'rsvx7-vps-secrets-v1', hashlib.sha256).digest()))
def encrypt(value): return cipher().encrypt(json.dumps(value).encode()).decode()
def decrypt(record):
    try: return json.loads(cipher().decrypt(record.get('secrets','').encode())) if record.get('secrets') else {}
    except (InvalidToken, ValueError): raise HTTPException(409,'تغيّر مفتاح التشفير. أعد إدخال بيانات الخادم.')
async def record(): return await db.settings.find_one({'_id':'vps'}) or {'_id':'vps',**DEFAULT}
def safe(value):
    result = {k:value.get(k,v) for k,v in DEFAULT.items()}
    result.update(credentialsConfigured=bool(value.get('secrets')), tested=value.get('tested'), job=value.get('job'), health=value.get('health'))
    return result

def canonical_site(value):
    try:
        parts=urlsplit(value)
        host=parts.hostname or ''
        if parts.scheme not in ('https','http') or parts.username or parts.password or parts.path not in ('','/') or parts.query or parts.fragment: raise ValueError()
        if parts.port not in (None,80 if parts.scheme=='http' else 443): raise ValueError()
        if not re.fullmatch(r'[a-zA-Z0-9.-]{1,253}',host): raise ValueError()
        if parts.scheme=='https':
            try: ipaddress.ip_address(host)
            except ValueError: pass
            else: raise ValueError()
            if '.' not in host: raise ValueError()
        return parts.scheme+'://'+host.lower()
    except ValueError: raise ValueError('استخدم https://domain.com أو http://SERVER_IP بلا مسارات أو منافذ إضافية.')

class HostBody(BaseModel):
    host: str = Field(min_length=1,max_length=253,pattern=r'^[a-zA-Z0-9.:_-]+$')
    port: int = Field(default=22,ge=1,le=65535)
class ConfigBody(HostBody):
    revision: int = Field(ge=0)
    username: str = Field(min_length=1,max_length=64,pattern=r'^[a-zA-Z_][a-zA-Z0-9_-]*[$]?$')
    authMethod: str = Field(pattern=r'^(password|key)$')
    fingerprint: str = Field(pattern=r'^SHA256:[a-zA-Z0-9+/]{43}$')
    installPath: str = Field(default='/opt/rsvx7',pattern=r'^/(?:opt|srv|root|home/[a-zA-Z0-9_.-]+)/rsvx7(?:-[a-zA-Z0-9_-]{1,40})?$')
    siteUrl: str = Field(min_length=8,max_length=300)
    provider: str = Field(default='openrouter',pattern=r'^(openrouter|local)$')
    model: str = Field(min_length=1,max_length=200,pattern=r'^[a-zA-Z0-9][a-zA-Z0-9_.:/-]*$')
    password: str = Field(default='',max_length=500)
    privateKey: str = Field(default='',max_length=16000)
    passphrase: str = Field(default='',max_length=500)
    providerKey: str = Field(default='',max_length=500)
    @field_validator('siteUrl')
    @classmethod
    def site(cls,value): return canonical_site(value)

async def address(host,port):
    # Connect to the exact checked IP, preventing DNS rebinding between validation and SSH.
    try: answers=await asyncio.get_running_loop().getaddrinfo(host,port,type=socket.SOCK_STREAM)
    except OSError: raise HTTPException(400,'تعذّر تحديد عنوان الخادم.')
    allowed=[ipaddress.ip_network(c.strip()) for c in os.environ.get('RSVX7_VPS_ALLOWED_CIDRS','').split(',') if c.strip()]
    for entry in answers:
        ip=ipaddress.ip_address(entry[4][0])
        if not ip.is_global and not any(ip in network for network in allowed): raise HTTPException(400,'يلزم عنوان VPS عام. الشبكات الخاصة تحتاج إعداد سماح خادميًا صريحًا.')
    if not answers: raise HTTPException(400,'عنوان الخادم غير صالح.')
    return answers[0][4][0]

class PinnedClient(asyncssh.SSHClient):
    def __init__(self,fingerprint): self.fingerprint=fingerprint
    def validate_host_public_key(self,host,addr,port,key): return hmac.compare_digest(key.get_fingerprint('sha256'),self.fingerprint)

async def connect(config):
    secrets=decrypt(config)
    kwargs={'host':await address(config['host'],config['port']),'port':config['port'],'username':config['username'],
            'known_hosts':([],[],[]),'client_factory':lambda:PinnedClient(config['fingerprint']),
            'config':[],'agent_path':None,'connect_timeout':12,'login_timeout':12,'keepalive_interval':20}
    if config['authMethod']=='key':
        try: kwargs['client_keys']=[asyncssh.import_private_key(secrets.get('privateKey',''),secrets.get('passphrase') or None)]
        except (ValueError,asyncssh.KeyImportError): raise HTTPException(400,'تعذّر قراءة مفتاح SSH أو عبارة مروره.')
    else: kwargs.update(password=secrets.get('password',''),client_keys=[])
    return await asyncssh.connect(**kwargs)

@router.get('')
async def get_config(_=Depends(require_super_admin)):
    config=await record();job=config.get('job') or {}
    if job.get('status')=='running' and job.get('id') not in TASKS:
        await db.settings.update_one({'_id':'vps','job.id':job['id'],'job.status':'running'}, {'$set':{'job.status':'failed','job.message':'أعيد تشغيل خادم الإدارة. افحص حالة VPS قبل إعادة النشر.'}})
        config=await record()
    return safe(config)

@router.post('/host-key')
async def host_key(body:HostBody,_=Depends(require_super_admin)):
    try:
        key=await asyncio.wait_for(asyncssh.get_server_host_key(await address(body.host,body.port),body.port,config=[]),12)
        if key is None: raise RuntimeError()
        return {'fingerprint':key.get_fingerprint('sha256'),'algorithm':key.get_algorithm()}
    except HTTPException: raise
    except Exception: raise HTTPException(502,'تعذّر قراءة بصمة SSH. تحقق من العنوان والمنفذ والجدار الناري.')

@router.put('')
async def save_config(body:ConfigBody,_=Depends(require_super_admin)):
    old=await record()
    if (old.get('job') or {}).get('status')=='running': raise HTTPException(409,'انتظر اكتمال النشر الحالي.')
    if old['revision']!=body.revision: raise HTTPException(409,'تغيّرت إعدادات الخادم. أعد تحميلها.')
    changed_target=any(getattr(body,k)!=old.get(k) for k in ('host','port','username','authMethod','fingerprint'))
    try: secrets={} if changed_target else decrypt(old)
    except HTTPException:
        if getattr(body,'password' if body.authMethod=='password' else 'privateKey'): secrets={}
        else: raise
    for name in SECRET_FIELDS:
        value=getattr(body,name)
        if value: secrets[name]=value
    if not secrets.get('password' if body.authMethod=='password' else 'privateKey'): raise HTTPException(400,'أدخل كلمة مرور SSH أو المفتاح الخاص.')
    if body.provider=='openrouter' and not secrets.get('providerKey'):
        from ai_settings import configured_key, AI_PROVIDER
        if AI_PROVIDER=='openrouter':
            inherited_key=configured_key(await db.settings.find_one({'_id':'ai'}) or {})
            if inherited_key: secrets['providerKey']=inherited_key
    values=body.model_dump(exclude=set(SECRET_FIELDS)|{'revision'})
    values.update(revision=body.revision+1,secrets=encrypt(secrets),tested=None,health=None,updatedAt=now())
    if changed_target or body.installPath != old.get('installPath') or body.siteUrl != old.get('siteUrl'):
        values['job'] = None
    query={'_id':'vps','revision':body.revision} if 'secrets' in old else {'_id':'vps','revision':{'$exists':False}}
    query['job.status']={'$ne':'running'}
    # In SQL and Mongo the _id uniqueness makes concurrent first saves conflict.
    try: result=await db.settings.update_one(query,{'$set':values},upsert='secrets' not in old)
    except DuplicateKeyError: raise HTTPException(409,'تغيّرت إعدادات الخادم. أعد تحميلها.')
    if 'secrets' in old and not result.modified_count: raise HTTPException(409,'تغيّرت إعدادات الخادم.')
    return safe(await record())

PROBE="""import json,os,platform,shutil,subprocess
r={'system':platform.system(),'machine':platform.machine(),'python':True,'docker':bool(shutil.which('docker'))}
try:
 p=subprocess.run(['docker','info','--format','{{json .ServerVersion}}'],capture_output=True,text=True,timeout=15);r['dockerReady']=p.returncode==0
 p=subprocess.run(['docker','compose','version','--short'],capture_output=True,text=True,timeout=15);r['composeReady']=p.returncode==0
except Exception:r['dockerReady']=False;r['composeReady']=False
try:r['memoryMB']=int(os.sysconf('SC_PHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')/1024/1024)
except Exception:r['memoryMB']=None
print(json.dumps(r))"""
@router.post('/test')
async def test_connection(_=Depends(require_super_admin)):
    config=await record()
    if not config.get('secrets'): raise HTTPException(400,'احفظ بيانات الخادم أولًا.')
    try:
        async with await connect(config) as ssh:
            output=await ssh.run('python3 -c '+shlex.quote(PROBE),timeout=25,check=True)
        result=json.loads(output.stdout)
        ready=result.get('system')=='Linux' and result.get('dockerReady') and result.get('composeReady')
        checked={'at':now(),'revision':config['revision'],'ready':bool(ready),'system':str(result.get('system',''))[:30],
                 'memoryMB':result.get('memoryMB'),'dockerReady':bool(result.get('dockerReady')),'composeReady':bool(result.get('composeReady'))}
        saved=await db.settings.update_one({'_id':'vps','revision':config['revision']},{'$set':{'tested':checked}})
        if not saved.modified_count: raise HTTPException(409,'تغيّرت الإعدادات أثناء الفحص.')
        return checked
    except HTTPException: raise
    except asyncssh.HostKeyNotVerifiable: raise HTTPException(409,'بصمة الخادم لا تطابق المحفوظة. تحقق منها قبل إرسال بيانات الدخول.')
    except asyncssh.PermissionDenied: raise HTTPException(401,'رفض الخادم بيانات SSH. تحقق من المستخدم وكلمة المرور أو المفتاح.')
    except Exception: raise HTTPException(502,'تعذّر فحص الخادم. يلزم Linux وPython 3 وDocker Compose وصلاحية تشغيل Docker.')

def source_archive():
    paths=['backend','scripts','remote-agent','builder/dist','frontend/build','deploy','Dockerfile.selfhost','Dockerfile.selfhost.dockerignore']
    for required in ('frontend/build/index.html','builder/dist/service.mjs','deploy/compose.selfhost.yaml',
                     'Dockerfile.selfhost','Dockerfile.selfhost.dockerignore','scripts/init_selfhost.py',
                     'scripts/check_selfhost.py','scripts/verify_gateway.py','deploy/install-selfhost.sh'):
        if not (ROOT/required).is_file(): raise RuntimeError('حزمة التشغيل غير مكتملة. أعد بناء التطبيق.')
    output=io.BytesIO()
    with tarfile.open(fileobj=output,mode='w:gz') as archive:
        for root in paths:
            base=ROOT/root
            for path in sorted(base.rglob('*')) if base.is_dir() else [base]:
                if not path.is_file() or path.is_symlink() or {'__pycache__','node_modules','private','.git'}.intersection(path.relative_to(ROOT).parts): continue
                if path.name.startswith('.env') or path.suffix in ('.log','.pyc','.zip'): continue
                archive.add(path,arcname=path.relative_to(ROOT).as_posix(),recursive=False)
    return output.getvalue()

async def job_update(jid,**fields):
    await db.settings.update_one({'_id':'vps','job.id':jid,'job.status':'running'},{'$set':{'job.'+key:value for key,value in fields.items()}})

@router.post('/deploy',status_code=202)
async def deploy(_=Depends(require_super_admin)):
    config=await record();tested=config.get('tested') or {}
    if not tested.get('ready') or tested.get('revision')!=config.get('revision'): raise HTTPException(409,'احفظ إعداداتك واختبر الاتصال بنجاح أولًا.')
    if config['provider']=='openrouter' and not decrypt(config).get('providerKey'): raise HTTPException(400,'أدخل مفتاح النموذج في إعدادات الخادم أو اختر نموذجًا محليًا.')
    jid=uuid.uuid4().hex;job={'id':jid,'releaseId':jid,'status':'running','stage':'preparing','message':'تجهيز حزمة المنصة','startedAt':now()}
    saved=await db.settings.update_one({'_id':'vps','revision':config['revision'],'job.status':{'$ne':'running'}},{'$set':{'job':job,'health':None}})
    if not saved.modified_count: raise HTTPException(409,'يوجد نشر جارٍ أو تغيّرت الإعدادات.')
    task=asyncio.create_task(deploy_job(config,jid));TASKS[jid]=task;task.add_done_callback(lambda _:TASKS.pop(jid,None))
    return {'job':job}

async def deploy_job(config,jid):
    path=config['installPath'];release=path+'/releases/'+jid
    try:
        data=await asyncio.to_thread(source_archive)
        await job_update(jid,stage='connecting',message='الاتصال بالخادم')
        async with await connect(config) as ssh:
            async with ssh.start_sftp_client() as sftp:
                await sftp.makedirs(release,exist_ok=True);await sftp.chmod(path,0o700)
                async with sftp.open(release+'/source.tar.gz','wb') as output: await output.write(data)
            await job_update(jid,stage='uploading',message='رفع ملفات المنصة')
            await ssh.run('tar -xzf '+shlex.quote(release+'/source.tar.gz')+' -C '+shlex.quote(release),check=True,timeout=90)
            secrets=decrypt(config)
            payload={'siteUrl':config['siteUrl'],'provider':config['provider'],'model':config['model'],'providerKey':secrets.get('providerKey','')}
            init='python3 '+shlex.quote(release+'/scripts/init_selfhost.py')+' --env-file '+shlex.quote(path+'/.env.selfhost')+' --settings-stdin'
            await ssh.run(init,input=json.dumps(payload),check=True,timeout=20)
            command='sh '+shlex.quote(release+'/deploy/install-selfhost.sh')+' '+shlex.quote(path+'/.env.selfhost')
            await job_update(jid,stage='installing',message='بناء التطبيق وتشغيل الخدمات')
            with __import__('anyio').fail_after(2400):
                async with ssh.create_process(command,stderr=asyncssh.STDOUT) as process:
                    async for line in process.stdout:
                        # Only fixed stage markers reach the UI; terminal output and secrets never do.
                        if line.strip().startswith('RSVX7_STAGE:'):
                            stage=line.strip().split(':',1)[1]
                            labels={'configuration':'فحص إعدادات الدومين','building':'بناء التطبيق','starting':'تشغيل الخدمات','model':'تجهيز النموذج المحلي','checking':'فحص التطبيق','gateway':'فحص البوابة وشهادة الدومين','ready':'الخدمات جاهزة؛ جارٍ فحص الرابط'}
                            if stage in labels: await job_update(jid,stage=stage,message=labels[stage])
                    await process.wait_closed()
                    if process.exit_status!=0: raise RuntimeError('لم يكتمل تثبيت المنصة. افحص Docker ومساحة الخادم وإعدادات العنوان.')
            # The installer checks the app and gateway; also verify the requested site.
            await job_update(jid,stage='checking',message='التحقق من الرابط العام وHTTPS')
            public_probe='''import urllib.request,json,time
url='''+repr(config['siteUrl'])+'''
expected='''+repr(jid)+'''
for attempt in range(6):
 try:
  with urllib.request.urlopen(url+'/readyz',timeout=8) as response:
   body=json.load(response);assert body['status']=='ready' and body.get('release')==expected
  with urllib.request.urlopen(url+'/',timeout=8) as response:
   assert response.status==200 and 'text/html' in response.headers.get('Content-Type','')
  break
 except Exception:
  if attempt==5:raise
  time.sleep(3)
'''
            try: await ssh.run('python3 -c '+shlex.quote(public_probe),check=True,timeout=120)
            except Exception: raise RuntimeError('الخدمات بدأت، لكن الرابط العام لا يستجيب. تحقق من DNS ومنافذ 80 و443 وشهادة HTTPS ثم أعد الفحص.')
            await ssh.run('ln -sfn '+shlex.quote(release)+' '+shlex.quote(path+'/current'),check=True,timeout=10)
        await job_update(jid,status='completed',stage='ready',message='تم تشغيل المنصة على الخادم',url=config['siteUrl'],finishedAt=now())
    except Exception as error:
        message=str(error) if isinstance(error,RuntimeError) else 'تعذّر النشر. تحقق من اتصال SSH وصلاحيات Docker وإعدادات الخادم.'
        await job_update(jid,status='failed',stage='failed',message=message,finishedAt=now())

@router.post('/health',status_code=202)
async def check_deployment(_=Depends(require_super_admin)):
    config=await record();job=config.get('job') or {}
    if job.get('status')=='running': raise HTTPException(409,'انتظر اكتمال العملية الحالية.')
    release_id=job.get('releaseId') or job.get('id') or ''
    if not re.fullmatch(r'[a-f0-9]{32}',release_id): raise HTTPException(409,'ابدأ نشر المنصة أولًا.')
    jid=uuid.uuid4().hex
    next_job={'id':jid,'releaseId':release_id,'mode':'health','status':'running','stage':'checking','message':'فحص الخدمات والرابط','startedAt':now()}
    saved=await db.settings.update_one({'_id':'vps','revision':config['revision'],'job.id':job['id'],'job.status':{'$ne':'running'}},{'$set':{'job':next_job,'health':None}})
    if not saved.modified_count: raise HTTPException(409,'بدأت عملية أخرى أو تغيّرت الإعدادات.')
    task=asyncio.create_task(health_job(config,jid,release_id));TASKS[jid]=task;task.add_done_callback(lambda _:TASKS.pop(jid,None))
    return {'job':next_job}


async def health_job(config,jid,release_id):
    try:
        script=(ROOT/'scripts/check_selfhost.py').read_text()
        payload={'envFile':config['installPath']+'/.env.selfhost','release':config['installPath']+'/releases/'+release_id,'siteUrl':config['siteUrl'],'expectedRelease':release_id}
        async with await connect(config) as ssh:
            response=await ssh.run('python3 -c '+shlex.quote(script),input=json.dumps(payload),timeout=65,check=True)
            report=json.loads(response.stdout)
            # Never trust terminal output as an application message.
            from importlib.util import module_from_spec, spec_from_file_location
            spec=spec_from_file_location('selfhost_diagnostics',ROOT/'scripts/check_selfhost.py')
            module=module_from_spec(spec);spec.loader.exec_module(module)
            checks=report.get('checks')
            if not isinstance(checks,list) or len(checks)!=len(module.CHECK_CODES): raise ValueError()
            clean=[]
            for name,allowed in module.CHECK_CODES.items():
                check=next(c for c in checks if c.get('id')==name)
                if check.get('code') not in allowed: raise ValueError()
                clean.append({'id':name,'status':'passed' if check['code'] in ('ready','configured') else 'failed','code':check['code']})
            ready=all(c['status']=='passed' for c in clean if c['id']!='model')
            health={'at':now(),'revision':config['revision'],'ready':ready,'checks':clean}
            if ready:
                # A DNS/certificate fix can recover this release without rebuilding it.
                await ssh.run('ln -sfn '+shlex.quote(payload['release'])+' '+shlex.quote(config['installPath']+'/current'),check=True,timeout=10)
            await db.settings.update_one({'_id':'vps','revision':config['revision'],'job.id':jid,'job.status':'running'},
                {'$set':{'health':health,'job.status':'completed' if ready else 'failed','job.stage':'ready' if ready else 'checking',
                         'job.message':'تم التحقق من تشغيل المنصة' if ready else 'لم تكتمل الجاهزية. راجع نتائج الفحص أدناه.',
                         'job.url':config['siteUrl'] if ready else None,'job.finishedAt':now()}})
    except Exception:
        await job_update(jid,status='failed',stage='checking',message='تعذّر فحص النشر. تحقق من SSH وDocker ثم أعد الفحص.',finishedAt=now())

@router.post('/bootstrap-credentials')
async def bootstrap_credentials(_=Depends(require_super_admin)):
    config=await record()
    if (config.get('job') or {}).get('status')!='completed': raise HTTPException(409,'أكمل نشر المنصة أولًا.')
    # Explicit owner action only. Read the initial pair, never the other server secrets.
    script="import json,pathlib;v=dict(line.split('=',1) for line in pathlib.Path("+repr(config['installPath']+'/.env.selfhost')+").read_text().splitlines() if '=' in line);print(json.dumps({k:v.get(k,'') for k in ['OWNER_USERNAME','OWNER_INITIAL_PASSWORD']}))"
    try:
        async with await connect(config) as ssh: response=await ssh.run('python3 -c '+shlex.quote(script),check=True,timeout=15)
        from fastapi.responses import JSONResponse
        return JSONResponse(json.loads(response.stdout),headers={'Cache-Control':'no-store'})
    except Exception: raise HTTPException(502,'تعذّر جلب بيانات التهيئة من الخادم.')
