"""Explicit wire contracts for models supporting OpenRouter structured outputs.
JSON mode alone guarantees syntax, not the action or independent-review fields.
Continuation replies are suffixes and deliberately never use a JSON schema.
"""
def object_schema(properties, required=None):
    return {'type':'object','properties':properties,'required':required or list(properties),'additionalProperties':False}

def response_format(role, criteria=()):
    string={'type':'string'}
    if role == 'file_planner':
        schema=object_schema({'files':{'type':'array','items':string,'minItems':1,'maxItems':1500}})
    elif role in ('coder', 'builder', 'file_reviewer'):
        action=object_schema({'type':{'type':'string','enum':['file']},'filePath':string,'content':string})
        schema=object_schema({'actions':{'type':'array','items':action,'minItems':0 if role == 'file_reviewer' else 1,'maxItems':2},'remainingFiles':{'type':'array','items':string}})
    elif role=='reviewer':
        requirement={'type':'string', **({'enum':list(dict.fromkeys(criteria))} if criteria else {})}
        issue=object_schema({'severity':{'type':'string','enum':['critical','major','minor']},'file':string,'problem':string,'fix':string})
        coverage=object_schema({'requirement':requirement,'files':{'type':'array','items':string},'status':{'type':'string','enum':['covered','missing']}})
        schema=object_schema({'verdict':{'type':'string','enum':['pass','revise']},'issues':{'type':'array','items':issue},'coverage':{'type':'array','items':coverage}})
    else:return None
    return {'type':'json_schema','json_schema':{'name':'builder_'+role,'strict':True,'schema':schema}}


def rejects_response_format(error):
    """Retry only an unsupported output parameter, never a refusal or quota error."""
    import re
    if getattr(error, 'status_code', None) not in (400, 422): return False
    message = (str(error) + ' ' + str(getattr(error, 'body', ''))).lower()
    if any(word in message for word in ('privacy', 'moderation', 'content policy', 'safety', 'guardrail')): return False
    return bool(re.search(r'response[_ ]format|json[_ ]schema|structured[_ ]outputs?', message) and
                re.search(r'unsupported|not support|unknown parameter|unrecognized|invalid schema|extra inputs are not permitted', message))
