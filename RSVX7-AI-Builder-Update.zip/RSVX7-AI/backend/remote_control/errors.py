"""Public errors never expose raw provider response bodies or credentials."""
import re
from openai import APIStatusError,APIConnectionError

def public_error(error):
    if isinstance(error,(APIStatusError,APIConnectionError)):
        from ai_settings import provider_error
        return provider_error(error)['message']
    value=getattr(error,'detail',str(error))
    if isinstance(value,dict):value=value.get('message','تعذر إكمال الطلب.')
    return re.sub(r'sk-or-v1-[A-Za-z0-9_-]+','[redacted]',str(value))[:2000]
