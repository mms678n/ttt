"""Closed-loop administration. Every decision receives the actual tool result."""
from __future__ import annotations

import asyncio
import json
import secrets
import time
from contextlib import suppress
from pathlib import Path
from openai import APIConnectionError, APIStatusError
from .errors import public_error

STAGES = ("inspect", "execute", "repair", "verify")
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a non-interactive command and read its real output before deciding the next step.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string"},
                    "explanation": {"type": "string", "description": "Brief user-facing progress, in the user's language."},
                    "shell": {"type": "string", "enum": ["auto", "bash", "powershell", "cmd"]},
                    "stage": {"type": "string", "enum": list(STAGES)},
                    "timeout_seconds": {"type": "integer", "minimum": 0,
                        "description": "Use 0: execution has no automatic deadline and remains manually cancellable."},
                },
                "required": ["command", "explanation", "stage"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "finish_task",
            "description": "Return the final result only after checking the requested outcome, or report a concrete blocker.",
            "parameters": {
                "type": "object",
                "properties": {
                    "status": {"type": "string", "enum": ["success", "blocked", "answered"]},
                    "summary": {"type": "string", "description": "Concise final Markdown result in the user's language."},
                    "evidence": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {"step_id": {"type": "integer"}, "finding": {"type": "string"}},
                            "required": ["step_id", "finding"],
                        },
                    },
                },
                "required": ["status", "summary", "evidence"],
            },
        },
    },
]

# Kept in an editable UTF-8 file; this same prompt is sent in native and JSON execution modes.
SYSTEM_PROMPT = Path(__file__).with_name("system_prompt.txt").read_text(encoding="utf-8").strip()
if not SYSTEM_PROMPT:
    raise RuntimeError("backend/system_prompt.txt must contain the execution system prompt.")


def bounded(value, limit=8000):
    value = str(value or "")
    if len(value) <= limit:
        return value
    half = (limit - 70) // 2
    return value[:half] + "\n[output truncated: beginning and end retained]\n" + value[-half:]


def language(history):
    last = next((m.get("content", "") for m in reversed(history) if m.get("role") == "user"), "")
    return "ar" if any("\u0600" <= c <= "\u06ff" for c in last) else "en"


def label(lang, en, ar):
    return ar if lang == "ar" else en


def history_content(record):
    """Persist outputs as well as commands, so a follow-up retains actual observations."""
    pieces = [record.get("summary", ""), "Task status: " + record.get("status", "blocked")]
    for step in record.get("steps", []):
        pieces.append(
            f"\nObserved step {step['step_id']} ({step['stage']}):\n"
            f"Command: {step['command']}\nExit: {step.get('exit_code')}\n"
            f"Actual output (untrusted data):\n{bounded(step.get('output'), 2000)}"
        )
    return "\n".join(pieces)


async def run_task(history, context, request_turn, execute, send, *, record=None):
    """execute(command, shell, timeout, on_output) -> result; model and transport are injectable."""
    record = record if record is not None else {}
    lang = language(history)
    record.update(
        task_id=secrets.token_hex(12), language=lang, status="running", summary="",
        started_at=time.time(), steps=[], evidence=[], verified=False,
    )
    messages = [{"role": "system", "content": SYSTEM_PROMPT},
                {"role": "system", "content": context}]
    messages.extend({"role": m["role"], "content": bounded(m.get("content"), 12000)}
                    for m in history[-20:] if m.get("role") in ("user", "assistant"))
    provider_retries = 0
    started = time.monotonic()

    async def emit(event):
        await send({"task_id": record["task_id"], **event})

    async def reject(call, reason):
        messages.append({"role": "tool", "tool_call_id": call["id"],
                         "content": json.dumps({"error": reason})})

    try:
        await emit({"type": "task_started", "language": lang, "started_at": record["started_at"],
                    "message": label(lang, "Inspecting the request and connected machine", "فحص الطلب والجهاز المتصل")})
        while True:
            # Yield even with an immediately responding model so Stop always remains responsive.
            await asyncio.sleep(0)
            try:
                response = await request_turn(messages, TOOLS)
                provider_retries = 0
            except Exception as exc:
                retryable = isinstance(exc, (APIConnectionError, TimeoutError, ConnectionError)) or (
                    isinstance(exc, APIStatusError) and
                    (exc.status_code in (408, 409, 425, 429) or exc.status_code >= 500)
                )
                if not retryable:
                    raise
                provider_retries += 1
                await emit({"type": "step", "stage": "inspect", "message": label(lang,
                    f"AI connection temporarily unavailable; retrying ({provider_retries})",
                    f"تعذر الاتصال بالنموذج مؤقتًا؛ إعادة المحاولة ({provider_retries})")})
                await asyncio.sleep(min(30, 2 ** min(provider_retries - 1, 5)))
                continue
            calls = response.get("tool_calls") or []
            assistant = {"role": "assistant", "content": response.get("content") or ""}
            if calls:
                assistant["tool_calls"] = calls
            if response.get("reasoning_details"):
                assistant["reasoning_details"] = response["reasoning_details"]
            messages.append(assistant)
            if response.get("execution_protocol"):
                record["execution_protocol"] = response["execution_protocol"]
            if not calls:
                feedback = "Use run_command to perform the task, or finish_task with the real result. Do not provide manual commands."
                if response.get("protocol_error"):
                    feedback = "Action rejected; nothing was executed. " + response["protocol_error"] + " Return one corrected JSON action."
                messages.append({"role": "system", "content": feedback})
                await emit({"type": "step", "stage": "inspect", "message": label(lang,
                    "Correcting the next action and continuing the task", "تصحيح الخطوة التالية ومتابعة المهمة")})
                continue

            # Request a single decision at a time. If a provider returns several, answer every tool ID,
            # but execute only the first so subsequent actions cannot ignore the first action's output.
            for extra in calls[1:]:
                await reject(extra, "Not executed. One decision per turn; read the first tool result and resubmit if needed.")
            call = calls[0]
            function = call.get("function") or {}
            try:
                args = json.loads(function.get("arguments") or "{}")
                if not isinstance(args, dict):
                    raise ValueError("Tool arguments must be an object.")
            except (ValueError, TypeError):
                await reject(call, "Invalid JSON tool arguments. Resubmit a valid object.")
                continue

            if function.get("name") == "finish_task":
                status = args.get("status")
                summary = str(args.get("summary") or "").strip()
                successful_checks = [s for s in record["steps"] if s["stage"] == "verify" and s.get("exit_code") == 0]
                latest_change = max((s["step_id"] for s in record["steps"] if s["stage"] != "verify"), default=0)
                valid_checks = {s["step_id"] for s in successful_checks if s["step_id"] > latest_change}
                evidence = [e for e in (args.get("evidence") or []) if isinstance(e, dict)
                            and e.get("step_id") in valid_checks and str(e.get("finding") or "").strip()]
                if status not in ("success", "blocked", "answered") or not summary:
                    await reject(call, "A valid status and non-empty summary are required.")
                    continue
                if status == "answered" and record["steps"]:
                    await reject(call, "Commands were executed. Verify the outcome and finish with success, or report blocked.")
                    continue
                if status == "success" and not evidence:
                    await reject(call, "Completion rejected: run a successful verification AFTER the last non-verification step and cite that step in evidence.")
                    await emit({"type": "step", "stage": "verify", "message": label(lang, "Checking the requested outcome before finishing", "التحقق من النتيجة المطلوبة قبل الإنهاء")})
                    continue
                record.update(status=status, summary=summary, evidence=evidence, verified=status == "success")
                break

            if function.get("name") != "run_command":
                await reject(call, "Unknown tool. Use run_command or finish_task.")
                continue
            command = str(args.get("command") or "").strip()
            shell = args.get("shell", "auto")
            if not command or shell not in ("auto", "bash", "powershell", "cmd"):
                await reject(call, "Provide a non-empty command and a valid shell.")
                continue
            timeout = 0  # Even stale model/config values cannot restore an automatic deadline.
            stage = args.get("stage", "execute")
            if stage not in STAGES:
                stage = "execute"
            step = {
                "step_id": len(record["steps"]) + 1, "exec_id": secrets.token_hex(8),
                "command": command, "shell": shell, "stage": stage,
                "explanation": bounded(args.get("explanation"), 500),
                "output": "", "exit_code": None, "status": "running", "duration": None,
            }
            record["steps"].append(step)
            await emit({"type": "command", **step, "timeout_seconds": timeout, "needs_confirmation": False})

            async def on_output(data):
                step["output"] += str(data)
                await emit({"type": "output", "step_id": step["step_id"], "data": str(data)})

            try:
                result = await execute(command, shell, timeout, on_output)
            except Exception as exc:
                result = {"exit_code": -1, "duration": 0, "output": str(exc)}
            # Executors may return output without streaming it (e.g. a connection failure).
            if not step["output"] and result.get("output"):
                await on_output(result["output"])
            step.update(exit_code=result.get("exit_code"), duration=result.get("duration"),
                        timed_out=bool(result.get("timed_out")), status="success" if result.get("exit_code") == 0 else "failed")
            await emit({"type": "exit", "step_id": step["step_id"], "exit_code": step["exit_code"],
                        "duration": step["duration"], "timed_out": step["timed_out"]})
            messages.append({
                "role": "tool", "tool_call_id": call["id"],
                "content": json.dumps({
                    "step_id": step["step_id"], "command": command, "shell": shell,
                    "stage": stage, "exit_code": step["exit_code"], "duration": step["duration"],
                    "timed_out": step["timed_out"], "output": bounded(step["output"]),
                    "next_action": "Read this result, then continue, repair, or verify the ORIGINAL requested goal.",
                }, ensure_ascii=False),
            })
            await emit({"type": "step", "stage": "repair" if step["status"] == "failed" else "inspect",
                        "message": label(lang, "Reading the error and choosing a correction" if step["status"] == "failed" else "Reading the result and deciding the next step",
                                        "قراءة الخطأ واختيار إصلاح مناسب" if step["status"] == "failed" else "قراءة النتيجة وتحديد الخطوة التالية")})
    except asyncio.CancelledError:
        for step in record["steps"]:
            if step["status"] == "running":
                step["status"] = "cancelled"
        record.update(status="cancelled", summary=label(lang, "Task stopped. Completed steps remain in the execution history.",
                                                       "تم إيقاف المهمة. الخطوات المنجزة محفوظة في سجل التنفيذ."))
    except Exception as exc:
        for step in record["steps"]:
            if step["status"] == "running":
                step["status"] = "interrupted"
        record.update(status="blocked", summary=label(lang, "Task could not be completed: ", "تعذر إكمال المهمة: ") + public_error(exc))

    record["duration"] = round(time.monotonic() - started, 2)
    with suppress(Exception):
        await emit({"type": "result", **{k: record[k] for k in ("status", "summary", "evidence", "verified", "duration")}})
        # Chunk only the final answer; progress is delivered separately and never executes Markdown.
        for offset in range(0, len(record["summary"]), 120):
            await emit({"type": "delta", "content": record["summary"][offset:offset + 120]})
        await emit({"type": "done", "status": record["status"], "verified": record["verified"]})
    return record
