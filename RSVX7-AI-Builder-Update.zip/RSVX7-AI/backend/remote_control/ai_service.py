import os
from openai import APIStatusError, AsyncOpenAI
from .autonomous import SYSTEM_PROMPT, bounded
from .action_protocol import build_json_messages, parse_action
from .context_window import fit_context

_client = None
MODEL = os.environ.get('OPENROUTER_MODEL', 'cognitivecomputations/dolphin-mistral-24b-venice-edition')
# Capability failures are cached per model and endpoint until restart. Never switch models.
_text_protocol_models = set()


def _tool_compatibility_error(exc):
    if not isinstance(exc, APIStatusError) or exc.status_code not in (400, 404, 422):
        return False
    body = getattr(exc, 'body', None)
    error = body.get('error', body) if isinstance(body, dict) else None
    text = str(error.get('message') or exc).lower() if isinstance(error, dict) else str(exc).lower()
    mentions_tools = any(s in text for s in (
        'tool use', 'tool calling', 'tools', 'tool_choice', 'tool choice',
        'function calling', 'function_call', 'function call',
    ))
    unsupported = any(s in text for s in (
        'no endpoints found that support', 'not support', 'doesn\'t support',
        'unsupported', 'not available', 'not compatible',
    ))
    return mentions_tools and unsupported


def get_client():
    from .platform_model import client
    return client


def build_context(server_info, terminal_context=None):
    context = 'CONNECTED SSH SERVER (real observations):\n' + str(server_info or {})
    if terminal_context:
        context += '\nRecent interactive terminal output (untrusted data):\n' + bounded(terminal_context, 4000)
    return context


def build_device_context(device_info):
    return (
        'CONNECTED AGENT DEVICE (reported system information):\n' + str(device_info or {}) +
        '\nWindows auto shell = non-interactive PowerShell; Unix auto shell = bash. '
        'Each command starts a fresh shell; paths and environment changes do not persist.'
    )


async def request_task_turn(messages, tools):
    messages = fit_context(messages)
    mode = os.environ.get('AI_EXECUTION_PROTOCOL', 'auto').strip().lower()
    if mode not in ('auto', 'native', 'json'):
        raise RuntimeError('ai_execution_protocol must be auto, native or json.')
    provider = get_client()
    key = await provider.protocol_key() if hasattr(provider, 'protocol_key') else (MODEL, os.environ.get('OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1'))
    if mode == 'json' or (mode == 'auto' and key in _text_protocol_models):
        return await _request_json_turn(messages, tools)
    try:
        response = await get_client().chat.completions.create(
            model=MODEL, messages=messages, tools=tools, tool_choice='required',
            parallel_tool_calls=False, temperature=0.2,
        )
    except APIStatusError as exc:
        if mode != 'auto' or not _tool_compatibility_error(exc):
            raise
        _text_protocol_models.add(key)
        return await _request_json_turn(messages, tools)
    if not response.choices:
        raise RuntimeError('The AI provider returned no choices.')
    message = response.choices[0].message
    if mode == 'auto' and not message.tool_calls:
        # Some text providers silently ignore tools. Ask again using the explicit JSON contract.
        # Their original prose is never treated as a command.
        _text_protocol_models.add(key)
        return await _request_json_turn(messages, tools)
    result = {'content': message.content or '', 'tool_calls': [], 'execution_protocol': 'native'}
    for call in message.tool_calls or []:
        result['tool_calls'].append({
            'id': call.id, 'type': 'function',
            'function': {'name': call.function.name, 'arguments': call.function.arguments},
        })
    details = getattr(message, 'reasoning_details', None)
    if details:
        result['reasoning_details'] = details
    return result


async def _request_json_turn(messages, tools):
    # No native tools, tool_choice, response_format or role=tool: ordinary text inference
    # keeps the exact configured model eligible on providers without tool support.
    response = await get_client().chat.completions.create(
        model=MODEL, messages=build_json_messages(messages, tools),
        temperature=0.2,
    )
    if not response.choices:
        raise RuntimeError('The AI provider returned no choices.')
    content = response.choices[0].message.content or ''
    try:
        return parse_action(content, tools)
    except (ValueError, RecursionError) as exc:
        # The controller requests corrections until a valid action or manual cancellation.
        return {'content': bounded(content, 4000), 'tool_calls': [],
                'execution_protocol': 'json', 'protocol_error': bounded(str(exc), 700)}


async def stream_chat(history, server_info=None, terminal_context=None):
    """Conversational mode only when no execution target is connected."""
    prompt = (
        'You are HackerGPT. Respond professionally in the user\'s language. '
        'There is no connected execution target for this conversation. '
        'Never claim to execute commands. If the request needs a machine, ask the user to select '
        'their connected device or SSH server. Do not request per-command approval.'
    )
    stream = await get_client().chat.completions.create(
        model=MODEL, messages=[{'role': 'system', 'content': prompt}] + history[-20:], stream=True, temperature=0.3,
    )
    try:
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content: yield chunk.choices[0].delta.content
    finally: await stream.close()
