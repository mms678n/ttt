"""Remote documents share platform persistence, with isolated collection names."""
import secrets
from bson import ObjectId
from persistence import get_database

def normalize(value):
    if isinstance(value, ObjectId): return str(value)
    if isinstance(value, dict): return {key: normalize(item) for key, item in value.items()}
    if isinstance(value, list): return [normalize(item) for item in value]
    if isinstance(value, tuple): return tuple(normalize(item) for item in value)
    return value

class Collection:
    def __init__(self, collection): self.collection = collection
    async def insert_one(self, document):
        document = normalize(document)
        document.setdefault('_id', secrets.token_hex(12))
        return await self.collection.insert_one(document)
    def __getattr__(self, method):
        target = getattr(self.collection, method)
        return lambda *args, **kwargs: target(*(normalize(arg) for arg in args), **normalize(kwargs))

class RemoteDatabase:
    def __getattr__(self, name):
        if name.startswith('_') or name == 'users': raise AttributeError('Remote accounts use platform authentication')
        return Collection(getattr(get_database(), 'remote_' + name))
    async def command(self, name): return await get_database().command(name)
