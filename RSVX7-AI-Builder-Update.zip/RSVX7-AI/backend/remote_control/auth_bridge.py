"""One identity/session system for HTTP, downloads and WebSocket execution."""
from contextvars import ContextVar
from types import SimpleNamespace
from urllib.parse import urlsplit
import os, hashlib
from fastapi import HTTPException, Request
from auth import current_user, hash_pw, verify_pw

actor = ContextVar('remote_actor', default=None)
def secret_digest(value): return hashlib.sha256(('rsvx7-device:' + value).encode()).hexdigest()
def hash_password(value): return hash_pw(secret_digest(value))
def verify_password(value, hashed): return verify_pw(secret_digest(value), hashed)

async def get_current_user(request: Request):
    # Downloads may open in a new tab; native same-origin HttpOnly cookie works.
    user = await current_user(request)
    from memberships import require_access
    require_access(user, feature="hacker")
    actor.set(user)
    return user

async def ws_identity(websocket, token):
    origin = websocket.headers.get('origin')
    allowed = {item.strip().rstrip('/') for item in os.environ.get('CORS_ORIGINS', '').split(',') if item.strip()}
    host = websocket.headers.get('host', '')
    if origin and origin.rstrip('/') not in allowed and urlsplit(origin).netloc != host:
        raise HTTPException(403, 'Cross-origin remote connection denied')
    headers = {'Authorization': 'Bearer ' + token} if token and token not in ('null','undefined') else {}
    request = SimpleNamespace(headers=headers, cookies=getattr(websocket,'cookies',{}), url=SimpleNamespace(path='/api/remote/ws'))
    user = await current_user(request)
    from memberships import require_access
    require_access(user, feature="hacker")
    actor.set(user)
    return {'sub': str(user['_id'])}
