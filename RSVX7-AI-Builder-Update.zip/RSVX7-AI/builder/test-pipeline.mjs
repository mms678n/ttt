import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {source} from './fixtures/agent-fixtures.mjs';
const require=createRequire(new URL('../frontend/package.json',import.meta.url));
const root=resolve(new URL('..',import.meta.url).pathname),folder=await mkdtemp(join(tmpdir(),'pipeline-'));
const names=Object.keys(source);
const envelope=(paths,changes={})=>JSON.stringify({actions:paths.map(filePath=>({type:'file',filePath,content:changes[filePath]??source[filePath]})),remainingFiles:[]});
let passed=0;
const test=async(name,fn)=>{await fn();passed++;console.log('PASS',name);};
try{
 await require('esbuild').build({stdin:{contents:"export {runProjectPipeline,pipelineSourceContext} from './builder/project-pipeline';",resolveDir:root},bundle:true,platform:'node',format:'esm',target:'es2022',outfile:join(folder,'pipeline.mjs'),alias:{'~':join(root,'builder/vendor/darkforge/app')},nodePaths:[join(root,'frontend/node_modules')],define:{'import.meta.env':'{}'}});
 const {runProjectPipeline,pipelineSourceContext}=await import(pathToFileURL(join(folder,'pipeline.mjs')));
 const run=async(custom,files={},extra={})=>{
  const calls=[],events=[],controller=new AbortController();
  const result=await runProjectPipeline({files,signal:controller.signal,...extra,progress:event=>events.push(structuredClone(event)),call:async call=>{
   calls.push(structuredClone(call));
   return await custom?.(call,calls,controller)||{text:call.stage==='structure'?JSON.stringify({files:names}):call.stage==='reviewing'?JSON.stringify({actions:[],remainingFiles:[]}):envelope(call.required),finishReason:'stop'};
  }});return{result,calls,events};
 };
 await test('creates empty tree, fills every file and reviews exact final source',async()=>{
  const {result,calls,events}=await run();
  const tree=events.find(e=>e.stage==='structure'&&e.files);
  assert.deepEqual(Object.keys(tree.files).sort(),names.map(n=>'/home/project/'+n).sort());
  assert.ok(Object.values(tree.files).every(f=>f.content===''));
  assert.equal(tree.completed,tree.total,'The tree counts created paths, separately from filled source');
  const stages=calls.map(c=>c.stage);assert.ok(stages.lastIndexOf('writing')<stages.indexOf('reviewing'));
  assert.deepEqual([...new Set(calls.filter(c=>c.stage==='reviewing').flatMap(c=>c.required))].sort(),[...names].sort());
  for(const name of names)assert.equal(result.files['/home/project/'+name].content,source[name]);
  assert.equal(events.at(-1).stage,'reviewing');assert.equal(events.at(-1).completed,events.at(-1).total);
  assert.equal(JSON.stringify(events.at(-1).files),JSON.stringify(result.files));
 });
 await test('actual review fix receives another actual review',async()=>{
  let fixed=false,reviewed=false;
  const {result}=await run(call=>{
   if(call.stage==='reviewing'&&call.required.includes('client.js')){
    if(!fixed){fixed=true;return{text:envelope(['client.js'],{'client.js':source['client.js']+'\n// fix'}),finishReason:'stop'};}
    reviewed=true;
   }
  });assert.ok(fixed&&reviewed);assert.match(result.files['/home/project/client.js'].content,/\/\/ fix/);
 });
 await test('identical review source cannot trigger a repair loop',async()=>{
  const {calls}=await run(call=>call.stage==='reviewing'?{text:envelope(call.required),finishReason:'stop'}:undefined);
  assert.equal(calls.filter(c=>c.stage==='reviewing').length,Math.ceil(names.length/2));
 });
 await test('unbounded review edits fail without altering committed source',async()=>{
  const old={'/home/project/keep.txt':{type:'file',content:'saved',isBinary:false}};let rev=0;
  await assert.rejects(run(call=>call.stage==='reviewing'?{text:envelope(['client.js'],{'client.js':source['client.js']+'\n//'+(++rev)}),finishReason:'stop'}:undefined,old),/file_format/);
  assert.equal(old['/home/project/keep.txt'].content,'saved');
 });
 for(const path of ['../private','.darkforge/tools.js','dist/index.html','/etc/private'])await test('unsafe manifest '+path,async()=>{
  await assert.rejects(run(call=>call.stage==='structure'?{text:JSON.stringify({files:[path]}),finishReason:'stop'}:undefined),/file_format/);
 });
 await test('new planned empty files cannot be marked written',async()=>{
  await assert.rejects(run(call=>call.stage==='writing'?{text:JSON.stringify({actions:[{type:'file',filePath:call.required[0],content:''}],remainingFiles:[]}),finishReason:'stop'}:undefined),/file_format/);
 });
 await test('existing intentionally empty source is preserved and reviewed',async()=>{
  const {result,calls}=await run(undefined,{'/home/project/empty.css':{type:'file',content:'',isBinary:false}});
  assert.equal(result.files['/home/project/empty.css'].content,'');assert.ok(calls.some(c=>c.stage==='reviewing'&&c.required.includes('empty.css')));
 });
 for(const stage of ['writing','reviewing'])for(const path of ['.env','.npmrc'])await test(stage+' rejects private source '+path,async()=>{
  await assert.rejects(run(call=>call.stage===stage?{text:JSON.stringify({actions:[...(stage==='writing'?[{type:'file',filePath:call.required[0],content:source[call.required[0]]}]:[]),{type:'file',filePath:path,content:'private configuration'}],remainingFiles:[]}),finishReason:'stop'}:undefined),/file_format/);
 });
 await test('private remaining files cannot bypass review',async()=>{
  await assert.rejects(run(call=>call.stage==='reviewing'?{text:JSON.stringify({actions:[],remainingFiles:['.npmrc']}),finishReason:'stop'}:undefined),/file_format/);
 });
 await test('malformed review cannot release source',async()=>{
  await assert.rejects(run(call=>call.stage==='reviewing'?{text:'looks good',finishReason:'stop'}:undefined),/file_format/);
 });
 await test('provider failures are not retried as formatting failures',async()=>{
  let calls=0;await assert.rejects(run(call=>{if(call.stage==='reviewing'){calls++;throw Error('provider unavailable');}}),/provider unavailable/);assert.equal(calls,1);
 });
 await test('cancelling review prevents final release',async()=>{
  await assert.rejects(run((call,calls,controller)=>{if(call.stage==='reviewing')controller.abort();}),{name:'AbortError'});
 });
 await test('binary and locked source survive generation and review',async()=>{
  const {result}=await run(undefined,{'/home/project/private.txt':{type:'file',content:'locked',isBinary:false},'/home/project/logo.png':{type:'file',content:'AA==',isBinary:true}},{lockedPaths:['private.txt']});
  assert.equal(result.files['/home/project/private.txt'].content,'locked');assert.equal(result.files['/home/project/logo.png'].content,'AA==');
 });
 await test('affected source has priority and cannot silently fall outside context',()=>{
  const files={};for(let i=0;i<30;i++)files['/home/project/a'+i+'.js']={type:'file',content:'x'.repeat(800),isBinary:false};
  files['/home/project/z.js']={type:'file',content:'important affected source',isBinary:false};
  assert.match(pipelineSourceContext(files,3000,['z.js']),/important affected source/);
  assert.throws(()=>pipelineSourceContext(files,10,['z.js']),/context/);
 });
 console.log('Ordered pipeline checks passed: '+passed);
}finally{await rm(folder,{recursive:true,force:true});}
