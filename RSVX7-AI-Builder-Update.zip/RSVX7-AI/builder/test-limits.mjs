import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createRequire} from 'node:module';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=resolve(new URL('..',import.meta.url).pathname),require=createRequire(new URL('../frontend/package.json',import.meta.url));
const dir=await mkdtemp(join(tmpdir(),'builder-limits-'));
const secret='limits-fixture-private-engine-key-not-a-credential';
const proposal={kind:'proposal',title:'Notes',summary:'Save notes locally',pages:[{name:'Home',purpose:'Manage notes'}],features:['Persist notes'],design:'Arabic RTL',steps:['Implement']};
let scenario='',calls=[],failures=0,checks=0,first=true;
const large='export const content = '+JSON.stringify('long text '.repeat(560))+';';
const files=Object.fromEntries(['a.js','b.js'].map(name=>['/home/project/'+name,{type:'file',content:large,isBinary:false}]));
const envelope=paths=>JSON.stringify({actions:paths.map(filePath=>({type:'file',filePath,content:scenario==='continuation'?large:'export const fixed = true;'})),remainingFiles:[]});
const mock=createServer(async(req,res)=>{
 let raw='';for await(const chunk of req)raw+=chunk;
 const body=JSON.parse(raw);calls.push(body);
 const system=body.messages[0].content;
 const batch=system.includes('CURRENT BATCH (data):\n')?JSON.parse(system.split('CURRENT BATCH (data):\n')[1].split('\nPROJECT CONTEXT')[0]):{};
 let text,finishReason='stop';
 if(body.role==='planner') {text=JSON.stringify(proposal);if(scenario==='planning_correction'&&first){first=false;text='bad'+'.'.repeat(3000);}}
 else if(body.role==='file_planner')text=JSON.stringify({files:scenario==='review'?['fix.js']:['a.js','b.js']});
 else if(body.role==='file_reviewer')text=JSON.stringify({actions:[],remainingFiles:[]});
 else {
  text=envelope(batch.requiredFiles);
  if(scenario==='continuation'&&first){first=false;text=text.slice(0,10500);finishReason='length';}
 }
 res.writeHead(200,{'content-type':'application/x-ndjson'});
 res.end(JSON.stringify({type:'delta',text})+'\n'+JSON.stringify({type:'result',finishReason})+'\n');
});
mock.listen(0,'127.0.0.1');await once(mock,'listening');
const reservation=createServer();reservation.listen(0,'127.0.0.1');await once(reservation,'listening');
const port=reservation.address().port;await new Promise(resolve=>reservation.close(resolve));
let engine;
const test=async(name,fn)=>{try{await fn();checks++;console.log('PASS',name)}catch(error){failures++;console.error('FAIL',name,error.message)}};
try{
 await require('esbuild').build({entryPoints:[join(root,'builder/service.ts')],bundle:true,platform:'node',format:'esm',outfile:join(dir,'engine.mjs'),alias:{'~':join(root,'builder/vendor/darkforge/app')},nodePaths:[join(root,'frontend/node_modules')],define:{'import.meta.env':'{}'}});
 await require('esbuild').build({stdin:{contents:"export {generateProject} from './builder/direct-build';export {readModelResponse} from './builder/model-transport';export {getChatIssue} from './builder/vendor/darkforge/app/utils/chat-errors';",resolveDir:root},bundle:true,platform:'node',format:'esm',outfile:join(dir,'direct.mjs'),alias:{'~':join(root,'builder/vendor/darkforge/app')},nodePaths:[join(root,'frontend/node_modules')],define:{'import.meta.env':'{}'}});
 const {generateProject,readModelResponse,getChatIssue}=await import(pathToFileURL(join(dir,'direct.mjs')));
 engine=spawn(process.execPath,[join(dir,'engine.mjs')],{env:{...process.env,BUILDER_ENGINE_PORT:String(port),BUILDER_API_ORIGIN:'http://127.0.0.1:'+mock.address().port,BUILDER_ENGINE_SECRET:secret},stdio:['ignore','ignore','pipe']});
 const base='http://127.0.0.1:'+port;
 for(let i=0;i<100;i++){try{if((await fetch(base+'/health',{headers:{authorization:'Bearer '+secret}})).ok)break;}catch{}await new Promise(r=>setTimeout(r,30));}
 const run=async(extra={})=>{calls=[];first=true;const r=await fetch(base+'/generate',{method:'POST',headers:{authorization:'Bearer '+secret,'content-type':'application/json'},body:JSON.stringify({mode:'build',contextLength:8192,ticket:'fixture',files:{},messages:[{role:'user',content:'Build the approved notes app'}],approvedPlan:proposal,...extra})});return(await r.text()).split('\n').filter(x=>x.trim()).map(x=>JSON.parse(x));};
 await test('review splits a two-file batch when each source fits but their combination does not',async()=>{
  scenario='review';const events=await run({files});
  assert.equal(events.at(-1).type,'done',JSON.stringify(events.at(-1)));
  const reviewed=calls.filter(c=>c.role==='file_reviewer');
  assert.ok(reviewed.some(c=>c.messages[0].content.includes('"requiredFiles":["a.js"]')));
  assert.equal(events.find(e=>e.type==='files').files['/home/project/a.js'].content,large);
 });
 await test('multi-file diagnostic prioritizes affected source without requiring every file in every call',async()=>{
  scenario='review';const events=await run({files,repairContext:{diagnostic:'a.js and b.js syntax failures',affectedFiles:['a.js','b.js'],automatic:true}});
  assert.equal(events.at(-1).type,'done',JSON.stringify(events.at(-1)));
  assert.ok(calls.length>0);assert.ok(calls[0].messages[0].content.includes('a.js and b.js syntax failures'));
  const reviewed=calls.filter(c=>c.role==='file_reviewer');
  assert.ok(reviewed.some(c=>c.messages[0].content.includes('"requiredFiles":["a.js"]')));
 });
 await test('a truncated multi-file reply falls back to smaller batches if continuation exhausts context',async()=>{
  scenario='continuation';const events=await run();
  assert.equal(events.at(-1).type,'done',JSON.stringify(events.at(-1)));
  const output=events.find(e=>e.type==='files');
  for(const path of ['a.js','b.js'])assert.equal(output.files['/home/project/'+path].content,large);
 });
 await test('planning bounds optional memory/history before an 8K provider request',async()=>{
  scenario='planning';await run({mode:'planning',sitePrompt:'Optional profile '.repeat(4000),messages:[...Array.from({length:20},(_,i)=>({role:i%2?'assistant':'user',content:'old discussion '.repeat(250)})),{role:'user',content:'CURRENT_USER_REQUEST: Arabic notes'}]});
  assert.ok(calls[0].messages.reduce((sum,m)=>sum+m.content.length+16,0)<12000,'sent an oversized planning prompt');
  assert.match(calls[0].messages.at(-1).content,/CURRENT_USER_REQUEST/);
 });
 await test('planning correction retains the question IDs/options together with the current answer',async()=>{
  scenario='planning_correction';
  const questions={kind:'questions',message:'CRITICAL_QUESTIONS_MARKER '+'.'.repeat(2000),questions:[{id:'target',label:'Which target?',options:['A'+'.'.repeat(4000),'B']}]};
  const events=await run({mode:'planning',messages:[{role:'assistant',content:'Questions',plan:questions},{role:'user',content:'Which target?: B'}]});
  assert.equal(events.at(-1).type,'done');assert.equal(calls.length,2);
  assert.ok(calls[1].messages.some(m=>m.content.includes('CRITICAL_QUESTIONS_MARKER')),'correction lost the questions');
  assert.ok(calls[1].messages.some(m=>m.content==='Which target?: B'));
  assert.ok(calls[1].messages.reduce((sum,m)=>sum+m.content.length+16,0)<12000);
 });
 for(const stream of [false,true])await test('context error stays machine readable across '+(stream?'NDJSON':'HTTP'),async()=>{
  const response=new Response(JSON.stringify(stream?{type:'error',code:'context',status:413,message:'لا توجد مساحة كافية في سياق النموذج.'}:{detail:{code:'context',message:'لا توجد مساحة كافية في سياق النموذج.'}})+(stream?'\n':''),{status:stream?200:413,headers:{'content-type':stream?'application/x-ndjson':'application/json'}});
  await assert.rejects(readModelResponse(response),error=>getChatIssue(error).code==='context'&&!error.message.includes('DF_CHAT_ERROR'));
 });
 await test('all 200 planned files finish when the provider writes one file per response',async()=>{
  const paths=Array.from({length:200},(_,i)=>'module-'+i+'.js');let count=0;
  const result=await generateProject({files:{},requiredPaths:paths,signal:new AbortController().signal,call:async call=>{count++;return{text:JSON.stringify({actions:[{type:'file',filePath:call.required[0],content:'export const value = 1;'}],remainingFiles:[]}),finishReason:'stop'}}});
  assert.equal(count,200);assert.equal(Object.keys(result.files).length,200);
 });
 await test('stale remainingFiles cannot repeatedly enqueue already-written files',async()=>{
  let count=0;
  const result=await generateProject({files:{},requiredPaths:['a.js','b.js'],signal:new AbortController().signal,call:async call=>{count++;return{text:JSON.stringify({actions:[{type:'file',filePath:call.required[0],content:'export const value = 1;'}],remainingFiles:['a.js','b.js']}),finishReason:'stop'}}});
  assert.equal(count,2);assert.equal(Object.keys(result.files).length,2);
 });
 await test('a bounded four-segment response preserves source instead of restarting after three',async()=>{
  const raw=JSON.stringify({actions:[{type:'file',filePath:'a.js',content:'export const text = "Arabic: أهلاً";'}],remainingFiles:[]});
  let count=0;
  const result=await generateProject({files:{},requiredPaths:['a.js'],signal:new AbortController().signal,call:async call=>{
   const segment=count++;assert.equal(call.continuation||'',raw.slice(0,segment*30));
   return{text:raw.slice(segment*30,segment===3?undefined:(segment+1)*30),finishReason:segment===3?'stop':'length'};
  }});
  assert.equal(count,4);assert.equal(result.files['/home/project/a.js'].content,'export const text = "Arabic: أهلاً";');
 });
 console.log('Builder limit regressions:',checks,'passed,',failures,'failed');process.exitCode=failures?1:0;
}finally{
 if(engine&&engine.exitCode===null){engine.kill();await once(engine,'exit');}
 await new Promise(resolve=>mock.close(resolve));await rm(dir,{recursive:true,force:true});
}
